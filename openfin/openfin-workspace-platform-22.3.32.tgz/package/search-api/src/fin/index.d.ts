import type OpenFin from '@openfin/core';
export declare function getIdentity(): OpenFin.Identity;
export declare function getPlatformNamespace(): string | undefined;
export declare function connectToChannel(name: string): Promise<OpenFin.ChannelClient | never>;
export declare function createChannel(name: string): Promise<OpenFin.ChannelProvider>;
