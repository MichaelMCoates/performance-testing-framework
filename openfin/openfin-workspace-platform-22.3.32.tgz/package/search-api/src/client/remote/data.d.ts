import type { InternalDataRequest, InternalDataResponse, InternalErrorResponse } from '../../internal-shapes';
/**
 * Push a data response to the creator of the search topic.
 * @param topic the search topic to push the data on.
 * @param res the internal data response to push.
 */
export declare function pushDataResponse(res: InternalDataResponse): Promise<any>;
/**
 * Listen for remote search provider data requests.
 * When a message is received on this channel, the provider described in the request will be looked up
 * and have its `onUserInput` function called. The response of said function will be returned back to the
 * identity that sent the channel message.
 * @param ctx the search topic context.
 */
export declare function makeStreamListener(): (req: InternalDataRequest) => Promise<InternalDataResponse | InternalErrorResponse>;
