import type { OpenFin } from '@openfin/core';
export declare function create(channelName: string): Promise<OpenFin.ChannelClient>;
