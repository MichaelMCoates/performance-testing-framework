/**
 * On channel disconnect, will attempt to reconnect.
 */
export declare function makeStreamListener(channelName: string): () => Promise<void>;
