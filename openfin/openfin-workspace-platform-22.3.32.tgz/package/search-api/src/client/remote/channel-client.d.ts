import type { OpenFin } from '@openfin/core';
export declare function getOrFail(): Promise<OpenFin.ChannelClient>;
export declare function get(): Promise<OpenFin.ChannelClient>;
export declare function set(newChannelPromise: Promise<OpenFin.ChannelClient>): void;
export declare function remove(): void;
