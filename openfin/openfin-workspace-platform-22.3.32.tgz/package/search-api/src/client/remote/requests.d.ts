import type { InternalSearchListenerRequest } from '../../internal-shapes';
export default function getSearchRequests(): Map<string, InternalSearchListenerRequest>;
