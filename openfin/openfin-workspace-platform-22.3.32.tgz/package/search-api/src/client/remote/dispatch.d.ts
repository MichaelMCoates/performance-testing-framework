import type OpenFin from '@openfin/core';
import type { InternalDispatchRequest } from '../../internal-shapes';
/**
 * Register a result dispatch channel topic listener.
 * When a message is received on this channel topic, the provider will be looked up and pass the result
 * to its `onResultDispatch` listener.
 */
export declare function makeStreamListener(): (req: InternalDispatchRequest, identity: OpenFin.Identity) => Promise<void>;
