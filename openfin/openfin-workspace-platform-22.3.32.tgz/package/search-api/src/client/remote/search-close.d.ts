import type { InternalSearchCloseRequest } from '../../internal-shapes';
/**
 * Listens for search requests that have been closed.
 * Upon being notified of a closed search request, get the internal representation
 * of the request for this client and close it.
 */
export declare function makeStreamListener(): (req: InternalSearchCloseRequest) => void;
/**
 * Close a remote search request.
 */
export declare function sendSearchRequestClose(requestId: string): Promise<any>;
