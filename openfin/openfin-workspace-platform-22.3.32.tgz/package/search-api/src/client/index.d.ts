import type { SearchTopicClient } from '../shapes';
/**
 * Subscribe to an existing search topic.
 * @param req the subscribe request.
 */
export declare function subscribe(channelName: string): Promise<SearchTopicClient>;
