import type { OpenFin } from '@openfin/core';
import type { DispatchedAction, RegistrationMetaInfo, SearchProvider, SearchProviderInfo, SearchProviderResponseGeneratorExtended, SearchRequest, SearchResult } from '../shapes';
/**
 * Register a remote search provider.
 * @param namespacedTopic the namespaced search topic to register the provider on.
 * @param provider the search provider to register.
 */
export declare function register(provider: SearchProvider, channel?: OpenFin.ChannelClient): Promise<RegistrationMetaInfo>;
/**
 * Deregister a remote search provider.
 * @param topic the search topic to deregister the provider from.
 * @param id the id of the search provider.
 */
export declare function deregister(id: string): Promise<void>;
/**
 * Dispatch a search result back to the respective provider.
 * @param providerId the name of the provider to dispatch the result back to.
 * @param result the search result to dispatch back to the provider.
 * @param action the action to dispatch the search result with.
 * @param identity optionally provide the identity of the dispatcher, otherwise the current identity will be used.
 */
export declare function dispatch(providerId: string, result: SearchResult, action: DispatchedAction, identity?: OpenFin.Identity): Promise<any>;
/**
 * Returns an extended search generator object.
 * @param namespacedTopic the namespaced search topic.
 * @param req the search request.
 */
export declare function search(request: SearchRequest): Promise<SearchProviderResponseGeneratorExtended>;
/**
 * Get the information for all search providers registered on this search topic.
 * @param namespacedTopic the namespaced search topic.
 */
export declare function getAllProviders(): Promise<SearchProviderInfo[]>;
/**
 * Disconnect from a search topic.
 * @param topic the namespaced search topic to disconnect from.
 */
export declare function disconnect(): Promise<void>;
