import * as client from './client';
import * as provider from './provider';
export declare const create: typeof provider.create;
export declare const subscribe: typeof client.subscribe;
export declare const defaultTopic = "all";
export type { SearchProviderResponse, SearchRequest, SearchTopicClient, SearchTopic, SearchProviderInfo, ScoreOrder, Action, ActionTrigger, SearchResult, SearchListenerRequest, SearchListenerResponse, UserInputListener, DispatchedSearchResult, DispatchedAction, ResultDispatchListener, SearchProvider, SearchTag, SearchResponse, DeregisterListener, DisconnectListener, RegisterListener, SubscriptionListener } from './shapes';
export { SearchTagBackground } from './shapes';
