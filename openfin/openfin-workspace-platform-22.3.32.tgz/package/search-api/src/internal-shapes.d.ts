import type OpenFin from '@openfin/core';
import type { DispatchedSearchResult, SearchListenerRequest, SearchListenerResponse, SearchProvider, SearchProviderInfo, SearchProviderResponse, SearchProviderResponseGeneratorState, SearchRequest, SearchResponse, SearchResult } from './shapes';
/**
 * Message for dispatching a search request.
 * This interface is used when sending a dispatch request from a remote OpenFin identity
 * to the search topic creator.
 */
export interface InternalSearchRequest extends SearchRequest {
    /**
     * The id of the search request.
     * On initial search request from remote provider, this ID is generated.
     * The remote OpenFin identity is required to pass this id on all subsequent requests.
     */
    id?: string;
}
export interface SearchProviderWithIdentity extends SearchProvider {
    identity: OpenFin.Identity;
}
export interface SearchProviderInfoWithIdentity extends SearchProviderInfo {
    identity: OpenFin.Identity;
}
/**
 * Response for a remote search request.
 */
export interface InternalSearchResponse {
    /**
     * The ID of the search request the response pertains to.
     */
    id: string;
    /**
     * True if the all search providers have responded to the search request.
     */
    done?: boolean;
    /**
     * The state of the search response generator.
     */
    state: SearchProviderResponseGeneratorState;
    /**
     * The current list of responses.
     */
    value: SearchProviderResponse[];
}
/**
 * Close a search request.
 * Used to notify search topic creator that a remote OpenFin identity has closed a search request.
 */
export interface InternalSearchCloseRequest {
    /**
     * The id of the remote search request to close.
     */
    id: string;
}
/**
 * Request data from a specific remote search provider.
 * This interface is used when requesting data from a search provider that is maintained in another OpenFin application.
 */
export interface InternalDataRequest {
    id: string;
    query: string;
    context: any;
    providerId: string;
    targets: string[];
}
export declare enum InternalSearchListenerResponseStatus {
    /**
     * The intial status of a new search listener response object.
     *
     * Denotes that the search provider listener has not taken use of the search listener response object,
     * as in `response.open()` nor `response.close()` has not been called yet.
     */
    Initial = 0,
    /**
     * Denotes that the search provider is done sending new or updated search results
     * for the corresponding request.
     */
    Open = 1,
    /**
     * Denotes that the search provider is done sending new or updated search results
     * for the corresponding request.
     */
    Close = 2
}
/**
 * Respond to the provider data request with data.
 * This interface is used when responding to the provider with data from datasources maintained in views.
 */
export interface InternalDataResponse extends SearchResponse {
    id: string;
    providerId: string;
    revoked?: string[];
    status?: InternalSearchListenerResponseStatus;
}
export interface InternalErrorResponse {
    /**
     * An error message, denoting that something went wrong.
     */
    error: string;
}
/**
 * Dispatch search result back to provider with an action.
 * This interface is used when dispatching a search result that came from a provider in another window or view.
 */
export interface InternalDispatchRequest {
    result: DispatchedSearchResult;
    providerId: string;
}
export interface InternalSearchListenerResponse {
    getResultBuffer(): SearchResult[];
    setResultBuffer(results: SearchResult[]): void;
    getRevokedBuffer(): string[];
    setRevokedBuffer(resultIds: string[]): void;
    getUpdatedContext(): any;
    setUpdatedContext(context: any | null): void;
    onChange(): void;
    getStatus(): InternalSearchListenerResponseStatus;
    res: SearchListenerResponse;
}
export interface InternalSearchListenerRequest {
    close(): void;
    req: SearchListenerRequest;
}
export interface InternalSearchResponseGeneratorHooks {
    setState(state: SearchProviderResponseGeneratorState): void;
}
