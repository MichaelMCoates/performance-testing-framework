import type { SearchTopic } from '../shapes';
/**
 * Create a topic.
 * If the OpenFin identity creating the topic is running in a platform, the search topic will be sandboxed to the platform.
 * In order to subscribe to a sandboxed search topic, the UUID of the platform must be specifed explicitly or the subscribing OpenFin identity must be running in the platform.
 */
export declare function create(channelName: string): Promise<SearchTopic>;
