import type { OpenFin } from '@openfin/core';
import { DispatchedAction, RegistrationMetaInfo, SearchProvider, SearchProviderInfo, SearchProviderResponseGeneratorExtended, SearchRequest, SearchResult } from '../shapes';
/**
 * Get all registered providers' info for an topic.
 * @param namespacedTopic the namespaced search topic id.
 */
export declare function getAllProviders(): Promise<SearchProviderInfo[]>;
/**
 * Register a provider.
 * @param provider the provider to register.
 */
export declare function register(provider: SearchProvider): Promise<RegistrationMetaInfo>;
/**
 * Deregister a provider.
 * @param name the name of the search provider to deregister.
 */
export declare function deregister(name: string): Promise<void>;
/**
 * Dispatch a search result back to the respective provider.
 * @param providerId the name of the provider to dispatch the result back to.
 * @param result the search result to dispatch back to the provider.
 * @param action the action to dispatch the search result with.
 * @param identity optionally provide the identity of the dispatcher, otherwise the current identity will be used.
 */
export declare function dispatch(providerId: string, result: SearchResult, action: DispatchedAction, identity?: OpenFin.Identity): Promise<void>;
/**
 * Returns an extended search generator object.
 * @param ctx the search topic context.
 * @param req the search request.
 */
export declare function search(req: SearchRequest): Promise<SearchProviderResponseGeneratorExtended>;
