import type OpenFin from '@openfin/core';
import type { InternalDispatchRequest } from '../../internal-shapes';
/**
 * Make a channel listener for proxying search result dispatch from a remote OpenFin identity back to the respective provider.
 */
export declare function makeStreamListener(): (req: InternalDispatchRequest, identity: OpenFin.Identity) => Promise<void>;
