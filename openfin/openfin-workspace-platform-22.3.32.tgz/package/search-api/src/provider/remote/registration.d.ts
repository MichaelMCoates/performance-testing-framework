import type OpenFin from '@openfin/core';
import { SearchProviderInfoWithIdentity } from '../../../../search-api/src/internal-shapes';
import type { RegistrationMetaInfo, SearchProviderInfo } from '../../shapes';
/**
 * Add a remote search provider.
 * @param info the search provider info. Must include identity.
 */
export declare function addRemoteProvider(info: SearchProviderInfoWithIdentity): Promise<void>;
/**
 * Removes a remote search provider.
 * @param name the name of the search provider.
 */
export declare function removeRemoteProvider(id: string, identity: OpenFin.Identity): void;
/**
 * Remove all search providers registered by the remote OpenFin identity.
 * @param identity the identity that registered the remote search providers.
 */
export declare function removeRemoteProvidersForIdentity(identity: OpenFin.Identity): void;
/**
 * Make a channel listener that allows remote OpenFin identities to register a search provider to a search topic.
 */
export declare function makeStreamListener(): (info: SearchProviderInfo, identity: OpenFin.Identity) => Promise<RegistrationMetaInfo | undefined>;
