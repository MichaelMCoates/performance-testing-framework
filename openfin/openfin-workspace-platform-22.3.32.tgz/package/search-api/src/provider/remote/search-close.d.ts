import type OpenFin from '@openfin/core';
import type { InternalSearchCloseRequest } from '../../internal-shapes';
/**
 * Sends a message notifying a remote OpenFin identity that a search request has been closed.
 * @param identity the remote OpenFin identity to notify.
 * @param requestId the search request id.
 */
export declare function sendRequestCloseToIdentity(identity: OpenFin.Identity, requestId: string): Promise<any>;
/**
 * Listen for search request close messages from remote providers.
 * On message, close the remote search request.
 */
export declare function makeStreamListener(): (req: InternalSearchCloseRequest) => void;
