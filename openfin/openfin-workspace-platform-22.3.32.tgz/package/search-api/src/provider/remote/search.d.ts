import type { InternalErrorResponse, InternalSearchRequest, InternalSearchResponse } from '../../internal-shapes';
export declare function closeRemoteSearchRequest(requestId: string): void;
/**
 * Listen for search requests from remote OpenFin identities.
 * On message, setup search generator that remote identity can check the status of in subsequent requests.
 */
export declare function makeStreamListener(): (request: InternalSearchRequest) => Promise<InternalSearchResponse | InternalErrorResponse>;
