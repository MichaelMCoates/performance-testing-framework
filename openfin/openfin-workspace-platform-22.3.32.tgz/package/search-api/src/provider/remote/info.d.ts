/**
 * Make a channel listener for sending search provider info to a remote OpenFin identity.
 * @param namespacedTopic the context of the search topic to get the provider info from.
 */
export declare function makeStreamListener(): () => Promise<import("@client/index").SearchProviderInfo[]>;
