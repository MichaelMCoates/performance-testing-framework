import type { OpenFin } from '@openfin/core';
/**
 * Create a channel for interacting with remote search providers.
 * @param ctx the context of the search topic to create the channel for.
 */
export declare function create(namespace: string): Promise<OpenFin.ChannelProvider>;
