import type { OpenFin } from '@openfin/core';
/**
 * Get the OpenFin channel that represents a topic.
 * If not found, will throw an error.
 */
export declare function getOrFail(): OpenFin.ChannelProvider;
/**
 * Get the OpenFin channel that represents a topic.
 */
export declare function get(): OpenFin.ChannelProvider;
/**
 * Set the OpenFin channel for a search topic.
 * @param channel the channel for the search topic.
 */
export declare function set(newChannel: OpenFin.ChannelProvider): void;
export declare function remove(): void;
