import { InternalDataResponse, SearchProviderInfoWithIdentity } from '../../internal-shapes';
import { DispatchedSearchResult, SearchListenerRequest, SearchListenerResponse } from '../../shapes';
/**
 * Listens for pushed new/updated remote search provider results or status changes.
 * When a message is received, call all listeners corresponding to the response.
 * @param namespacedTopic the namespaced search topic.
 */
export declare function makeStreamListener(): (res: InternalDataResponse) => void;
/**
 * Make a search listener for a remote search provider.
 * This listener will be called by the provider when the topic is searched.
 * When called, the listener waits and returns the response from the view for the data request.
 * @param info the provider info.
 */
export declare function makeOnSearch(info: SearchProviderInfoWithIdentity): (request: SearchListenerRequest, response: SearchListenerResponse) => Promise<InternalDataResponse>;
/**
 * Make a dispatch result listener for a remote search provider.
 * When called, the listener sends a result dispatch request to the underlying remote OpenFin identity.
 * @param info the remote search provider info.
 */
export declare function makeOnResultDispatch(info: SearchProviderInfoWithIdentity): (result: DispatchedSearchResult) => Promise<any>;
