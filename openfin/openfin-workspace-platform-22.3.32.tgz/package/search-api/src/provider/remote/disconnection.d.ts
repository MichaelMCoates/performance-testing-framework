import type OpenFin from '@openfin/core';
import type { DisconnectListener } from '../../shapes';
export declare function addDisconnectListener(listener: DisconnectListener): void;
export declare function removeDisconnectListener(listener: DisconnectListener): void;
/**
 * Called when a remote OpenFin identity disconnects from the channel for a search topic.
 * Disconnecting will clean up all search providers correlated to the OpenFin identity.
 * @param namespacedTopic the namespaced search topic id.
 */
export declare function makeStreamListener(): (identity: OpenFin.Identity) => Promise<void>;
