import type OpenFin from '@openfin/core';
import type { SubscriptionListener } from '../../shapes';
/**
 * Add a listener that is called whenever someone remotely subscribes to a search topic.
 * @param listener the subscription listener to add.
 */
export declare function addSubscriptionListener(listener: SubscriptionListener): void;
/**
 * Remove a listener that is called whenever someone remotely subscribes to a search topic.
 * @param listener the listener to remove.
 */
export declare function removeSubscriptionListener(listener: SubscriptionListener): void;
/**
 * Called when a remote OpenFin identity connects to a channel to listen on topic invocations.
 * If a subscription listener registered for this search topic returns false, the request will be rejected.
 */
export declare function makeStreamListener(): (identity: OpenFin.Identity) => Promise<void>;
