import type OpenFin from '@openfin/core';
/**
 * Make a channel listener for deregistering remote search providers from search topics.
 */
export declare function makeStreamListener(): (name: string, identity: OpenFin.Identity) => void;
