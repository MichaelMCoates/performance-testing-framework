import type OpenFin from '@openfin/core';
import { InternalSearchListenerRequest, InternalSearchListenerResponse, SearchProviderWithIdentity } from './internal-shapes';
import { DeregisterListener, DispatchedAction, DispatchedSearchResult, RegisterListener, ScoreOrder, SearchProvider, SearchRequest, SearchResult } from './shapes';
export declare const defaultSearchTopic = "all";
/**
 * The stream id that data is requested and transported back to the creator of a search topic on.
 */
export declare const remoteProviderDataStreamId = "0";
/**
 * The stream id that handles search request to the creator of a search topic from remote client like views.
 */
export declare const remoteClientSearchStreamId = "1";
/**
 * The stream id for registering a remote search provider with the creator of a search topic.
 */
export declare const remoteProviderRegistrationStreamId = "2";
/**
 * The stream id for deregistering a remote search provider with the creator of a search topic.
 */
export declare const remoteProviderDeregistrationStreamId = "3";
/**
 * The stream id for sharing remote search provider information with the creator of a search topic.
 */
export declare const remoteProviderInfoStreamId = "4";
/**
 * The stream id for dispatching search results back to a remote search provider.
 */
export declare const remoteProviderDispatchStreamId = "5";
/**
 * The stream id for notifying remote search providers that the request have closed.
 */
export declare const remoteSearchCloseStreamId = "6";
export declare const noop: () => void;
export declare function addRegisterListener(listener: RegisterListener): void;
export declare function removeRegisterListener(listener: RegisterListener): void;
export declare function addDeregisterListener(listener: DeregisterListener): void;
export declare function removeDeregisterListener(listener: DeregisterListener): void;
/**
 * Add a provider.
 * @param provider the search provider to register.
 */
export declare function addProvider(provider: SearchProviderWithIdentity): Promise<void>;
/**
 * Remove a provider.
 * @param id the id of the provider.
 */
export declare function removeProvider(id: string): Promise<void>;
/**
 * Get all providers for a topic.
 */
export declare function getProviders(): SearchProvider[];
/**
 * Clears all search providers for a search topic.
 */
export declare function clearProviders(): void;
/**
 * Get a provider for a topic.
 * @param id the name of the search provider.
 */
export declare function getProvider(id: string): SearchProviderWithIdentity | undefined;
/**
 * Make a dispatched search result.
 * @param result the original search result.
 * @param action the action this search result is dispatched with.
 */
export declare function makeDispatchedSearchResult(result: SearchResult, dispatcherIdentity: OpenFin.Identity, actionParam?: DispatchedAction): DispatchedSearchResult;
/**
 * Algorithm for aggregating search results.
 *
 * Any search results in the old set of results will be replaced with
 * new search results if their `key` field matches.
 *
 * The array will then be sorted by `score`.
 */
export declare function aggregate(oldResultsParam: SearchResult[], newResults: SearchResult[], order?: ScoreOrder): SearchResult[];
/**
 * Creates a wrapper around a search listener response that can be used internally
 * to listen for search results that were added to the buffer or response status changes.
 * @param scoreOrder the order to aggregate search results in.
 */
export declare function makeInternalSearchListenerResponse(scoreOrder?: ScoreOrder): InternalSearchListenerResponse;
/**
 * Creates a wrapper around a search listener request that can be used
 * internally to close the request.
 * @param topic the topic the search request was dispatched on.
 * @param id the id of the search request.
 * @param req the search request.
 */
export declare function makeInternalSearchListenerRequest(id: string, req: SearchRequest): InternalSearchListenerRequest;
