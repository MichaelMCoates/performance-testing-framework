export declare const providerNotExist: Error;
export declare const providerExists: Error;
export declare const badPayload: Error;
export declare const subscriptionRejected: Error;
export declare const channelNotExist: Error;
