export { Microsoft365WorkflowIntegration } from './integrations/microsoft';
export type { Microsoft365IntegrationConfig, Microsoft365ConnectionConfig, Microsoft365Workflows, MicrosoftEntityTypeConfig, MicrosoftSearchWorkflowConfig } from './integrations/microsoft';
export type { WorkflowIntegrationConfig, WorkflowIntegration, IntegrationWorkflows } from './shapes/integrations';
