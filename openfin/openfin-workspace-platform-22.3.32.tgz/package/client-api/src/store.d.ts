/**
 * Entry points for the OpenFin Workspace Store API.
 *
 * The Store API allows you to register a Store provider with the Workspace Platform.
 *
 * @packageDocumentation
 */
import type { StorefrontProvider, StoreRegistration } from './shapes/store';
export * from './shapes/store';
/**
 * Registers a {@link StorefrontProvider}.
 *
 * @throws Error if a provider with the same `id` already exists.
 * @throws Error if Workspace Platform is not initialized.
 *
 * @param provider the implementation of a Storefront provider.
 *
 * @example
 * ```ts
 * import { Storefront, type StorefrontProvider } from "@openfin/workspace";
 *
 * const myStorefrontProvider: StorefrontProvider = {
 *      id: "my-storefront-id"
 *      title: "My StorefrontProvider"
 *      icon: "https://cdn.openfin.co/demos/notifications/generator/images/icon-blue.png",
 *      getApps: () => {...},
 *      getNavigation: () => {...},
 *      getLandingPage: () => {...},
 *      getFooter: () => {...},
 *      launchApp: () => {...}
 * };
 *
 * await Storefront.register(myStorefrontProvider);
 * ```
 */
export declare const register: (provider: StorefrontProvider) => Promise<StoreRegistration>;
/**
 * API function to deregister a Storefront provider.
 *
 * @param providerId the id of the provider to deregister.
 * @returns promise that resolves once the provider is deregistered.
 *
 * @throws an error if the provider is not currently registered.
 * @example
 *
 * ```ts
 * import { Storefront, type StorefrontProvider } from "@openfin/workspace";
 *
 * const myStorefrontProvider: StorefrontProvider = {
 *      id: "my-storefront-id"
 *      title: "My StoreFrontProvider"
 *      icon: "https://cdn.openfin.co/demos/notifications/generator/images/icon-blue.png",
 *      getApps: () => {...},
 *      getNavigation: () => {...},
 *      getLandingPage: () => {...},
 *      getFooter: () => {...},
 *      launchApp: () => {...}
 * };
 *
 * await Storefront.register(myStorefrontProvider);
 *
 * await Storefront.deregister("my-storefront-id");
 * ```
 */
export declare const deregister: (providerId: string) => Promise<void>;
/**
 * API function to hide the Store UI.
 *
 * @remarks At least one Store provider must be registered for this function to take effect.
 *
 * @returns a promise that resolves once the Store UI is hidden.
 *
 * @example Hide a Store provider.
 *
 * ```ts
 * import { Storefront } from '@openfin/workspace';
 *
 * await Storefront.hide();
 * ```
 */
export declare const hide: () => Promise<void>;
/**
 * API function to show the Store UI.
 *
 * @remarks At least one Store provider must be registered for this function to take effect.
 *
 * @returns a promise that resolves once the Store UI is shown
 *
 * @example Show a Store provider.
 *
 * ```ts
 * import { Storefront } from '@openfin/workspace';
 *
 * await Storefront.show();
 * ```
 */
export declare const show: () => Promise<void>;
