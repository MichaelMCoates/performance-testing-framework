import type { CLIProvider, HomeProvider } from './shapes/home';
import { HomeRegistration } from './shapes/home';
export * from './shapes/home';
/**
 * API function to register a Home provider.
 *
 * @remarks A Workspace Platform must be initialized.
 *
 * @throws An error if the Workspace Platform is not initialized.
 * @throws An error if a Home provider with the same `id` is already registered.
 *
 * @param provider - The Home provider to register.
 *
 * @returns A promise that resolves with a `HomeRegistration` object once the Dock provider is successfully registered. This contains the client API version, Workspace Version and a function to set the search query.
 *
 * @example **Register a Basic Home provider**
 *
 * ```ts
 * import { Home, type HomeProvider } from '@openfin/workspace';
 *
 * const provider: HomeProvider = {
 *     title: "My Home Provider"
 *     inputPlaceholder: "Search with My Home Provider",
 *     icon: "https://www.openfin.co/favicon-32x32.png",
 *     listTitle: "My Home Provider Results",
 *     logoUrl: "https://www.openfin.co/favicon-32x32.png",
 *     id: "my-home-provider",
 *     onUserInput: (req, res) => {
 *         console.log(req.query);
 *         return { results: [], context: { filters: [] } }
 *     },
 *     dispatchFocusEvents: true,
 * };
 *
 * await Home.register(provider)
 *
 * await Home.show()
 * ```
 */
export declare const register: (provider: HomeProvider | CLIProvider) => Promise<HomeRegistration>;
/**
 * API function to deregister a Home provider.
 *
 * @remarks A Workspace Platform must be initialized, and the Home provider must be registered for this function to take effect.
 *
 * @throws an error if the provider is not registered.
 *
 * @param providerId the Home provider ID.
 *
 * @returns a promise that resolves once the Home provider is successfully deregistered.
 *
 * @example Deregister a Home provider.
 *
 * ```ts
 * import { Home } from '@openfin/workspace';
 *
 * await Home.deregister('my-home-provider');
 * ```
 */
export declare const deregister: (providerId: string) => Promise<void>;
/**
 * API function to show the Home UI.
 *
 * @remarks A Workspace Platform must be initialized, and at least one Home provider must be registered for this function to take effect.
 *
 * @returns a promise that resolves once the Home UI is hidden
 *
 * @example Show a Home provider.
 *
 * ```ts
 * import { Home } from '@openfin/workspace';
 *
 * await Home.show();
 * ```
 */
export declare function show(): Promise<void>;
/**
 * API function to hide the Home UI.
 *
 * @remarks A Workspace Platform must be initialized, and at least one Home provider must be registered for this function to take effect.
 *
 * @returns a promise that resolves once the Home UI is hidden
 *
 * @example Hide a Home provider.
 *
 * ```ts
 * import { Home } from '@openfin/workspace';
 *
 * await Home.hide();
 * ```
 */
export declare function hide(): Promise<void>;
