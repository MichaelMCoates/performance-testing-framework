import * as DockAPI from './dock';
import * as HomeAPI from './home';
import * as IntegrationsAPI from './integrations';
import * as StorefrontAPI from './store';
export * from './shapes/common';
export * from './shapes/templates';
export * from './shapes/home';
export * from './shapes/store';
export * from './shapes/dock';
/**
 * Namespace for Storefront integrations.
 */
export { StorefrontAPI as Storefront };
/**
 * Namespace for Home integrations.
 */
export { HomeAPI as Home };
/**
 * Namespace for Dock integrations.
 */
export { DockAPI as Dock };
/**
 * Namespace for Microflows integrations.
 */
export { IntegrationsAPI as Integrations };
