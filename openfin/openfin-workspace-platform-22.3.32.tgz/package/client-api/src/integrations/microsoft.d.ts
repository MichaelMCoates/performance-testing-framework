import { BaseWorkflowIntegration, WorkflowIntegration } from '../../../client-api/src/shapes/integrations';
import { Microsoft365ConnectionConfig, Microsoft365IntegrationConfig, Microsoft365Workflows, MicrosoftEntityTypeConfig, MicrosoftSearchWorkflowConfig } from './microsoft.shapes';
export type { Microsoft365IntegrationConfig, Microsoft365ConnectionConfig, Microsoft365Workflows, MicrosoftSearchWorkflowConfig, MicrosoftEntityTypeConfig };
/**
 * The Microsoft365WorkflowIntegration class is a WorkflowIntegration that provides Microsoft 365 integration.
 * This integration allows you to search for Microsoft 365 entities and perform actions on them using Home.
 */
export declare class Microsoft365WorkflowIntegration extends BaseWorkflowIntegration implements WorkflowIntegration {
    #private;
    /** The configuration object for the integration. */
    config: Microsoft365IntegrationConfig;
    /** The name of the integration. Used for Analytics */
    workflowIntegrationName: string;
    /**
     * Creates an instance of Microsoft365WorkflowIntegration.
     *
     * @param config The configuration object for the integration.
     *
     * @example
     * ```ts
     * const microsoft365Integration = new Microsoft365WorkflowIntegration({
     *      connect: {
     *          clientId: microsoft365Config.clientId,       // Client ID of the registered app
     *          tenantId: microsoft365Config.tenantId,       // Tenant ID of the registered app
     *          redirectUri: microsoft365Config.redirectUri  // Redirect URI of the registered app. This _must_ be the same domain as the app (providerUrl).
     *      },
     * });
     *
     * await WorkspacePlatform.init({
     *     browserOptions: {},
     *     integrations: [microsoft365Integration]
     * })
     */
    constructor(config: Microsoft365IntegrationConfig);
    /**
     * Connects to the Microsoft 365 API using the provided configuration.
     *
     * @param config Defaults to the config provided to the constructor, but can be overridden here.
     *
     * @example
     * ```ts
     * await microsoft365Integration.connect({
     *     clientId: microsoft365Config.clientId,
     *     tenantId: microsoft365Config.tenantId,
     *     redirectUri: microsoft365Config.redirectUri
     * });
     * ```
     */
    connect: (config?: Microsoft365ConnectionConfig) => Promise<void>;
    /**
     * Wrapper around the Microsoft365Connection.executeApiRequest method.
     * If the request fails due to an expired auth token, this method will reconnect and retry the request.
     * If we are not connected, this method will connect before executing the request.
     *
     * @param args Arguments to pass to the Microsoft365Connection.executeApiRequest method.
     * @returns The response from the Microsoft365Connection.executeApiRequest method.
     */
    private executeApiRequest;
    /**
     * Initializes a given workflow.
     *
     * This method is automatically called when `disableAutoInitialize` is set to `false` in the workflow configuration.
     *
     * Use this method if you need to call it manually (not at platform initialization).
     *
     *
     * @param workflow The workflow to initialize.
     *
     * @example
     * ```ts
     * const microsoft365WorkflowIntegration = new Microsoft365WorkflowIntegration({
     *     connect: {
     *         clientId: microsoft365Config.clientId,
     *         tenantId: microsoft365Config.tenantId,
     *         redirectUri: microsoft365Config.redirectUri
     *     },
     *     workflows: {
     *         search: {
     *             disableAutoInitialize: true
     *         }
     *     }
     * });
     *
     * await platformInit({
     *     overrideCallback,
     *     browserOptions: {},
     *     integrations: [microsoft365WorkflowIntegration]
     * });
     *
     * await microsoft365WorkflowIntegration.initializeWorkflow('search');
     * ```
     */
    initializeWorkflow: (workflow: string) => Promise<void>;
}
