import { CLIFilter } from '../../../client-api/src/index';
import { CLISearchResultContact, HomeProvider } from '../../../client-api/src/shapes/home';
import type { Presence } from '@microsoft/microsoft-graph-types';
import type * as MicrosoftGraphTypes from '@microsoft/microsoft-graph-types';
import { Microsoft365DocumentType, MicrosoftEntityTypeConfig, MicrosoftSearchWorkflowConfig } from './microsoft.shapes';
export declare const getDefaultMicrosoftConfig: () => {
    workflows: {
        search: MicrosoftSearchWorkflowConfig;
    };
};
/** Map of MicrosoftEntityTypeConfig keys to their corresponding Microsoft365DocumentType. */
export declare const SEARCH_FILTER_TYPE_MAP: {
    [K in keyof MicrosoftEntityTypeConfig]: Microsoft365DocumentType;
};
/**
 * Some Microsoft 365 APIs require specific OAuth scopes to be provided. This map contains the required scopes for each MicrosoftEntityTypeConfig key.
 * For Example. If the `chatMessage: true` key is set, then the `Chat.Read` and `ChannelMessage.Read.All` scopes are required.
 */
export declare const MICROSOFT_365_REQUIRED_SCOPES: {
    [K in keyof MicrosoftEntityTypeConfig]?: string[];
};
export declare const MICROSOFT_365_SEARCH_RESULT_ACTIONS: {
    readonly teamsCall: "Teams Call";
    readonly teamsChat: "Teams Chat";
    readonly email: "Email";
};
/**
 * Extracts the selected filters from the given user input request and constructs a new filter array.
 *
 * The function looks for an existing filter with the ID matching `this.searchTypeFilterId` in the request.
 * If such a filter is found, its selected options are preserved in the new filter array.
 *
 * The returned filter array includes one filter object for 'Type', which is a multi-select filter with options for 'Document', 'Contact', 'Message', 'Email', and 'Event'.
 * The 'isSelected' status of these options is determined by their 'isSelected' status in the original request (if present).
 *
 * @param req The user input request object from which to extract the selected filters.
 * @returns An array of CLIFilter objects representing the validated filters.
 */
export declare const getValidFilters: (req: Parameters<HomeProvider["onUserInput"]>[0], searchTypePossibleFilters: Set<Microsoft365DocumentType>) => CLIFilter[];
export declare const getValidContactFilters: (users: MicrosoftGraphTypes.User[], req: Parameters<HomeProvider["onUserInput"]>[0]) => CLIFilter[];
export declare const getContactFiltersFromRequest: (req: Parameters<HomeProvider["onUserInput"]>[0]) => {
    department: string[];
    jobTitle: string[];
};
export declare const filterContactFromRequest: (items: MicrosoftGraphTypes.User[], filter: ReturnType<typeof getContactFiltersFromRequest>) => MicrosoftGraphTypes.User[];
/**
 * Extracts type filters from the input request.
 *
 * @param req - The user input request.
 *
 * @returns An object containing boolean flags indicating whether
 * each of the types (Documents, Contacts, Messages, Emails, Events) should be shown.
 * If none of the types are selected in the request, all types are marked to be shown.
 *
 * @remarks
 * The function first checks if the `selectedFilters` field in the request's context contains the search type filter ID.
 * If it does, it extracts the filter options and checks which types have been selected by the user.
 * If no types are selected or all types are deselected, the function marks all types to be shown.
 * Otherwise, it marks only the selected types to be shown.
 */
export declare const getTypeFiltersFromRequest: (req: Parameters<HomeProvider["onUserInput"]>[0], searchTypePossibleFilters: Set<Microsoft365DocumentType>) => {
    readonly showDocuments: boolean;
    readonly showContacts: boolean;
    /** Teams Messages */
    readonly showChatMessages: boolean;
    /** Outlook Emails */
    readonly showMessages: boolean;
    /** Outlook Events */
    readonly showEvents: boolean;
    /** SharePoint Lists */
    readonly showLists: boolean;
};
export declare const getDocumentFiltersFromRequest: (req: Parameters<HomeProvider["onUserInput"]>[0]) => {
    readonly filterFiles: boolean;
    readonly showWord: boolean;
    readonly showExcel: boolean;
    readonly showPowerPoint: boolean;
    readonly showPDF: boolean;
    readonly showOneNote: boolean;
};
export declare const filterDocumentsFromRequest: (items: MicrosoftGraphTypes.DriveItem[], filter: ReturnType<typeof getDocumentFiltersFromRequest>) => MicrosoftGraphTypes.DriveItem[];
export declare const getFileType: (fileName?: string) => string;
export declare const getFileIcon: (fileName?: string) => string;
export declare const mapMicrosoftAvailabilityToPresence: (availability: Presence) => CLISearchResultContact["templateContent"]["onlineStatus"] | undefined;
/** base64IdToUrl converts a base64 encoded id to a url safe id */
export declare const base64IdToUrl: (b64Id: string) => string;
