import { DeepPartial } from '../../../common/src/utils/types';
import { HomeProvider } from '../../../client-api/src/shapes/home';
import { IntegrationWorkflows, WorkflowConfig, WorkflowIntegrationConfig } from '../../../client-api/src/shapes/integrations';
/**
 * Configuration object for the Microsoft 365 workflow integration.
 *
 * Used for choosing which Microsoft 365 entities to include in the search results.
 *
 * @example
 * ```ts
 * const config: MicrosoftEntityTypeConfig = {
 *     message: true,
 *     chatMessage: true,
 *     drive: false,
 *     event: false,
 *     user: true,
 *     contact: false,
 *     list: false,
 * };
 * ```
 */
export interface MicrosoftEntityTypeConfig {
    /**
     * Whether or not to include messages (Outlook Emails) in the search results.
     *
     * `'Mail.ReadWrite.Shared'` OAuth scopes are required to access this data.
     * If these scopes are not provided, user Authentication will fail.
     *
     * @default true
     */
    message?: boolean;
    /**
     * Whether or not to include messages (Teams Messages) in the search results.
     *
     * `'Chat.Read' OR 'Chat.ReadWrite' AND 'ChannelMessage.Read.All'` OAuth scopes are required to access this data.
     * If these scopes are not provided, user Authentication will fail.
     *
     * Futhermore, the `openUrlWithBrowser` permission must be enabled in the application manifest. This should support the `msteams` protocols. This is used for opening the Teams client when action-ing a Teams message.
     * See the [Developer Guide](https://developers.openfin.co/of-docs/docs/api-security) for more information.
     *
     * @default true
     */
    chatMessage?: boolean;
    /**
     * Whether or not to include files (OneDrive Files) in the search results.
     * @default true
     */
    drive?: boolean;
    /**
     * Whether or not to include events (Outlook Calendar Events) in the search results.
     *
     * `'Calendars.Read' OR 'Calendars.ReadWrite'` OAuth scopes are required to access this data.
     * If these scopes are not provided, user Authentication will fail.
     *
     * @default true
     */
    event?: boolean;
    /**
     * Whether or not to include users (People) in the search results.
     *
     * `'User.Read.All' AND 'Presence.Read.All'` OAuth scopes are required to access this data.
     * If these scopes are not provided, user Authentication will fail.
     *
     * @default true
     */
    user?: boolean;
    /**
     * Whether or not to include contacts (Outlook Contacts) in the search results.
     *
     * `'Contacts.Read.Shared'` OAuth scopes are required to access this data.
     * If these scopes are not provided, user Authentication will fail.
     *
     * @default true
     */
    contact?: boolean;
    /**
     * Whether or not to include lists (SharePoint Lists) in the search results.
     *
     * `'Sites.Read.All' OR 'Sites.ReadWrite.All' AND 'Mail.ReadWrite.Shared'` OAuth scope is required to access this data.
     * @default true
     */
    list?: boolean;
}
/**
 * Configuration object for the Microsoft 365 Search workflow integration.
 *
 * All properties are optional. If they are omitted, the default values will be used.
 */
export interface MicrosoftSearchWorkflowConfig extends WorkflowConfig {
    /**
     * Configuration object for the HomeProvider.
     *
     * Use this to configure the HomeProvider for example, adding a custom logo or name.
     *
     * See {@link HomeProvider} for configuration options.
     */
    homeProvider?: DeepPartial<Omit<HomeProvider, 'onUserInput' | 'onResultDispatch'>>;
    /**
     * Configuration object for the Microsoft 365 entity types to include in the search results.
     *
     * Use this to enable/disable the different Microsoft 365 entity types.
     *
     * See {@link MicrosoftEntityTypeConfig} for configuration options.
     */
    microsoftEntityTypeConfig?: MicrosoftEntityTypeConfig;
    /**
     * The `msteams://` deep link can be used to open a Microsoft Teams chat in the Microsoft Teams desktop application.
     *
     * This _requires_ that the user has the Microsoft Teams desktop application installed. Else the call will silently fail.
     *
     * @default true
     */
    useTeamsDeepLink?: boolean;
}
export interface Microsoft365Workflows extends IntegrationWorkflows {
    /**
     * The Search workflow for the Microsoft 365 integration.
     *
     * This workflow is used to search for Microsoft 365 entities.
     *
     * To disable the Search workflow, set the disabled property in the workflow config to `false`.
     *
     * See {@link MicrosoftSearchWorkflowConfig} for configuration options.
     */
    search?: MicrosoftSearchWorkflowConfig;
}
export interface Microsoft365ConnectionConfig {
    /**
     * The client ID of the Microsoft 365 application.
     */
    clientId: string;
    /**
     * The tenant ID of the Microsoft 365 application.
     */
    tenantId: string;
    /**
     * The redirect URI of the Microsoft 365 application.
     */
    redirectUri: string;
}
/**
 * Configuration object for the Microsoft 365 workflow integration.
 */
export interface Microsoft365IntegrationConfig extends WorkflowIntegrationConfig {
    connect: Microsoft365ConnectionConfig;
    workflows?: Microsoft365Workflows;
}
