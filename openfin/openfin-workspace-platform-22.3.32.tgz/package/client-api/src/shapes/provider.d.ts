import { TaskbarIcon } from '../../../client-api-platform/src/shapes';
export interface ProviderInfo {
    /**
     * Unique identifier for the provider.
     *
     * @remarks A non-zero length string.
     */
    id: string;
    /**
     * A UI friendly title for the provider platform.
     */
    title: string;
    /**
     * Icon for the provider.
     */
    icon: string | TaskbarIcon;
    /**
     *  version of client SDK, set by the API
     */
    clientAPIVersion?: string;
    /**
     * The group name to group the taskbar icon with.
     */
    taskbarIconGroup?: string;
}
