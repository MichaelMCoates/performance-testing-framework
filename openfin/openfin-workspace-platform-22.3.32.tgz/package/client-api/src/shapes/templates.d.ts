/**
 *  OpenFin Workspace Custom Templates API
 *
 *  @module Templates
 */
import { SplitButton as SplitButtonTemplateData } from './home';
export type ListPairs = [string, string][];
export type CustomTemplateData = Record<string, string | ListPairs | SplitButtonTemplateData>;
export type ContainerFragmentTypes = PlainContainerTemplateFragment | ButtonTemplateFragment | SplitButtonFragment;
export type PresentationFragmentTypes = TextTemplateFragment | ImageTemplateFragment | ListTemplateFragment;
export type InteractiveFragmentTypes = ButtonTemplateFragment | TextTemplateFragment | ImageTemplateFragment;
/**
 * The options to build your custom template composition layout.
 */
export type TemplateFragment = PlainContainerTemplateFragment | ButtonTemplateFragment | TextTemplateFragment | ListTemplateFragment | ImageTemplateFragment | SplitButtonFragment;
export declare const ContainerTemplateFragmentNames: {
    readonly Container: "Container";
    readonly Button: "Button";
    readonly SplitButton: "SplitButton";
};
export declare const PresentationTemplateFragmentNames: {
    readonly Text: "Text";
    readonly Image: "Image";
    readonly List: "List";
};
export declare const TemplateFragmentTypes: {
    readonly Text: "Text";
    readonly Image: "Image";
    readonly List: "List";
    readonly Container: "Container";
    readonly Button: "Button";
    readonly SplitButton: "SplitButton";
};
export interface BaseTemplateFragment<T extends keyof typeof TemplateFragmentTypes> {
    /**
     * Type of the template fragment.
     */
    type: T;
    /**
     * CSS style properties of the fragment.
     *
     * All the available custom template fragments support all of the React's inline style properties (with camelCase keys)
     *
     * Note: "position: fixed" is disallowed as a fragment style.
     */
    style?: Record<string, string | number>;
}
export interface FragmentAction {
    /**
     * The action that will be dispatched back to provider when this fragment is clicked.
     *
     */
    action?: string;
    /**
     * The aria compliant description for this action.
     * If you leave this blank, the renderer will generate a generic description of
     * the fragment's type and its action.
     *
     */
    actionDescription?: string;
}
export interface ContainerTemplateFragment<T extends keyof typeof ContainerTemplateFragmentNames> extends BaseTemplateFragment<T> {
    /**
     * Sub-fragments of the container.
     *
     * You can use container template fragment to create nested composition structures.
     */
    children?: TemplateFragment[];
}
export interface PresentationTemplateFragment<T extends keyof typeof PresentationTemplateFragmentNames> extends BaseTemplateFragment<T> {
    /**
     * Optional flag.
     *
     * If a template fragment is flagged as optional, The service will not require
     * the fragment's `dataKey` to exist in `templateData`. If a fragment is optional and its data
     * is missing, the fragment will be omitted quietly by the renderer.
     */
    optional?: boolean;
    /**
     * Data key of the template fragment.
     *
     * The data associated with this fragment will be looked up in `templateData` map with this key.
     *
     * Example:
     * ```ts
     * const myTemplateLayout = {
     *    type: FragmentTypes.Text,
     *    dataKey: 'info',
     * }
     *
     * const searchResult: CLISearchResultCustom = {
     *     //...
     *     template: CLITemplate.Custom,
     *     templateContent: {
     *         layout: myTemplateLayout,
     *         data: {
     *             info: 'My Custom Search Result Info',
     *         }
     *     }
     * };
     * ```
     *
     */
    dataKey: string;
}
/**
 * Some common stylization options for the `Button` component.
 */
export declare enum ButtonStyle {
    Primary = "primary",
    Secondary = "secondary",
    TextOnly = "textOnly"
}
export type SplitButtonStyle = Extract<ButtonStyle, ButtonStyle.Primary | ButtonStyle.Secondary>;
export type PlainContainerTemplateFragment = ContainerTemplateFragment<'Container'>;
export type ButtonTemplateFragment = ContainerTemplateFragment<'Button'> & FragmentAction & {
    /**
     * Style of the button emitted by this fragment.
     */
    buttonStyle?: ButtonStyle;
};
export type SplitButtonFragment = ContainerTemplateFragment<'SplitButton'> & {
    /**
     * Determines the styling of the split button.
     */
    buttonStyle: SplitButtonStyle;
    /**
     * Data key of the template fragment.
     *
     * The data associated with this fragment will be looked up in `templateData` map with this key.
     *
     * Example:
     * ```ts
     * const myTemplateLayout = {
     *    type: FragmentTypes.SplitButton,
     *    buttonStyle: ButtonStyle.Primary,
     *    dataKey: 'splitButton1',
     * }
     *
     * const searchResult: CLISearchResultCustom = {
     *    //...
     *    template: CLITemplate.Custom,
     *    templateContent: {
     *        layout: myTemplateLayout,
     *        data: {
     *          splitButton1: {
     *              label: 'Split Button 1',
     *              tooltip: 'Click me',
     *              icon: 'iconURL',
     *              action: 'primaryAction',
     *              options: [
     *                  {
     *                      label: 'Menu Option 1',
     *                      tooltip: 'Click for optionAction1',
     *                      action: 'optionAction1'
     *                  },
     *                  {
     *                      label: 'Menu Option 2',
     *                      tooltip: 'Click for optionAction2',
     *                      action: 'optionAction1'
     *                  }
     *              ]
     *        }
     *    }
     * };
     * ```
     *
     */
    dataKey: string;
};
export type TextTemplateFragment = PresentationTemplateFragment<'Text'> & FragmentAction;
export type ImageTemplateFragment = PresentationTemplateFragment<'Image'> & FragmentAction & {
    /**
     * Alternative (accessibility) text for the image.
     */
    alternativeText: string;
};
export type ListTemplateFragment = PresentationTemplateFragment<'List'>;
export interface CustomTemplate {
    /**
     * Root of the template composition tree. See {@link ContainerTemplateFragment} for nesting.
     */
    layout: TemplateFragment;
    /**
     * Data associated with the custom search result template's presentation fragments.
     */
    data: CustomTemplateData;
}
