import { WorkspacePlatformModule } from '../../../client-api-platform/src/shapes';
export interface WorkflowConfig extends Record<string, unknown> {
    /**
     * If false, will automatically initialize the workflow when the Workspace Platform is initialized.
     * Else, will need to be initialized by calling initializeWorkflow.
     *
     * @default false
     */
    disableAutoInitialize?: boolean;
    /**
     * If true, will disable this workflow.
     * @default false
     */
    disabled?: boolean;
}
export interface IntegrationWorkflows {
    [key: string]: WorkflowConfig;
}
export interface WorkflowDependencies {
    workspacePlatformAPI: WorkspacePlatformModule;
}
export interface WorkflowIntegrationConfig {
    connect: unknown;
    workflows?: IntegrationWorkflows;
}
export interface WorkflowIntegration {
    /**
     * Name of the Workflow Integration
     * @example "Microsoft365"
     */
    workflowIntegrationName: string;
    /**
     * The config for the Workflow Integration
     */
    config: WorkflowIntegrationConfig;
    connect: (config?: any) => Promise<void>;
    initializeWorkflow: (workflow: string) => Promise<void>;
    _initializeWorkflows: (config?: WorkflowIntegrationConfig) => Promise<void>;
}
export declare abstract class BaseWorkflowIntegration {
    #private;
    workflowIntegrationName: string;
    config: WorkflowIntegrationConfig;
    constructor(config: WorkflowIntegrationConfig);
    _initializeWorkflows: (config?: WorkflowIntegrationConfig) => Promise<void>;
    initializeWorkflow(workflow: string): Promise<void>;
}
