/**
 * Use relative paths here rather than aliases which mess
 * up the packaged typing files. When writing code examples,
 * for documentation, please use async/await syntax over .then()!
 */
import { CustomButtonConfig, RegistrationMetaInfo } from './common';
import { ProviderInfo } from './provider';
/**
 * Describes the type of the app directory entry `manifest` attributes.
 * Launch mechanics are determined by the manifest type.
 */
export declare enum AppManifestType {
    /**
     * A snapshot manifest.
     */
    Snapshot = "snapshot",
    /**
     * A classic OpenFin app manifest.
     */
    Manifest = "manifest",
    /**
     * A view manifest.
     */
    View = "view",
    /**
     * A manifest for an external application.
     */
    External = "external"
}
export interface AppIntent {
    name: string;
    displayName: string;
    contexts: string[];
}
/**
 * Detailed metadata describing an image.
 */
export interface Image {
    src: string;
    type?: string;
    size?: string;
    purpose?: string;
}
/**
 * Store custom button configuration
 */
export interface StoreButtonConfig extends Omit<CustomButtonConfig, 'tooltip' | 'iconUrl'> {
    title: string;
}
/**
 * Detailed metadata describing an application.
 */
export interface App {
    /**
     * Unique identifier for an application.
     */
    appId: string;
    /**
     * A UI friendly title for the application.
     */
    title: string;
    /**
     * Custom tooltip on the Store App Card Container.
     *
     * @default - title of App Card
     */
    tooltip?: string;
    /**
     * URL to application manifest.
     */
    manifest?: string;
    /**
     * UI friendly description for an application.
     */
    description?: string;
    /**
     * Describes the type of manifest resolved by the `manifest` field.
     * Launch mechanics are determined by the manifest type.
     */
    manifestType?: AppManifestType | string;
    /**
     * A list of icons that can be rendered in UI for this application.
     */
    icons: Image[];
    /**
     * A list of optional images that highlight application functionality.
     */
    images?: Image[];
    /**
     * Primary button configuration.
     */
    primaryButton?: StoreButtonConfig;
    /**
     * Array of secondary button configurations.
     */
    secondaryButtons?: StoreButtonConfig[];
    intents?: AppIntent[];
    tags?: string[];
    version?: string;
    publisher: string;
    contactEmail?: string;
    supportEmail?: string;
}
export declare enum StorefrontTemplate {
    LandingPage = "landingPage",
    AppGrid = "appGrid"
}
/**
 * Represents a link to be rendered inside Storefront.
 */
export interface StorefrontLink {
    /**
     * A UI friendly title to render the link as.
     */
    title: string;
    /**
     * When the rendered `title` text is clicked, the user will be navigated to this URL.
     */
    url: string;
}
export interface StorefrontFooter {
    /**
     * A logo to be displayed on the Storefront's footer.
     */
    logo: Image;
    /**
     * A set of links to display on Storefront's footer.
     */
    links: [StorefrontLink?, StorefrontLink?, StorefrontLink?];
    text: string;
}
/**
 * Render a navigation section on the left panel of Storefront.
 */
export interface StorefrontNavigationSection {
    /**
     * Unique identifier for the navigation section.
     */
    id: string;
    /**
     * The UI friendly title of the navigation section.
     */
    title: string;
    /**
     * Navigation items to render under this section.
     * 1-5 Navigation Items are supported.
     */
    items: [
        StorefrontNavigationItem,
        StorefrontNavigationItem?,
        StorefrontNavigationItem?,
        StorefrontNavigationItem?,
        StorefrontNavigationItem?
    ];
}
/**
 * Represents the existing StorefrontDetailedNavigationItem and existing App interfaces
 * Used by StorefrontLandingPage to represent items in the bottom, middle and top rows.
 */
export type StorefrontLandingPageItem = StorefrontDetailedNavigationItem | App;
export type StorefrontLandingPageTopRow = [
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?
];
export type StorefrontLandingPageMiddleRow = [
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?
];
export type StorefrontLandingPageBottomRow = [
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?,
    StorefrontLandingPageItem?
];
export interface StorefrontLandingPage {
    hero?: {
        title: string;
        description: string;
        cta: StorefrontNavigationItem;
        image: Image;
    };
    topRow: {
        title: string;
        items: StorefrontLandingPageTopRow;
    };
    middleRow: {
        title: string;
        apps: StorefrontLandingPageMiddleRow;
    };
    bottomRow: {
        title: string;
        items: StorefrontLandingPageBottomRow;
    };
}
/**
 * Render a grid of applications in Storefront.
 */
export interface StorefrontAppGrid {
    /**
     * The apps to render in the grid.
     */
    apps: App[];
}
export interface StorefrontNavigationItemBase {
    /**
     * An ID for referencing the navigation item. Must be unique.
     */
    id: string;
    /**
     * UI friendly name for the navigation item.
     */
    title: string;
}
export interface StorefrontNavigationItemDetails {
    description: string;
    image: Image;
    buttonTitle?: string;
    tooltip?: string;
}
/**
 * Template for rendering a navigation item that renders a app grid when clicked.
 */
export interface StorefrontNavigationItemAppGrid extends StorefrontNavigationItemBase {
    templateId: StorefrontTemplate.AppGrid;
    /**
     * Render an app grid when navigation item is pressed.
     */
    templateData: StorefrontAppGrid;
}
export interface UpdateButtonConfigRequest {
    appId: string;
    primaryButton: StoreButtonConfig;
    secondaryButtons: StoreButtonConfig[];
}
/**
 * Response from store registration which includes metadata and a function to update app cards buttons.
 */
export interface StoreRegistration extends RegistrationMetaInfo {
    /**
     * Function to updates app card button config.
     * @example Updating primary button title and disabled flag.
     * @param request object that contains primary button and secondary buttons configs that will be
     * used to update button configuration returned by provider for an app.
     *
     * @example Updating primary button title and disabled flag.
     *
     * ```ts
     *  let storeRegistration: StoreRegistration | undefined;
     *
     *  await WorkspacePlatform.init({
     *      customActions: {
     *          storeButtonCustomActionHandler: async (payload: StoreCustomButtonActionPayload) => {
     *              if (storeRegistration) {
     *                  await storeRegistration.updateAppCardButtons({
     *                      appId: payload.appId,
     *                          primaryButton: {
     *                              ...payload.primaryButton,
     *                              title: 'Disabled Button',
     *                              disabled: true,
     *                          },
     *                       secondaryButtons: payload.secondaryButtons
     *                  });
     *              }
     *          }
     *      }
     *  });
     *
     *  const sampleApp: App = {
     *      title: 'Sample Application',
     *      addId: 'sampleAppId',
     *      icons: [],
     *      publisher: 'Sample',
     *      primaryButton: {
     *          title: 'Sample Button',
     *          action: {
     *          id: 'storeButtonCustomActionHandler',
     *          }
     *       }
     *  },
     *
     *  const storefrontProvider: StorefrontProvider = {
     *      title: 'Sample Store',
     *      id: 'sampleStoreId',
     *      icon: {...},
     *      getApps: () => Promise.resolve([sampleApp]),
     *      getLandingPage: {...},
     *      getNavigation: {...},
     *      getFooter: {...},
     *      launchApp: (app: App) => WR.getCurrentSync().launchApp({app})
     * };
     *
     *  storeRegistration = await Store.register(storefrontProvider);
     *  await Store.show();
     *
     *  ```
     */
    updateAppCardButtons: (request: UpdateButtonConfigRequest) => Promise<void>;
}
/**
 * Template for rendering a navigation item that renders another landing page when clicked.
 */
export interface StorefrontNavigationItemLandingPage extends StorefrontNavigationItemBase {
    templateId: StorefrontTemplate.LandingPage;
    /**
     * Render a landing page when navigation item is pressed.
     */
    templateData: StorefrontLandingPage;
}
/**
 * Render an item in the navigation bar of Storefront.
 */
export type StorefrontNavigationItem = StorefrontNavigationItemAppGrid | StorefrontNavigationItemLandingPage;
/**
 *  Render an item in the navigation bar of Storefront with a description and image.
 */
export type StorefrontDetailedNavigationItem = StorefrontNavigationItem & StorefrontNavigationItemDetails;
/**
 * Describes a Storefront provided by a platform.
 * A platform must provide an object that satisfies this interface in order to register with the Storefront.
 *
 * <h3>Sample StorefrontProvider definition.</h3>
 *
 * @example **Registering a StorefrontProvider**
 *
 * Import required dependencies.
 * ```ts
 * import { Storefront, StorefrontProvider } from '@openfin/workspace';
 * ```
 *
 * Create provider object to configure `Storefront`.
 *
 * ```ts
 * const provider: StorefrontProvider = {
 *   id: 'provider-id',
 *   title: 'Sample Storefront',
 *   icon: 'https://www.openfin.co/favicon-32x32.png',
 *   getApps: () => { }, // Get apps to populate the platform's storefront
 *   getNavigation: () => {...}, // Get navigation selections for the left navigation bar
 *   getLandingPage: () => {...}, // Get main landing page for platform's storefront
 *   getFooter: () => {...}, // Get footer for the platform's storefront
 *   launchApp: () => {...}, // Launch an app provided by the platform's storefront
 * };
 * ```
 *
 * Register storefront ``provider`` object.
 * ```ts
 * await Storefront.register(provider);
 * ```
 */
export interface StorefrontProvider extends ProviderInfo {
    /**
     * Store button visibility status
     *
     * @default 'visible'
     */
    buttonVisibility?: 'hidden' | 'visible';
    /**
     * Behavior of app card when it is clicked
     *
     * @default 'show-app-details'
     */
    cardClickBehavior?: 'show-app-details' | 'perform-primary-button-action';
    /**
     * Get a list of apps to populate the platform's Storefront with.
     *
     * @example An example of a `getApps` implementation that returns a single app.
     *
     * ```ts
     * const app : App = {
     *      appId: 'uid'
     *      title: 'My App'
     *      manifest: `https://openfin-iex.experolabs.com/openfin/manifests/cash-flow.json`,
     *      icons: [
     *          {
     *              src: '/icon.png'
     *          }
     *      ],
     *      contactEmail: contact@email.com,
     *      supportEmail: support@email.com,
     *      publisher: 'My Publisher',
     *      tags: [],
     *      images: [],
     *      intents: []
     * }
     *
     * const getApps = async (): Promise<App[]> => {
     *      return [app];
     * }
     * ```
     */
    getApps(): Promise<App[]>;
    /**
     * Get the main landing page for the platform's Storefront.
     *
     * @example Landing page with hero, top row, middle row, and bottom row.
     *
     * ```ts
     * const landingPage : StorefrontLandingPage = {
     *   hero: {
     *      title: 'My Landing Page',
     *      description: 'description',
     *      cta: navigationItems[0],
     *      image: {
     *          src: './images/image.png'
     *      }
     *   },
     *   topRow: {
     *       title: 'Top Row Title',
     *       items: [ /* array of StorefrontNavigationItem *\/ ]
     *   },
     *   middleRow: {
     *       title: 'Middle Row Title',
     *       items: [ /* array of Apps *\/ ]
     *   },
     *   bottomRow: {
     *       title: 'Bottom Row Title',
     *       items: [ /* array of StorefrontNavigationItem *\/ ]
     *   }
     * }
     *
     * const getLandingPage = async (): Promise<StorefrontLandingPage> => {
     *      return landingPage;
     * }
     *```
     */
    getLandingPage(): Promise<StorefrontLandingPage>;
    /**
     * Get the Storefront navigation sections for the left nav bar.
     *
     * @example An example of a navigation section with a title and navigation items.
     *
     * ```ts
     * const navigationSections: [StorefrontNavigationSection, StorefrontNavigationSection] = [
     *   {
     *       id: 'first id',
     *       title: 'title',
     *       items: [ /* array of navigation items *\/ ]
     *   },
     *   {
     *       id: 'second id'
     *       title: 'title',
     *       items: [ /* array of navigation items *\/ ]
     *   }
     * ]
     *
     * const getNavigation = async (): Promise<[StorefrontNavigationSection, StorefrontNavigationSection]>  => {
     *      return navigationSections;
     * }
     *```
     */
    getNavigation(): Promise<[
        StorefrontNavigationSection?,
        StorefrontNavigationSection?,
        StorefrontNavigationSection?
    ]>;
    /**
     * Get the footer for the platform's Storefront.
     *
     * The footer is a section displayed at the bottom of the Storefront. It can contain a logo, text, and links.
     *
     *
     * @example An example implementation of `getFooter`:
     *
     * ```ts
     * const footer: StorefrontFooter = {
     *      logo: { src: './images/image', size: '32' },
     *      text: 'footer text',
     *      links: [
     *          { title:'title', url: 'https://openfin.co' },
     *          { title: 'title', url: 'https://openfin.co'}
     *      ]
     * }
     *
     * const getFooter = async (): Promise<StorefrontFooter> => {
     *      return footer;
     * }
     * ```
     */
    getFooter(): Promise<StorefrontFooter>;
    /**
     * Launch an app provided by the platform's Storefront.
     *
     *
     * @example An example implementation of `launchApp`:
     * ```ts
     * import { getStorefrontProvider } from "./my-provider";
     *
     * //Grab your provider
     * const myStoreFrontProvider: StorefrontProvider = getStorefrontProvider();
     *
     * const app : App = {
     *      appId: 'uid'
     *      title: 'My App'
     *      manifest: `https://openfin-iex.experolabs.com/openfin/manifests/cash-flow.json`,
     *      icons: [
     *          {
     *              src: './image.png'
     *          }
     *      ],
     *      contactEmail: contact@email.com,
     *      supportEmail: support@email.com,
     *      publisher: 'My Publisher',
     *      tags: [],
     *      images: [],
     *      intents: []
     * }
     *
     * const launch = async () => {
     *      await myStorefrontProvider.launchApp(app);
     * }
     * ```
     * @param app the app to launch.
     *
     * @returns a promise that resolves when the app has been launched.
     */
    launchApp(app: App): Promise<void>;
}
