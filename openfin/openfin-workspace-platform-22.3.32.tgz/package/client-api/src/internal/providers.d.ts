import { ProviderType } from '../../../common/src/api/provider';
export declare class ProviderNotRegisteredError extends Error {
    constructor(providerType: ProviderType, id?: string);
}
export declare class ProviderAlreadyRegisteredError extends Error {
    constructor(providerType: ProviderType, id?: string);
}
export declare class FailedToGetProviderError extends Error {
    constructor(providerType: ProviderType, id?: string);
}
/**
 * Utility class for managing providers.
 */
export declare class ProvidersMap<T extends {
    id: string;
}> {
    private readonly providersMap;
    private readonly providerType;
    constructor(providerType: ProviderType);
    /**
     * Asserts that a provider is not already registered.
     * @param provider The provider to check.
     * @throws ProviderAlreadyRegisteredError if the provider already exists.
     */
    assertNotAlreadyRegistered(id: string): void;
    /**
     * Asserts that a provider is registered.
     * @param provider The provider to check.
     * @throws ProviderAlreadyRegisteredError if the provider already exists.
     */
    assertRegistered(id: string): void;
    /**
     * Gets a provider by id.
     * @param id The id of the provider to get.
     * @returns The provider if it exists, otherwise undefined.
     */
    getProvider(id: string): T | undefined;
    /**
     * Checks if a provider exists.
     * @param id The id of the provider to check.
     * @returns True if the provider exists, otherwise false.
     */
    hasProvider(id: string): boolean;
    /**
     * Sets a provider.
     * @param provider The provider to set.
     */
    setProvider(provider: T): void;
    /**
     * Deletes a provider.
     * @param id The id of the provider to delete.
     */
    deleteProvider(id: string): void;
    /**
     * Gets a provider by id or throws an error if it does not exist.
     * @param id The id of the provider to get.
     * @returns The provider if it exists.
     * @throws An error if the provider does not exist.
     * @see {@link ProviderNotRegisteredError}
     */
    getProviderOrFail(id: string): T;
    clearProviders(): void;
}
