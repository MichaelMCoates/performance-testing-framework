import type { InternalSearchListenerRequest } from '../../../../common/src/api/shapes/home';
/**
 * Map of search requests.
 */
export declare const searchRequests: Map<string, InternalSearchListenerRequest>;
