import { withDisconnectListener } from '../../../../../common/src/utils/channels';
import { SearchAPIClientChannelClient } from '../../../../../common/src/api/protocol/shapes/search';
type HomeWorkspaceAPIClientChannelClient = withDisconnectListener<SearchAPIClientChannelClient> & {
    homeChannelActionsRegistered?: boolean;
};
export declare function registerHomeChannelClientActions(channel: HomeWorkspaceAPIClientChannelClient): void;
export {};
