import { HomeClientApiDataRequest, HomeInternalDataResponse, HomeInternalErrorResponse, InternalDataResponse } from '../../../../../common/src/api/shapes/home';
export declare function pushDataResponse(res: InternalDataResponse): Promise<void>;
export declare function handleDataRequest(req: HomeClientApiDataRequest): Promise<HomeInternalDataResponse | HomeInternalErrorResponse>;
