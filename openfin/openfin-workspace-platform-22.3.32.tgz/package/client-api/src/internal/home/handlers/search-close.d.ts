import type { HomeClientApiSearchCloseRequest } from '../../../../../common/src/api/shapes/home';
/**
 * Listens for search requests that have been closed.
 */
export declare function handleSearchRequestClose(req: HomeClientApiSearchCloseRequest): void;
