import type OpenFin from '@openfin/core';
import type { HomeClientApiDispatchRequest } from '../../../../../common/src/api/shapes/home';
export declare function handleResultDispatch(req: HomeClientApiDispatchRequest, identity: OpenFin.Identity): Promise<void>;
