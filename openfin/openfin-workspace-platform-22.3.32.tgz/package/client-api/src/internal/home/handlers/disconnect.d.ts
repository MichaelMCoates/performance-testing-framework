export declare function handleChannelDisconnection(): Promise<void>;
