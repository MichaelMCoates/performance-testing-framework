import { ProvidersMap } from '../../../../client-api/src/internal/providers';
import { RegisterMetaInfoInternal, StorefrontProvider } from '../../../../client-api/src/shapes';
export declare const StorefrontProviders: ProvidersMap<StorefrontProvider>;
export declare const registerStorefrontProviderInternal: (provider: StorefrontProvider) => Promise<RegisterMetaInfoInternal>;
