import { WorkspaceAPIClientChannelClient } from '../../../../common/src/api/protocol/workspace';
type StorefrontWorkspaceAPIClientChannelClient = WorkspaceAPIClientChannelClient & {
    storefrontChannelActionsRegistered?: boolean;
};
/**
 *  Registers a channel action for each function in the Storefront provider.
 */
export declare const registerStorefrontChannelClientActions: (channel: StorefrontWorkspaceAPIClientChannelClient) => void;
export {};
