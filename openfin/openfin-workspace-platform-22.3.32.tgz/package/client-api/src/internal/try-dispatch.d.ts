import { WorkspaceChannelAction } from '../../../common/src/api/protocol/shapes/workspace';
export interface ChannelDispatch {
    action: WorkspaceChannelAction;
    payload?: any;
}
/**
 * A utility method to handle deprecated channel events.
 * It will try to dispatch the channel action provided with the action parameter.
 * If the dispatch fails and the failure reason is that the action is not registered with the channel provider,
 * it will dispatch the action provided with the fallback parameter.
 * @param action The contemporary action for the provider.
 * @param fallback The deprecated action for the provider.
 * @param fallbackResponse optional response for the fallback action.
 * @returns channel response is returned if action was successful. If fallback was used, fallbackResponse is returned instead.
 */
export declare function tryDispatch(action: ChannelDispatch, fallback: ChannelDispatch): Promise<void>;
export declare function tryDispatch<T = undefined>(action: ChannelDispatch, fallback: ChannelDispatch, fallbackResponse: T): Promise<T>;
