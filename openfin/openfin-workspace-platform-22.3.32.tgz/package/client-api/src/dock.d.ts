import type { DockProvider } from './shapes/dock';
import { type DockProviderRegistration } from './shapes/dock';
export * from './shapes/dock';
/**
 * API function to register a Dock provider.
 *
 * @remarks A Workspace Platform must be initialized.
 *
 * @throws An error if the Workspace Platform is not initialized.
 * @throws An error if a Dock provider for this Workspace Platform is already registered.
 * @throws An error if the Dock provider configuration contains buttons with duplicate ids. If no ids are specified, the buttons will be assigned ids automatically.
 *
 * @param provider - The Dock provider to register.
 *
 * @returns A promise that resolves with a `DockProviderRegistration` object once the Dock provider is successfully registered. This contains the client API version, Workspace Version and a function to update the Dock provider configuration.
 *
 * @example Register a Dock provider with a single button.
 *
 * ```ts
 * import { Dock, type DockProvider } from '@openfin/workspace';
 *
 * const provider: DockProvider = {
 *      id: 'provider-id',
 *      title: 'Sample Dock',
 *      icon: 'https://www.openfin.co/favicon-32x32.png',
 *      buttons: [
 *           {
 *              tooltip: 'Sample Button 1',
 *              iconUrl: 'https://www.openfin.co/favicon-32x32.png',
 *               action: {
 *                   id: 'sampleButton1'
 *               }
 *           }
 *       ]
 * };
 *
 * await Dock.register(provider)
 *
 * await Dock.show()
 * ```
 */
export declare const register: (provider: DockProvider) => Promise<DockProviderRegistration>;
/**
 * API function to deregister a Dock provider.
 *
 * @remarks A Workspace Platform must be initialized, and the Dock provider must be registered for this function to take effect.
 *
 * @throws an error if the provider is not registered.
 *
 * @returns a promise that resolves once the Dock provider is successfully deregistered.
 *
 * @example Deregister a Dock provider.
 *
 * ```ts
 * import { Dock } from '@openfin/workspace';
 *
 * await Dock.deregister();
 * ```
 */
export declare const deregister: () => Promise<void>;
/**
 * API function to minimize the Dock UI.
 *
 * @remarks A Workspace Platform must be initialized, and at least one Dock provider must be registered for this function to take effect.
 *
 * @returns a promise that resolves once the Dock UI is minimized
 *
 * @example Minimize a Dock provider.
 *
 * ```ts
 * import { Dock } from '@openfin/workspace';
 *
 * await Dock.minimize();
 * ```
 */
export declare const minimize: () => Promise<void>;
/**
 * API function to show the Dock UI.
 *
 * @remarks A Workspace Platform must be initialized, and at least one Dock provider must be registered for this function to take effect.
 *
 * @returns a promise that resolves once the Dock UI is shown
 *
 * @example Show a Dock provider.
 *
 * ```ts
 * import { Dock } from '@openfin/workspace';
 *
 * await Dock.show();
 * ```
 */
export declare const show: () => Promise<void>;
