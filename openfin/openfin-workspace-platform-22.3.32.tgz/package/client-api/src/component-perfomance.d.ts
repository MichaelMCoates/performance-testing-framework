import type OpenFin from '@openfin/core';
type ComponentNames = 'home' | 'dock' | 'store';
export declare const setupComponentPerformance: (component: ComponentNames, componentWindowIdentity: OpenFin.Identity) => Promise<void>;
export {};
