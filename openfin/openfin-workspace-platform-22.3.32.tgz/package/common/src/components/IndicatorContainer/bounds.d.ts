import type OpenFin from '@openfin/core';
import { IndicatorBounds, IndicatorOptions, WindowSize } from './types';
/**
 * Gets the bounds of the parent window, with fallback to provided bounds.
 */
export declare const getParentWindowBounds: (parentWindow: OpenFin.Window | false, parentWindowBounds?: OpenFin.WindowBounds) => Promise<OpenFin.WindowBounds | undefined>;
/**
 * Checks if a window is maximized.
 */
export declare const isWindowMaximized: (parentWindow: OpenFin.Window | false) => Promise<boolean>;
/**
 * Pure function – returns the final indicator rectangle, nothing else.
 */
export declare function computeIndicatorBounds(identity: OpenFin.Identity | null | undefined, mySize: WindowSize, opts: IndicatorOptions): Promise<IndicatorBounds>;
