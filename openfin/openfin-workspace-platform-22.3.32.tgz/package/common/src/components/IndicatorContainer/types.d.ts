import type OpenFin from '@openfin/core';
import { PositioningType } from '../../../../common/src/utils/positioning';
export declare enum ShowAtType {
    Top = "top",
    Below = "below"
}
export interface IndicatorOptions {
    /**
     * Where to place the indicator relative to its parent.
     */
    showAt: ShowAtType;
    /**
     * When `true`, we use the "enterprise" timing + vertical offset rules.
     */
    isEnterprise: boolean;
    /**
     * The bounds of the parent window if the parent is not available at
     * runtime (e.g. the browser window launched the indicator and closed).
     */
    fallbackParentBounds?: OpenFin.WindowBounds;
    /**
     * Determines whether to position relative to parent window or monitor.
     */
    positioning?: PositioningType;
}
export interface IndicatorBounds {
    left: number;
    top: number;
    width: number;
    height: number;
}
export interface WindowSize {
    width: number;
    height: number;
}
