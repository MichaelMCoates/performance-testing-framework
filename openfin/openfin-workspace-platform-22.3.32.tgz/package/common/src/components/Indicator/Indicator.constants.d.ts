/**
 * Here we define an Indicator only explicitly by needing an ID for reference over the wire.
 * Type and message are meant to provide actual context and meaning to an indicator, but
 * they are not required in the case of destroying an existing indicator.
 */
export interface Indicator {
    id: string;
    type?: IndicatorType;
    message?: string;
}
/**
 * Indicator types are meant to provide additional context to the indicator.
 */
export type IndicatorType = 'error' | 'success' | 'info';
