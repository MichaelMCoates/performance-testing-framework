import type OpenFin from '@openfin/core';
import { HomeSearchListenerRequest, SetSearchQueryOptions } from '../../../client-api/src/shapes';
export interface SearchQueryWithProviderID {
    providerID: string;
    query: string;
    options?: SetSearchQueryOptions;
}
export interface SearchQueryWithProviderIdentity {
    providerID: string;
    platformIdentity: OpenFin.Identity;
    query: string;
    options?: SetSearchQueryOptions;
}
/**
 * The ids of home providers that are built into Home.
 */
export declare enum HomeBuiltInProviderID {
    /**
     * Built in Home provider that provides commands.
     */
    Commands = "home-commands"
}
/**
 * Assign a search context to Home.
 * @param ctx the search context to assign.
 */
export declare function assignHomeSearchContext(ctx: Partial<HomeSearchListenerRequest['context']>): Promise<void>;
