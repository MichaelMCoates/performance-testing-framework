import type OpenFin from '@openfin/core';
export interface Workspace {
    workspaceId: string;
    title: string;
    snapshot: OpenFin.Snapshot;
}
export declare const getLegacyWorkspaces: () => Promise<Workspace[]>;
