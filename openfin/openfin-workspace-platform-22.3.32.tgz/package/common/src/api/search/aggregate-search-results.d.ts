import type { HomeSearchResult, ScoreOrder } from '../../../../client-api/src/shapes';
/**
 * Aggregates and sorts the search results from old and new result arrays.
 *
 * @param oldResults - An array of existing `HomeSearchResult` objects.
 * @param newResults - An array of new `HomeSearchResult` objects to be merged with the existing results.
 * @param order - The order in which to sort the results based on their scores ('ascending' or 'descending'). Default is 'ascending'.
 * @returns An array of `HomeSearchResult` objects containing the merged and sorted search results.
 */
export declare function aggregate(oldResults?: HomeSearchResult[], newResults?: HomeSearchResult[], order?: ScoreOrder): HomeSearchResult[];
