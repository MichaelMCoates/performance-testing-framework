import { HomeSearchListenerResponse, HomeSearchResult, ScoreOrder } from '../../../../client-api/src/shapes';
import { InternalSearchListenerRequest, InternalSearchListenerResponseStatus, SearchRequest } from '../shapes/home';
export interface InternalSearchListenerResponse {
    getResultBuffer(): HomeSearchResult[];
    setResultBuffer(results: HomeSearchResult[]): void;
    getRevokedBuffer(): string[];
    setRevokedBuffer(resultIds: string[]): void;
    getUpdatedContext(): any;
    setUpdatedContext(context: any | null): void;
    onChange(): void;
    getStatus(): InternalSearchListenerResponseStatus;
    res: HomeSearchListenerResponse;
}
export declare function makeInternalSearchListenerResponse(scoreOrder?: ScoreOrder): InternalSearchListenerResponse;
export declare function makeInternalSearchListenerRequest(id: string, req: SearchRequest): InternalSearchListenerRequest;
