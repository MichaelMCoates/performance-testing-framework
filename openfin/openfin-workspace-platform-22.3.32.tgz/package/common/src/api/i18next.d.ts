import i18next, { type Resource } from 'i18next';
import { Locale } from '../../../client-api-platform/src/shapes';
declare function initI18next(language?: Locale): void;
export declare const setLanguageInI18next: (locale: Locale) => void;
declare const t: import("i18next").TFunction<["translation", ...string[]], undefined>;
export { initI18next, i18next, t, type Resource };
export { useTranslation } from 'react-i18next';
