interface StyleOverrides {
    iconUrl: string;
}
interface HotkeyOverrides {
    toggleHomeVisibility: string;
}
export interface Overrides {
    hotkeys: HotkeyOverrides;
    style: StyleOverrides;
    browserWindowTitle: string;
    flags: {
        [key: string]: boolean;
    };
    disableRuntimeValidation: boolean;
    browserBaseUrl: string;
    disableOpenFinAnalytics: boolean;
    analyticsEndpoint: string;
    translationOverridesUrl: string;
    /**
     * WRK-4846
     * This property is internal but is being temporarily exposed for Wells Fargo.
     * It will be removed once Workspace adopts the fix in Runtime version 38.
     */
    displayViewTabDefaultIcon: boolean;
}
export declare function getManifestOverrides(): Promise<Partial<Overrides>>;
export declare function getOverrides(): Promise<Partial<Overrides>>;
export {};
