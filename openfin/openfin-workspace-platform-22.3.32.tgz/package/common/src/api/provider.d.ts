import type OpenFin from '@openfin/core';
import type { RemoveFunctions } from '../../../common/src/utils/types';
import type { CLIProvider, DockProvider, HomeProvider, StorefrontProvider, WorkspaceButtonsConfig } from '../../../client-api/src/shapes';
interface WithIdentity {
    /**
     * The platform identity that registered the Storefront Provider.
     */
    platformIdentity: OpenFin.Identity;
    /**
     * Unique identifier for the provider.
     * Namespaced by platformIdentity to avoid collisions.
     */
    uniqueId: string;
}
export type ProviderType = 'storefront' | 'dock'
/**
 * Use with caution! This is not fully utilized everywhere in the codebase.
 */
 | 'home';
/**
 * The internal representation of the dock provider, which includes the identity of the provider
 * All functions on the DockProvider type are removed, as they are handled through OpenFin Channels
 *
 * The `platformIdentity` is added in the register call [here](../../../provider/src/api/provider.ts)
 */
export type DockProviderInternal = 
/**
 * Remove all functions from the StorefrontProvider type, as they are handled through OpenFin Channels
 */
RemoveFunctions<Omit<DockProvider, 'workspaceComponents'>> & {
    workspaceComponents: WorkspaceButtonsConfig;
} & WithIdentity;
/**
 * The internal representation of the storefront provider, which includes the identity of the provider
 * All functions on the StorefrontProvider type are removed, as they are handled through OpenFin Channels
 *
 * The `platformIdentity` is added in the register call [here](../../../provider/src/api/provider.ts)
 */
export type StorefrontProviderInternal = 
/**
 * Remove all functions from the StorefrontProvider type, as they are handled through OpenFin Channels
 */
RemoveFunctions<StorefrontProvider> & WithIdentity;
/**
 * The internal representation of the home provider, which includes the identity of the provider
 * All functions on the HomeProvider/CLIProvider type are removed, as they are handled through OpenFin Channels
 *
 * The `platformIdentity` is added in the register call [here](../../../provider/src/api/provider.ts)
 */
export type HomeProviderInternal = 
/**
 * Remove all functions from the StorefrontProvider type, as they are handled through OpenFin Channels
 */
(RemoveFunctions<HomeProvider> | RemoveFunctions<CLIProvider>) & WithIdentity;
/**
 * The internal representation of a provider, which includes the identity of the provider
 * This should be used anywhere within 'dock/*' or 'storefront/*' and most places within 'provider/*'
 * to ensure that the identity is included
 */
export type ProviderInfoInternal<T extends ProviderType = ProviderType> = T extends 'dock' ? DockProviderInternal : StorefrontProviderInternal;
export interface ProviderChannelPayload {
    providerType: ProviderType;
}
export type ProviderRegisterPayload = {
    providerType: 'dock';
    info: RemoveFunctions<DockProvider>;
} | {
    providerType: 'storefront';
    info: RemoveFunctions<StorefrontProvider>;
};
export interface ProviderDeregisterPayload extends ProviderChannelPayload {
    id: string;
}
export type ProviderConnectionPayload = {
    providerType: 'dock';
    provider: DockProviderInternal;
} | {
    providerType: 'storefront';
    provider: StorefrontProviderInternal;
};
export type ProviderDisconnectionPayload = {
    providerType: 'dock';
    provider: DockProviderInternal;
} | {
    providerType: 'storefront';
    provider: StorefrontProviderInternal;
};
export interface ProviderUpdatePayload {
    providerType: 'dock';
    provider: RemoveFunctions<DockProvider> | DockProviderInternal;
}
export interface ProviderUpdateEventPayload {
    providerType: 'dock';
    provider: DockProviderInternal;
}
/**
 * Gets a unique identifier for a provider, based on the provider's identity and the provider's id
 *
 * This allows for different providers to be registered with the same id.
 */
export declare const getUniqueProviderIdentifier: ({ platformIdentity, id }: Pick<ProviderInfoInternal, "platformIdentity" | "id">) => string;
/**
 * Get a list of all providers that have registered with the provider API.
 */
export declare const getProviders: <T extends ProviderType>(providerType: T) => Promise<ProviderInfoInternal<T>[]>;
/**
 * A function to dispatch showing the component window of current OF identity
 * @returns action to show Component Window
 */
export declare const showProviderWindow: (providerType: ProviderType) => Promise<void>;
/**
 * A function to dispatch hiding the component window of current OF identity
 * @returns action to hide Component Window
 */
export declare const hideProviderWindow: (providerType: ProviderType) => Promise<void>;
export {};
