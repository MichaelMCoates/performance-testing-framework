import type OpenFin from '@openfin/core';
import type { Awaitable } from '../../../../../common/src/utils/types';
import type { dockOFIdentity, homeOFIdentity, storefrontOFIdentity } from '../../../../../common/src/utils/window';
import type { SearchQueryWithProviderID, SearchQueryWithProviderIdentity } from '../../../../../common/src/api/home';
import type { ProviderChannelPayload, ProviderDeregisterPayload, ProviderInfoInternal, ProviderRegisterPayload, ProviderUpdatePayload } from '../../../../../common/src/api/provider';
import type { ClientAPILaunchStorefrontProviderAppRequest, LaunchStorefrontProviderAppRequest } from '../../../../../common/src/api/storefront';
import type { WorkspaceComponentSetSelectedSchemePayload } from '../../../../../common/src/api/theming';
import type { Workspace as LegacyWorkspace } from '../../../../../common/src/api/workspaces';
import type { HomeSearchListenerRequest } from '../../../../../client-api/src/home';
import type { RegisterMetaInfoInternal } from '../../../../../client-api/src/index';
import type { StorefrontFooter, StorefrontLandingPage, StorefrontNavigationSection, UpdateButtonConfigRequest } from '../../../../../client-api/src/store';
import type { App, ColorSchemeOptionType, Page } from '../../../../../client-api-platform/src/shapes';
export type WorkspaceChannelAction = keyof WorkspaceChannelTypes;
/****** API Client Channel Actions ******/
/**
 * Channel actions, related to store, **registered** by the Workspace Platform Provider e.g. Studio.
 */
type StoreAPIClientChannelActions = {
    'get-storefront-provider-apps': (id: string) => Promise<App[]>;
    'get-storefront-provider-footer': (id: string) => Promise<StorefrontFooter>;
    'get-storefront-provider-landing-page': (id: string) => Promise<StorefrontLandingPage>;
    'get-storefront-provider-navigation': (id: string) => Promise<[StorefrontNavigationSection?, StorefrontNavigationSection?, StorefrontNavigationSection?]>;
    'launch-storefront-provider-app': (payload: ClientAPILaunchStorefrontProviderAppRequest) => Promise<void>;
};
/**
 * Channel actions, related to dock, **registered** by the Workspace Platform Provider e.g. Studio.
 */
type DockAPIClientChannelActions = Record<string, never>;
/**
 * Channel actions, related to home, **registered** by the Workspace Platform Provider e.g. Studio.
 */
type HomeAPIClientChannelActions = Record<string, never>;
type WorkspaceAPIClientChannelActions = StoreAPIClientChannelActions | DockAPIClientChannelActions | HomeAPIClientChannelActions;
/****** End of API Client Channel Actions ******/
/****** Workspace Component Channel Actions ******/
/**
 * Channel Actions **registered** by all workspace components.
 */
type SharedChannelActions = {
    'set-selected-scheme': (ctx: WorkspaceComponentSetSelectedSchemePayload) => Promise<void>;
};
/**
 * Channel Actions **registered** by the Home workspace component.
 */
type HomeChannelActions = {
    'assign-home-search-context': (payload: Partial<HomeSearchListenerRequest['context']>) => Promise<void>;
    'open-home-and-set-search-query': (payload: SearchQueryWithProviderIdentity) => Promise<void>;
    'temporary-is-home-ready': () => Promise<boolean>;
};
/**
 * Channel Actions **registered** by the Storefront workspace component.
 */
type StoreChannelActions = {
    'update-app-card-button-config': (payload: UpdateButtonConfigRequest & ProviderInfoInternal<'storefront'>) => Promise<void>;
};
/**
 * Channel Actions **registered** by the Dock workspace component.
 */
interface DockChannelActions {
}
type WorkspaceComponentChannelActions = SharedChannelActions & HomeChannelActions & StoreChannelActions & DockChannelActions;
/****** End of Workspace Component Channel Actions ******/
/****** Workspace Provider Channel Actions ******/
/**
 * These are channel actions that can be accessed by the client API OR the workspace component.
 * In other words these are channel actions that are **registered** by the workspace provider.
 *
 * The handlers for these actions are defined [here](https://github.com/openfin/workspace/blob/develop/provider/src/api/protocol.ts#L32)
 */
type WorkspaceChannelTypes = {
    'register-provider': (payload: ProviderRegisterPayload) => RegisterMetaInfoInternal;
    'deregister-provider': (payload: ProviderDeregisterPayload) => Promise<void>;
    'get-providers': (payload: ProviderChannelPayload) => Promise<ProviderInfoInternal[]>;
    'show-provider-window': (payload: ProviderChannelPayload) => Promise<void>;
    'hide-provider-window': (payload: ProviderChannelPayload) => Promise<void>;
    'update-provider': (payload: ProviderUpdatePayload) => Promise<void>;
    'get-storefront-provider-apps': (payload: ProviderInfoInternal<'storefront'>) => Promise<App[]>;
    'get-storefront-provider-landing-page': (payload: ProviderInfoInternal<'storefront'>) => Promise<StorefrontLandingPage | undefined>;
    'get-storefront-provider-footer': (payload: ProviderInfoInternal<'storefront'>) => Promise<StorefrontFooter>;
    'get-storefront-provider-navigation': (payload: ProviderInfoInternal<'storefront'>) => Promise<Promise<[StorefrontNavigationSection?, StorefrontNavigationSection?]>>;
    'launch-storefront-provider-app': (payload: LaunchStorefrontProviderAppRequest) => Promise<void>;
    'update-app-card-button-config': (payload: UpdateButtonConfigRequest & Omit<ProviderInfoInternal<'storefront'>, 'uniqueId'>) => Promise<void>;
    'show-home': (payload: undefined) => Promise<void>;
    'hide-home': (payload: undefined) => Promise<void>;
    'set-search-query': (payload: SearchQueryWithProviderID) => Promise<void>;
    'assign-home-search-context': (payload: Partial<HomeSearchListenerRequest['context']>) => Promise<void>;
    'set-selected-scheme': (ctx: ColorSchemeOptionType) => Promise<void>;
    'get-legacy-pages': () => Promise<Page[]>;
    'get-legacy-workspaces': (payload: undefined) => Promise<LegacyWorkspace[]>;
    'register-storefront-provider': () => Promise<void>;
    'deregister-storefront-provider': () => Promise<void>;
    'hide-storefront': () => Promise<void>;
    'show-storefront': () => Promise<void>;
};
/****** End of Workspace Provider Channel Actions ******/
/**
 * This is a shared interface between the client API and the workspace components.
 *
 * Since all actions are dispatched to the channel provider, the `dispatch` function is the same for both the client API and the workspace components.
 */
interface WorkspaceChannelClientBase extends Omit<OpenFin.ChannelClient, 'dispatch' | 'register'> {
    /**
     * Dispatches an action to the Workspace Provider.
     * @param action The action to dispatch
     * @param payload The payload to send with the action
     */
    dispatch: <T extends WorkspaceChannelAction>(action: T, payload: Parameters<WorkspaceChannelTypes[T]>[0]) => Promise<Awaited<ReturnType<WorkspaceChannelTypes[T]>>>;
}
/**
 * This is the Workspace Component Channel Client.
 * This is used to communicate with the workspace provider from a workspace component (home, storefront, dock).
 *
 * This extends `WorkspaceChannelClientBase`.
 */
export interface WorkspaceComponentChannelClient extends WorkspaceChannelClientBase {
    /**
     * Registers a handler for a channel action.
     * @param action
     * @param handler
     * @returns
     */
    register: <T extends keyof WorkspaceComponentChannelActions>(action: T, handler: (payload: Parameters<WorkspaceComponentChannelActions[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Awaitable<ReturnType<WorkspaceComponentChannelActions[T]>>) => boolean;
}
/**
 * This is the Client API channel client.
 * This is used to communicate with the Workspace Provider from the client API. (`@openfin/workspace` / `client-api`)
 *
 * This extends `WorkspaceChannelClientBase`.
 */
export interface WorkspaceAPIClientChannelClient extends WorkspaceChannelClientBase {
    /**
     * Registers a handler for a channel action.
     * This function is ONLY used from within `client-api` and should not be used by the workspace components.
     *
     * @param action The action to register a handler for.
     * @param handler The handler to register.
     */
    register: <T extends keyof WorkspaceAPIClientChannelActions>(action: T, handler: (payload: Parameters<WorkspaceAPIClientChannelActions[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Awaitable<ReturnType<WorkspaceAPIClientChannelActions[T]>>) => boolean;
}
export interface WorkspaceChannelProvider extends Omit<OpenFin.ChannelProvider, 'register' | 'dispatch'> {
    /**
     * Used for dispatching a channel action to a channel client
     *
     * @param to The identity of the client to send the action to.
     * @param action The action to send.
     * @param payload The payload to send with the action.
     */
    dispatch: <I extends OpenFin.ClientIdentity | OpenFin.Identity, T extends I['name'] extends (typeof homeOFIdentity)['name'] ? keyof SharedChannelActions | keyof HomeChannelActions : I['name'] extends (typeof dockOFIdentity)['name'] ? keyof SharedChannelActions | keyof DockChannelActions : I['name'] extends (typeof storefrontOFIdentity)['name'] ? keyof SharedChannelActions | keyof StoreChannelActions : keyof SharedChannelActions | keyof WorkspaceAPIClientChannelActions>(to: I, action: T, payload: T extends keyof SharedChannelActions ? Parameters<SharedChannelActions[T]>[0] : I['name'] extends (typeof homeOFIdentity)['name'] ? T extends keyof HomeChannelActions ? Parameters<HomeChannelActions[T]>[0] : never : I['name'] extends (typeof dockOFIdentity)['name'] ? T extends keyof DockChannelActions ? Parameters<DockChannelActions[T]>[0] : never : I['name'] extends (typeof storefrontOFIdentity)['name'] ? T extends keyof StoreChannelActions ? Parameters<StoreChannelActions[T]>[0] : never : T extends keyof WorkspaceAPIClientChannelActions ? Parameters<WorkspaceAPIClientChannelActions[T]>[0] : never) => Promise<Awaited<I['name'] extends (typeof homeOFIdentity)['name'] ? T extends keyof HomeChannelActions ? ReturnType<HomeChannelActions[T]> : never : I['name'] extends (typeof dockOFIdentity)['name'] ? T extends keyof DockChannelActions ? ReturnType<DockChannelActions[T]> : never : I['name'] extends (typeof storefrontOFIdentity)['name'] ? T extends keyof StoreChannelActions ? ReturnType<StoreChannelActions[T]> : never : never>>;
    /**
     * Used for registering a channel action handler for a channel client
     *
     * @param action The action to register a handler for.
     * @param handler The handler to register.
     */
    register: <T extends WorkspaceChannelAction>(action: T, handler: (payload: Parameters<WorkspaceChannelTypes[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Awaitable<ReturnType<WorkspaceChannelTypes[T]>>) => boolean;
}
export {};
