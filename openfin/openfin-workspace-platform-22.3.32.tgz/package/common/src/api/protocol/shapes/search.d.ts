import OpenFin from '@openfin/core';
import { Awaitable, RemoveFunctions } from '../../../../../common/src/utils/types';
import { homeOFIdentity } from '../../../../../common/src/utils/window';
import type { HomeClientApiDataRequest, HomeClientApiDispatchRequest, HomeClientApiSearchCloseRequest, HomeInternalDataResponse, HomeInternalErrorResponse, InternalDataResponse, InternalDispatchRequest, InternalErrorResponse, InternalSearchRequest, InternalSearchResponse } from '../../../../../common/src/api/shapes/home';
import { HomeProvider } from '../../../../../client-api/src/home';
import { RegisterMetaInfoInternal } from '../../../../../client-api/src/index';
export declare const HomeChannelActions: {
    /**
     * The stream id that data is requested and transported back to the creator of a search topic on.
     */
    readonly remoteProviderDataStreamId: "0";
    /**
     * The stream id that handles search request to the creator of a search topic from remote client like views.
     */
    readonly remoteClientSearchStreamId: "1";
    /**
     * The stream id for registering a remote search provider with the creator of a search topic.
     */
    readonly remoteProviderRegistrationStreamId: "2";
    /**
     * The stream id for deregistering a remote search provider with the creator of a search topic.
     */
    readonly remoteProviderDeregistrationStreamId: "3";
    /**
     * The stream id for sharing remote search provider information with the creator of a search topic.
     */
    readonly remoteProviderInfoStreamId: "4";
    /**
     * The stream id for dispatching search results back to a remote search provider.
     */
    readonly remoteProviderDispatchStreamId: "5";
    /**
     * The stream id for notifying remote search providers that the request have closed.
     */
    readonly remoteSearchCloseStreamId: "6";
};
/**
 * Registered ON the Client API
 * Dispatched to by the Workspace Provider
 */
interface SearchAPIClientChannelActions {
    [HomeChannelActions.remoteProviderDataStreamId]: (req: HomeClientApiDataRequest, identity: OpenFin.Identity) => Promise<HomeInternalDataResponse | HomeInternalErrorResponse>;
    [HomeChannelActions.remoteSearchCloseStreamId]: (req: HomeClientApiSearchCloseRequest, identity: OpenFin.Identity) => void;
    [HomeChannelActions.remoteProviderDispatchStreamId]: (req: HomeClientApiDispatchRequest, identity: OpenFin.Identity) => Promise<void> | void;
}
type HomeChannelActions = Record<string, never>;
/**
 * Registered ON the WOrkspace Provider
 * Dispatched to by Client API OR by Home.
 */
type SearchProviderChannelActions = {
    [HomeChannelActions.remoteProviderDataStreamId]: (req: InternalDataResponse, identity: OpenFin.Identity) => void | Promise<void>;
    [HomeChannelActions.remoteClientSearchStreamId]: (req: InternalSearchRequest, identity: OpenFin.Identity) => Promise<InternalSearchResponse | InternalErrorResponse>;
    [HomeChannelActions.remoteProviderDeregistrationStreamId]: (providerId: string, identity: OpenFin.Identity) => Promise<void>;
    [HomeChannelActions.remoteProviderRegistrationStreamId]: (req: RemoveFunctions<HomeProvider>, identity: OpenFin.Identity) => Promise<RegisterMetaInfoInternal>;
    [HomeChannelActions.remoteProviderDispatchStreamId]: (req: InternalDispatchRequest, identity: OpenFin.Identity) => Promise<void>;
    [HomeChannelActions.remoteSearchCloseStreamId]: (req: {
        id: string;
    }, identity: OpenFin.Identity) => Promise<void>;
};
interface SearchChannelClientBase extends Omit<OpenFin.ChannelClient, 'dispatch' | 'register'> {
    /**
     * Dispatches an action to the Workspace Provider.
     * @param action The action to dispatch
     * @param payload The payload to send with the action
     */
    dispatch: <T extends keyof SearchProviderChannelActions>(action: T, payload: Parameters<SearchProviderChannelActions[T]>[0]) => Promise<Awaited<ReturnType<SearchProviderChannelActions[T]>>>;
}
export interface SearchAPIClientChannelClient extends SearchChannelClientBase {
    /**
     * Registers a handler for a channel action.
     * This function is ONLY used from within `client-api` and should not be used by the workspace components.
     *
     * @param action The action to register a handler for.
     * @param handler The handler to register.
     */
    register: <T extends keyof SearchAPIClientChannelActions>(action: T, handler: (payload: Parameters<SearchAPIClientChannelActions[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Awaitable<ReturnType<SearchAPIClientChannelActions[T]>>) => boolean;
}
export interface WorkspaceChannelProvider extends Omit<OpenFin.ChannelProvider, 'register' | 'dispatch'> {
    /**
     * Used for dispatching a channel action to a channel client
     *
     * @param to The identity of the client to send the action to.
     * @param action The action to send.
     * @param payload The payload to send with the action.
     */
    dispatch: <I extends OpenFin.ClientIdentity | OpenFin.Identity, T extends I['name'] extends (typeof homeOFIdentity)['name'] ? keyof HomeChannelActions : keyof SearchAPIClientChannelClient>(to: I, action: T, payload: I['name'] extends (typeof homeOFIdentity)['name'] ? T extends keyof HomeChannelActions ? Parameters<HomeChannelActions[T]>[0] : never : T extends keyof SearchAPIClientChannelActions ? Parameters<SearchAPIClientChannelActions[T]>[0] : never) => I['name'] extends (typeof homeOFIdentity)['name'] ? T extends keyof HomeChannelActions ? Promise<Awaited<ReturnType<HomeChannelActions[T]>>> : T extends keyof SearchAPIClientChannelActions ? Promise<Awaited<ReturnType<SearchAPIClientChannelActions[T]>>> : never : never;
    /**
     * Used for registering a channel action handler for a channel client
     *
     * @param action The action to register a handler for.
     * @param handler The handler to register.
     */
    register: <T extends keyof SearchProviderChannelActions>(action: T, handler: (payload: Parameters<SearchProviderChannelActions[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Awaitable<ReturnType<SearchProviderChannelActions[T]>>) => boolean;
}
export {};
