import type OpenFin from '@openfin/core';
import { ColorSchemeOptionType } from '../../../../client-api-platform/src/shapes';
export declare const NOTIFICATIONS_SYNC_CHANNEL = "of-workspace-notifications-sync";
export declare enum NotificationsChannelAction {
    UpdatePlatformThemeScheme = "update-platform-theme-scheme"
}
export interface UpdatePlatformSchemePayload {
    scheme: ColorSchemeOptionType;
}
interface NotificationsSyncChannelClient extends OpenFin.ChannelClient {
    dispatch(action: NotificationsChannelAction.UpdatePlatformThemeScheme, payload: UpdatePlatformSchemePayload): Promise<void>;
}
export declare const getNotificationsSyncChannelClient: () => Promise<NotificationsSyncChannelClient>;
export {};
