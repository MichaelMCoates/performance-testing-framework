import type OpenFin from '@openfin/core';
/**
 * All of the remote procedures that can be called in the
 * a Workspace Platform's address space.
 *
 * When adding a new channel action make sure to add a function that's name matches
 * the value of the enum for the remote procedure in the Workspace Platform overrides and the override-callback.
 * All of the registered channel action handlers can be found here in the platform's overrides:
 * @see link: [Provider Protocol Handlers](https://github.com/openfin/workspace/client-api-platform/src/init/override-callback/index.ts)
 */
export declare enum WorkspacePlatformChannelAction {
    LaunchApp = "launchApp",
    SavePage = "savePage",
    GetSavedPage = "getSavedPage",
    CreateSavedPage = "createSavedPage",
    UpdateSavedPage = "updateSavedPage",
    DeleteSavedPage = "deleteSavedPage",
    GetSavedPages = "getSavedPages",
    CreateSavedPageInternal = "createSavedPageInternal",
    UpdateSavedPageInternal = "updateSavedPageInternal",
    DeleteSavedPageInternal = "deleteSavedPageInternal",
    UpdatePageForWindow = "updatePageForWindow",
    AttachPagesToWindow = "attachPagesToWindow",
    DetachPagesFromWindow = "detachPagesFromWindow",
    ReorderPagesForWindow = "reorderPagesForWindow",
    SetActivePage = "setActivePage",
    AddPage = "addPage",
    AddDefaultPage = "addDefaultPage",
    GetAllAttachedPages = "getAllAttachedPages",
    GetActivePageIdForWindow = "getActivePageIdForWindow",
    GetPagesForWindow = "getPagesForWindow",
    GetPageForWindow = "getPageForWindow",
    GetSavedPageMetadata = "getSavedPageMetadata",
    GetUniquePageTitle = "getUniquePageTitle",
    GetLastFocusedBrowserWindow = "getLastFocusedBrowserWindow",
    GetPageByViewIdentity = "getPageByViewIdentity",
    GetThemes = "getThemes",
    GetSelectedScheme = "getSelectedScheme",
    SetSelectedScheme = "setSelectedScheme",
    OpenGlobalContextMenuInternal = "openGlobalContextMenuInternal",
    OpenViewTabContextMenuInternal = "openViewTabContextMenuInternal",
    OpenPageTabContextMenuInternal = "openPageTabContextMenuInternal",
    OpenSaveButtonContextMenuInternal = "openSaveButtonContextMenuInternal",
    InvokeCustomActionInternal = "invokeCustomActionInternal",
    RequestQuitPlatformDialogInternal = "requestQuitPlatformDialogInternal",
    GetSavedWorkspace = "getSavedWorkspace",
    CreateSavedWorkspace = "createSavedWorkspace",
    UpdateSavedWorkspace = "updateSavedWorkspace",
    DeleteSavedWorkspace = "deleteSavedWorkspace",
    GetSavedWorkspaces = "getSavedWorkspaces",
    GetSavedWorkspacesMetadata = "getSavedWorkspacesMetadata",
    SaveWorkspace = "saveWorkspace",
    GetCurrentWorkspace = "getCurrentWorkspace",
    ApplyWorkspace = "applyWorkspace",
    RestoreLastSavedWorkspaceInternal = "restoreLastSavedWorkspaceInternal",
    SetActiveWorkspace = "setActiveWorkspace",
    IsBrowserInitialized = "isBrowserInitialized",
    Analytics = "analyticsInternal",
    GetLanguage = "getLanguage",
    GetLanguageResourcesInternal = "getLanguageResourcesInternal",
    SetLanguage = "setLanguage",
    GetDockProviderConfig = "getDockProviderConfig",
    SaveDockProviderConfig = "saveDockProviderConfig",
    HandleSaveModalOnPageClose = "handleSaveModalOnPageClose",
    ShouldPageClose = "shouldPageClose",
    ShouldWindowClose = "shouldWindowClose",
    CopyPage = "copyPage",
    HandlePageChanges = "handlePageChanges",
    MarkUnsavedPagesAsSavedInternal = "markUnsavedPagesAsSavedInternal",
    TrackRemovedTabInternal = "trackRemovedTabInternal",// Enterprise
    RestoreRemovedTabInternal = "restoreRemovedTabInternal",// Enterprise
    TrackVisitedSiteInternal = "trackVisitedSiteInternal",// Enterprise
    GetRecentlyVisitedSitesInternal = "getRecentlyVisitedSitesInternal",// Enterprise
    GetFrequentlyVisitedSitesInternal = "getFrequentlyVisitedSitesInternal",// Enterprise
    SearchSitesInternal = "searchSitesInternal",// Enterprise
    GetSearchProvidersInternal = "getSearchProvidersInternal",// Enterprise
    GetCuratedContentInternal = "getCuratedContentInternal",// Enterprise
    HandleRequestNavigationInternal = "handleRequestNavigationInternal",// Enterprise
    RefreshBookmarksInternal = "refreshBookmarksInternal",// Enterprise
    LaunchBookmarkInternal = "launchBookmarkInternal",// Enterprise
    GetNotificationsConfig = "getNotificationsConfig",
    UpdateDockFavoritesInternal = "updateDockFavoritesInternal",// Enterprise
    UpdateContentMenuInternal = "updateContentMenuInternal",// Enterprise
    LaunchDockEntryInternal = "launchDockEntryInternal",// Enterprise
    SetDockFavoritesOrderInternal = "setDockFavoritesOrderInternal",// Enterprise
    NavigateContentMenuInternal = "navigateContentMenuInternal",// Enterprise
    SetDefaultDockButtonsOrderInternal = "setDefaultDockButtonsOrderInternal",// Enterprise
    GetDockWorkspacesContextMenuInternal = "getDockWorkspacesContextMenuInternal",// Enterprise
    HandleDockWorkspacesMenuResponseInternal = "handleDockWorkspacesMenuResponseInternal",// Enterprise
    RemoveDockFavoriteInternal = "removeDockFavoriteInternal",// Enterprise
    AddDockFavoriteInternal = "addDockFavoriteInternal",// Enterprise
    FocusAndExpandSearchInternal = "focusAndExpandSearchInternal",// Enterprise
    SendUpdateVersionModalResponseInternal = "sendUpdateVersionModalResponseInternal",// Enterprise
    ShowUpdateVersionModalInternal = "showUpdateVersionModalInternal"
}
export type PlatFormSupportedFeatures = boolean | {
    isWorkspacePlatform: boolean;
    isBrowserInitialized: boolean;
    analytics?: {
        isSupported: boolean;
    };
};
export declare const getPlatformClient: (identity: OpenFin.ApplicationIdentity) => Promise<OpenFin.ChannelClient>;
export declare const internalGetWorkspacePlatformChannelClient: (identity: OpenFin.ApplicationIdentity) => Promise<PlatFormSupportedFeatures>;
/**
 * Get a channel client for a specific Workspace platform.
 *
 * The channel client can execute remote procedures on the platform via its `dispatch` function.
 * A call to the `dispatch` function will block until the channel action has concluded execution
 * in the Workspace platform's address space.
 * For a list of supported procedures, see the `ChannelAction` enum.
 *
 * @returns the channel client for the Workspace platform.
 */
export declare const getWorkspacePlatformChannelClient: (identity: OpenFin.ApplicationIdentity) => Promise<OpenFin.ChannelClient>;
/**
 * Get a channel client for a specific Workspace platform.
 *
 * Ensure that the channel is used within a platform with the browser
 *
 * @returns the channel client for the Workspace platform.
 */
export declare const getBrowserChannelClient: (identity: OpenFin.ApplicationIdentity) => Promise<OpenFin.ChannelClient>;
