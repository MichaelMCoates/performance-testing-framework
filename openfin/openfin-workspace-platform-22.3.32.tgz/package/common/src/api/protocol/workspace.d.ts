import { withDisconnectListener } from '../../../../common/src/utils/channels';
import { SearchAPIClientChannelClient } from '../../../../common/src/api/protocol/shapes/search';
import type { WorkspaceAPIClientChannelClient, WorkspaceChannelProvider, WorkspaceComponentChannelClient } from './shapes/workspace';
export type { WorkspaceAPIClientChannelClient, WorkspaceComponentChannelClient, WorkspaceChannelProvider };
/** The name of the channel for the centralized workspace protocol. */
export declare const channelName: "__of_workspace_protocol__";
export declare const getChannelClient: () => Promise<WorkspaceComponentChannelClient>;
export declare const getClientAPIChannelClient: () => Promise<WorkspaceAPIClientChannelClient>;
export declare const getSearchClientAPIChannelClient: () => Promise<withDisconnectListener<SearchAPIClientChannelClient>>;
/**
 * Launches the Workspace Provider.
 * If the Workspace Provider is already running, does nothing.
 */
export declare const launchProvider: () => Promise<void>;
/**
 * Launches the Workspace provider if it is not running.
 * Then gets a Channel Client that is connected to the Workspace Provider.
 * @returns the Channel Client that is connected to the Workspace Provider.
 */
export declare const getChannelClientAndLaunchProvider: () => Promise<WorkspaceComponentChannelClient>;
/**
 * Launches the Workspace provider if it is not running.
 * Then gets a Channel Client that is connected to the Workspace Provider.
 * @returns the Channel Client that is connected to the Workspace Provider.
 */
export declare const getClientAPIChannelClientAndLaunchProvider: () => Promise<WorkspaceAPIClientChannelClient>;
