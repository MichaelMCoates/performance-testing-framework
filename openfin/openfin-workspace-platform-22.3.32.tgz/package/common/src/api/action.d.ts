/**
 * Configures a custom action when the control is invoked
 */
export interface CustomActionSpecifier {
    /** Identifier of a custom action defined at platform initialization*/
    id: string;
    /** Any data necessary for the functioning of specified custom action*/
    customData?: any;
}
/**
 * Base configuration for a custom button
 */
export interface BaseCustomButtonConfig {
    /** Button name text when hovered over */
    tooltip: string;
    /** Disable custom button true or false */
    disabled?: boolean;
    /** icon URL for icon image */
    iconUrl?: string;
    parentHover?: boolean;
}
export interface BaseCustomDropdownItem<Action = any> extends Omit<BaseCustomButtonConfig, 'tooltip'> {
    tooltip?: string;
    /** Is this dropdown item checked? Any value other than undefined will decorate the dropdown option as a checkbox option. */
    checked?: boolean;
    /** icon URL for icon image */
    action?: Action;
    options?: (BaseCustomDropdownItem | BaseCustomDropdownConfig)[];
    separator?: boolean;
}
export type BaseCustomDropdownItems = BaseCustomDropdownItem[] | (() => Promise<BaseCustomDropdownItem[]>);
/**
 * Base Configuration for a custom dropdown
 */
export interface BaseCustomDropdownConfig extends BaseCustomButtonConfig {
    /** Dropdown options */
    options: BaseCustomDropdownItems;
}
/**
 * Configuration for a buttons with a custom action
 */
export interface CustomButtonConfig extends BaseCustomButtonConfig {
    /** Custom action once the button is clicked */
    action: CustomActionSpecifier;
    options?: never;
}
/**
 * Configuration for a button that presents a dropdown menu with options that dispatch custom actions when clicked.
 */
export interface CustomDropdownConfig extends BaseCustomDropdownConfig {
    /** Options that will be displayed in the dropdown */
    options: (CustomButtonConfig | CustomDropdownConfig)[];
    action?: never;
}
