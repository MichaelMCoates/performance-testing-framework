import type OpenFin from '@openfin/core';
export interface TabsHandler {
    /**
     * Shows tabs for specified window instance. Does nothing if tabs are visible.
     */
    show(): Promise<void>;
    /**
     * Hides tabs for specified window instance. Does nothing if tabs are hidden.
     */
    hide(layoutOverrides?: OpenFin.LayoutOptions): Promise<void>;
    /**
     * Checks if the tabs for specified window are visible and resolves with true/false.
     */
    isShowingTabs(): Promise<boolean>;
}
export declare const getTabsHandler: (layoutIdentity: OpenFin.LayoutIdentity) => TabsHandler;
