/**
 * Options for using privately hosted notification service.
 */
export type NotificationsCustomManifestOptions = {
    /**
     * A custom manifest location to start the notification service from.
     * The UUID cannot be OpenFin hosted Notification Service UUID, 'notifications-service'.
     */
    manifestUrl: string;
    /**
     * The UUID of the provided custom notifications service manifest.
     * This value **MUST** match the UUID of the manifest provided in `manifestUrl`.
     */
    manifestUuid: string;
};
