import { HomeProviderInternal } from '../../../../common/src/api/provider';
import { DispatchedSearchResult, HomeSearchListenerRequest, HomeSearchResult } from '../../../../client-api/src/shapes';
export declare const HOME_SEARCH_CHANNEL_NAME: "__search-openfin-browser-home-topic__";
export type HomeClientApiDispatchRequest = {
    providerId: string;
    result: DispatchedSearchResult;
};
export type HomeClientApiSearchCloseRequest = {
    id: string;
};
export type HomeClientApiDataRequest = {
    id: string;
    query: string;
    context: any;
    providerId: string;
    targets: string[];
};
export interface HomeInternalDataResponse extends SearchResponse {
    id: string;
    providerId: string;
    revoked?: string[];
    status?: InternalSearchListenerResponseStatus;
}
export interface HomeInternalErrorResponse {
    error: string;
}
interface SearchResponse {
    results: HomeSearchResult[];
    context?: any;
}
export interface InternalDataResponse extends SearchResponse {
    id: string;
    providerId: string;
    revoked?: string[];
    status?: InternalSearchListenerResponseStatus;
}
export interface InternalSearchListenerRequest {
    close(): void;
    req: HomeSearchListenerRequest;
}
export interface SearchRequest {
    /** The search query. */
    query: string;
    /** Additional custom context that can be used for searching. */
    context?: Partial<HomeSearchListenerRequest['context']>;
    /** A list of search provider names to execute the search request against. */
    targets?: string[];
}
/**
 * Message for dispatching a search request.
 * This interface is used when sending a dispatch request from a remote OpenFin identity
 * to the search topic creator.
 */
export interface InternalSearchRequest extends SearchRequest {
    /**
     * The id of the search request.
     * On initial search request from remote provider, this ID is generated.
     * The remote OpenFin identity is required to pass this id on all subsequent requests.
     */
    id?: string;
}
export interface InternalSearchResponse {
    /**
     * The ID of the search request the response pertains to.
     */
    id: string;
    /**
     * True if the all search providers have responded to the search request.
     */
    done?: boolean;
    /**
     * The state of the search response generator.
     */
    state: SearchProviderResponseGeneratorState;
    /**
     * The current list of responses.
     */
    value: SearchProviderResponse[];
}
export type SearchProviderResponseGenerator = AsyncGenerator<SearchProviderResponse[], SearchProviderResponse[], SearchProviderResponse[]>;
export interface SearchProviderResponse {
    /**
     * The search provider that responded with the search results.
     */
    provider: HomeProviderInternal;
    /**
     * If the search result succeeds for this provider, results of the search will be set.
     */
    results?: HomeSearchResult[];
    /**
     * A context with custom data to pass through search
     */
    context?: any;
    /**
     * If the search failed for this provider, error will be set.
     */
    error?: Error;
}
export declare enum SearchProviderResponseGeneratorState {
    /**
     * The generator is in the process of fetching the initial set of results from search providers.
     */
    Fetching = "fetching",
    /**
     * The generator has fetched all initial results, and is now waiting for search providers with
     * open {@link SearchListenerResponse} streams to push new or updated search results.
     */
    Fetched = "fetched",
    /**
     * All open {@link SearchListenerResponse} streams have closed, completing the request.
     * In this state, the set of responses returned by `generator.next()` are final.
     */
    Complete = "complete"
}
export type InternalSearchResponseGeneratorHooks = {
    setState(state: SearchProviderResponseGeneratorState): void;
};
export interface InternalErrorResponse {
    /**
     * An error message, denoting that something went wrong.
     */
    error: string;
}
export interface SearchProviderResponseGeneratorExtended extends SearchProviderResponseGenerator {
    /**
     * The id of the search request.
     */
    id: string;
    /**
     * The state of the search provider response generator.
     */
    state: SearchProviderResponseGeneratorState;
    /**
     * Notifies all search providers related to this search request
     * that the search requester is no longer listening for new or updated search results.
     * @experimental
     */
    close: () => void;
}
export interface InternalDispatchRequest {
    result: DispatchedSearchResult;
    providerId: string;
    uniqueId: string;
}
export declare enum InternalSearchListenerResponseStatus {
    /**
     * The initial status of a new search listener response object.
     *
     * Denotes that the search provider listener has not taken use of the search listener response object,
     * as in `response.open()` nor `response.close()` has not been called yet.
     */
    Initial = 0,
    /**
     * Denotes that the search provider is done sending new or updated search results
     * for the corresponding request.
     */
    Open = 1,
    /**
     * Denotes that the search provider is done sending new or updated search results
     * for the corresponding request.
     */
    Close = 2
}
export type SearchQueryWithProviderID = {
    query: string;
    providerID: string;
};
export {};
