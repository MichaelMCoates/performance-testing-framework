import { App, StorefrontFooter, StorefrontLandingPage, StorefrontNavigationItemAppGrid, StorefrontNavigationSection } from '../../../client-api/src/shapes';
import { ProviderInfoInternal } from './provider';
/**
 * Request object to launch an app.
 * Passed from Storefront to Provider.
 */
export interface LaunchStorefrontProviderAppRequest extends ProviderInfoInternal<'storefront'> {
    /**
     * App to launch.
     */
    app: App;
}
/**
 * Request object to launch an app.
 * Passed from Workspace Provider to the Workspace Platform
 */
export interface ClientAPILaunchStorefrontProviderAppRequest extends Pick<ProviderInfoInternal<'storefront'>, 'id' | 'platformIdentity'> {
    /**
     * App to launch.
     */
    app: App;
}
/**
 * Launch a Storefront app.
 * @param req LaunchStorefrontProviderAppRequest request object.
 */
export declare const launchStorefrontApp: (req: LaunchStorefrontProviderAppRequest) => Promise<void>;
/**
 * Get a list of applications for Storefront.
 * @param identity of the platform to get the apps from.
 * @returns the list of Storefront apps for the platform.
 */
export declare const getStorefrontApps: (provider: ProviderInfoInternal<"storefront">) => Promise<App[]>;
/**
 * Get the platform's landing page for Storefront.
 * @param identity of the platform to get the landing page of.
 * @returns the platform's landing page.
 */
export declare const getStorefrontLandingPage: (provider: ProviderInfoInternal<"storefront">) => Promise<StorefrontLandingPage | undefined>;
/**
 * Get the platform's footer for Storefront.
 * @param identity of the platform to get the footer of.
 * @returns the platform's footer.
 */
export declare const getStorefrontFooter: (provider: ProviderInfoInternal<"storefront">) => Promise<StorefrontFooter>;
/**
 * Get the platform's navigation for Storefront.
 * @param identity of the platform to get the navigation of.
 * @returns the platform's navigation.
 */
export declare const getStorefrontNavigation: (provider: ProviderInfoInternal<"storefront">) => Promise<[StorefrontNavigationSection?, StorefrontNavigationSection?]>;
/**
 * A helper method that gets a Storefront navigation item by ID.
 * @param navigationItemId the id of the Storefront navigation item.
 * @param identity of the platform.
 * @returns the navigation item with the ID.
 */
export declare const getStorefrontNavigationItemAppGrid: (navigationItemId: string, provider: ProviderInfoInternal<"storefront">) => Promise<StorefrontNavigationItemAppGrid | undefined>;
