import type OpenFin from '@openfin/core';
import type { AttachedPage, Page, PageWithUpdatableRuntimeAttribs } from './shapes';
export declare function cleanPage<T extends AttachedPage | Page>(page: T): T;
/**
 * Generates a Page object which represents a page.
 * @param title the title for the page.
 * @param layout the layout for the page.
 */
export declare const makePage: (title: string, layout: OpenFin.LayoutOptions) => Promise<PageWithUpdatableRuntimeAttribs>;
/**
 * Clone a page.
 * @param page the page to clone.
 * @returns a clone of the given page.
 */
export declare const clonePage: <T extends Page | AttachedPage>(page: T) => Promise<T>;
