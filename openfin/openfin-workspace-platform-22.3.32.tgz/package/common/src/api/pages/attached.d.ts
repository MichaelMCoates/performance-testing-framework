import type OpenFin from '@openfin/core';
import type { AttachedPage, DetachPagesFromWindowPayload, ExtendedAttachPagesToWindowPayload, ExtendedUpdatePageForWindowPayload, ReorderPagesForWindowPayload, SetActivePageForWindowPayload } from './shapes';
/**
 * Get the pages attached to a window.
 * @param identity the identity of the window to get the attached pages of.
 * @returns the pages attached to the window.
 */
export declare const getPages: (identity: OpenFin.Identity) => Promise<AttachedPage[]>;
/**
 * Get the active attached page for the specified window.
 * @param identity the window identity to get the active attached page of.
 * @returns the active attached page for the window.
 */
export declare const getActivePageForWindow: (identity: OpenFin.Identity) => Promise<AttachedPage>;
/**
 * Set the active attached page for the specified window.
 * @param identity the window identity to set the active attached page of.
 */
export declare const setActivePageForWindow: (payload: SetActivePageForWindowPayload) => Promise<void>;
/**
 * Attach a page to an open window.
 * If the page is already attached to a window, an error will be thrown.
 *
 * @param payload the attach pages to window payload.
 */
export declare const attachPagesToWindow: (payload: ExtendedAttachPagesToWindowPayload) => Promise<void>;
/**
 * Detach pages from the window they are currently attached to.
 * A detached page will not have its views cleaned up.
 *
 * @param payload the detach pages from window payload.
 */
export declare const detachPagesFromWindow: (payload: DetachPagesFromWindowPayload) => Promise<void>;
export interface RenamePagePayload {
    /** The OF window identity the page is attached to. */
    identity: OpenFin.Identity;
    /** The id of the page to change the name of. */
    pageId: string;
    /** The new title of the page. */
    newTitle: string;
}
/**
 * Rename an attached page.
 * The page must be attached to the specified window.
 *
 * @param page the page to rename.
 */
export declare const renamePage: (payload: RenamePagePayload) => Promise<void>;
/**
 * Reorder pages attached to an open window.
 * @param payload the reorder pages for window payload.
 */
export declare const reorderPagesForWindow: (payload: ReorderPagesForWindowPayload) => Promise<void>;
/**
 * Update a page attached to a window.
 * @param payload the update page for window payload.
 */
export declare const updatePageForWindow: (payload: ExtendedUpdatePageForWindowPayload) => Promise<void>;
/**
 * Forces a window to save its attached page state to window options.
 * @param identity the identity of the window to save the pages of in window options.
 */
export declare const updatePagesWindowOptions: (identity: OpenFin.Identity) => Promise<void>;
/**
 * Check if the window identity is currently detaching pages.
 * @param identity the OF window identity to check.
 */
export declare const isDetachingPages: (identity: OpenFin.Identity) => Promise<boolean>;
/**
 * Check if the window identity is in the middle of changing active pages.
 * @param identity the OF window identity to check.
 */
export declare const isActivePageChanging: (identity: OpenFin.Identity) => Promise<boolean>;
