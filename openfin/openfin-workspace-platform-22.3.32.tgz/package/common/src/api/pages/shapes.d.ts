import type OpenFin from '@openfin/core';
export interface PageLayoutDetails {
    /**
     * The id of the machine that created the page.
     */
    machineId: string;
    /**
     *  The name of the machine that created the page.
     */
    machineName?: string;
}
export type PageLayout = OpenFin.LayoutOptions & {
    layoutDetails?: PageLayoutDetails;
};
/**
 * Provides configuration options for a set of Workspace Views. An array of Page objects is a required option of the {@link workspacePlatform}
 * property of the {@link BrowserCreateWindowRequest} interface.
 *```ts
 *  const page: Page = {
 *      title: 'myPageTitle',
 *      pageId: 'myPageID',
 *      layout: {
 *          content: [
 *              {
 *                  type: 'stack',
 *                  content: [
 *                      {
 *                          type: 'component',
 *                          componentName: 'view',
 *                          componentState: {
 *                              name: 'myViewName',
 *                              url: 'http://google.com'
 *                          }
 *                      }
 *                  ]
 *              }
 *          ]
 *      }
 * };
 * ```
 */
export interface Page {
    /** A UI friendly title for the page. */
    title: string;
    /** The unique ID of the page. */
    pageId: string;
    /** An optional UI friendly description of the page. */
    description?: string;
    /** A optional UI friendly tooltip for the page. */
    tooltip?: string;
    /**
     * True if the page is read only. In this state, the page is locked and cannot be unlocked.
     *
     * @deprecated This property is deprecated and will be removed in a future release. Setting it has no effect. To _"lock"_ a page, and prevent the ability to close pages, drag pages within the window and drag pages into/out of the window, use the `isLocked` property.
     */
    isReadOnly?: boolean;
    /** Icon that appears on a page tab if there are unsaved changes (dirty state). If 'undefined', default icon will appear. */
    unsavedIconUrl?: string;
    /** Icon that appears on a page tab if there are no unsaved changes. If 'undefined', default icon will appear. */
    iconUrl?: string;
    /** The layout of the page. */
    layout: PageLayout;
    /** True if the page is locked. */
    isLocked?: boolean;
    /** Used to manipulate behaviour of a close button on a page tab. If `undefined`, then close button is visible and actionable.
     * If either property true, this page tab's context menu will disable its 'Close Page' option.
     */
    closeButton?: {
        hidden?: boolean;
        disabled?: boolean;
    };
    /** Used to configure fixed views on the edges of the browser window. Only one panel per side is supported. */
    panels?: PanelConfig[];
    /** Optional property to attach custom metadata to the page object, such as version or timestamp. Must be serializable. */
    customData?: any;
}
type AttachedPageMetadata = {
    /** The window the page is currently attached to. */
    parentIdentity?: OpenFin.Identity;
    /** True if the page is the currently active page for its parent window. */
    isActive?: boolean;
    /** The name of the layout this page contains, useful for interacting with OpenFin Core APIs. */
    layoutName?: string;
    /** True if the page has unsaved changes. */
    hasUnsavedChanges?: boolean;
    /** Panel config with all view identities in place */
    panels?: ExtendedPanelConfig[];
};
export type AttachedPage = Page & AttachedPageMetadata;
export type AttachedPageInternal = {
    layoutContainerKey?: string;
    singleViewName?: string;
    attachedPageType?: 'singleView' | 'multiView' | undefined;
    isLayoutCreated?: boolean;
    pageIcon?: string;
} & AttachedPage;
export type ReparentAttachedPage = AttachedPage & {
    multiInstanceViewBehavior?: 'reparent';
};
export type PageWithUpdatableRuntimeAttribs = Page & Pick<AttachedPage, 'hasUnsavedChanges'> & {
    multiInstanceViewBehavior?: OpenFin.MultiInstanceViewBehavior;
};
export interface DetachPagesFromWindowPayload {
    /** The OF window identity to detach the pages from. */
    identity: OpenFin.Identity;
    /** The ids of the pages to detach. */
    pageIds: string[];
}
export interface SetActivePageForWindowPayload {
    /** The OF window identity to set the active page of. */
    identity: OpenFin.Identity;
    /**
     * The id of the page to set as active.
     * The page must be attached to the target window.
     */
    pageId: string;
}
export interface ReorderPagesForWindowPayload {
    /** The OF window identity the pages to change the order of. */
    identity: OpenFin.Identity;
    /** The ordered ids of the attached pages. */
    pageIds: string[];
}
export interface UpdatePageForWindowPayload {
    /** The OF window identity the pages to change the order of. */
    identity: OpenFin.Identity;
    /** The id of the attached page to update. */
    pageId: string;
    /** The partial updated state of the page. */
    page: Partial<PageWithUpdatableRuntimeAttribs>;
}
export interface ExtendedUpdatePageForWindowPayload extends UpdatePageForWindowPayload {
    /** The partial updated state of the page. */
    page: Partial<AttachedPage>;
}
export interface AttachPagesToWindowPayload {
    /** The OF window identity to attach the pages to. */
    identity: OpenFin.Identity;
    /** The pages to attach. */
    pages: PageWithUpdatableRuntimeAttribs[];
    insertionIndex?: number;
    /** Whether to replace the active page with the first new page, if true insertionIndex is ignored and pages are inserted at the active page's index */
    replaceActivePage?: boolean;
}
export interface ExtendedAttachPagesToWindowPayload extends AttachPagesToWindowPayload {
    /** The pages to attach. */
    pages: AttachedPage[];
}
export interface GetSavedPageMetadataPayload {
    /** The OF window identity to attach the pages to. */
    identity: OpenFin.Identity;
    /** The id of the page to get the save state of. */
    pageId: string;
}
/**
 * Possible positions than a fixed view panel can take.
 */
export declare enum PanelPosition {
    Left = "Left",
    Right = "Right",
    Top = "Top",
    Bottom = "Bottom"
}
/**
 * Properties specific to a horizontal fixed view panel (top or bottom)
 */
export interface PanelConfigHorizontal {
    /** Position of the panel in the page. */
    position: PanelPosition.Top | PanelPosition.Bottom;
    /** Size of the top/bottom panel, formatted as CSS property value with units. E.g. "0px", "10%", "3rem". */
    height: string;
}
/**
 * Properties specific to a vertical fixed view panel (left or right)
 */
export interface PanelConfigVertical {
    /** Position of the panel in the page. */
    position: PanelPosition.Left | PanelPosition.Right;
    /** Size of the left/right panel, formatted as CSS property value with units. E.g. "0px", "10%", "3rem". */
    width: string;
    /** When true, the left/right panel extends all the way to the top of the window,
     * thus taking priority over the top panel.*/
    extendToTop?: boolean;
    /** When true, the left/right panel extends all the way to the bottom of the window,
     * thus taking priority over the bottom panel.*/
    extendToBottom?: boolean;
}
/**
 * Configuration of an individual fixed view panel
 *
 * Example:
 * ```ts
 * {
 *    position: PanelPosition.Left,
 *    width: '140px',
 *    viewOptions: { url: 'https://example.com'}
 * }
 * ```
 */
export type PanelConfig = (PanelConfigHorizontal | PanelConfigVertical) & {
    /** The options with which to initialize the panel view.*/
    viewOptions: Omit<OpenFin.PlatformViewCreationOptions, 'bounds' | 'target'>;
};
export type ExtendedPanelConfig = PanelConfig & {
    viewOptions: PanelConfig['viewOptions'] & OpenFin.Identity;
};
export interface ShouldPageClosePayload {
    /** The page that is closing. */
    page: AttachedPage;
    /** The OF window identity containing the page. */
    identity: OpenFin.Identity;
    /** The type of close operation that triggered the override */
    closeType: 'page' | 'window' | 'view';
}
export interface ViewsPreventingUnloadPayload extends Omit<OpenFin.ViewsPreventingUnloadPayload, 'closeType'> {
    closeType: OpenFin.ViewsPreventingUnloadPayload['closeType'] | 'page';
}
export interface HandlePagesAndWindowClosePayload {
    /** Pages for which `shouldPageClose` override returned false */
    pagesPreventingClose: AttachedPage[];
    /** Pages for which `shouldPageClose` override returned true */
    pagesNotPreventingClose: AttachedPage[];
    /** Identity of the Browser window */
    identity: OpenFin.Identity;
}
export interface HandlePagesAndWindowCloseResult {
    /** Determines whether closing of the window should proceed. */
    shouldWindowClose: boolean;
}
export interface HandleSaveModalOnPageClosePayload {
    /** The page that is closing. */
    page: AttachedPage;
    /** The OF window identity containing the page. */
    identity: OpenFin.Identity;
}
export interface SaveModalOnPageCloseResult {
    /** If false, a modal informing that unsaved changes will be lost will not be displayed. */
    shouldShowModal: boolean;
}
export interface ShouldPageCloseResult {
    shouldPageClose: boolean;
}
export interface CopyPagePayload {
    /** The OF browser identity containing the page to copy. */
    identity: OpenFin.Identity;
    /** The page to copy. */
    page: Page;
    /** Specifies the trigger for creating a copy. */
    reason: 'save-as' | 'duplicate';
}
export type AddDefaultPagePayload = {
    /** The OF window identity to attach the pages to. */
    identity: OpenFin.Identity;
    /** The page to attach. */
    page: PageWithUpdatableRuntimeAttribs;
    /** The newPageUrl provided. */
    newPageUrl: string;
};
export type AddPagePayload = {
    /** The OF window identity to attach the pages to. */
    identity: OpenFin.Identity;
    /** The page to attach. */
    page: PageWithUpdatableRuntimeAttribs;
    /** Index at which the page should be added */
    insertionIndex?: number;
    multiInstanceViewBehavior?: OpenFin.MultiInstanceViewBehavior;
};
/**
 * A node that represents either a bookmark or folder in the bookmark tree.
 */
export interface BookmarkNode {
    /**
     * The unique id of the node.
     */
    id: string;
    /**
     * The title of the bookmark or folder.
     */
    title: string;
    /**
     * The unique URL associated with a bookmark. Is undefined for folders.
     */
    url?: string;
    /**
     * When this bookmark or folder was created, in milliseconds since the epoch.
     */
    dateCreated: number;
    /**
     * The favicon to display next to titles for bookmarks. When no icon or a
     * broken icon is provided, the default globe icon will be used instead. Is
     * undefined for folders.
     */
    favIcon?: string;
    /**
     * The id of the parent folder that contains a bookmark. Is undefined for the
     * root node.
     */
    parentId?: string;
    /**
     * The children of this node. Can only contain bookmarks. Is undefined for
     * bookmarks.
     */
    children?: BookmarkNode[];
}
/**
 * Request object to create a new bookmark node.
 */
export interface CreateBookmarkNodeRequest {
    /**
     * The title of the bookmark or folder.
     */
    title: string;
    /**
     * The unique URL associated with the bookmark. Omit for folders.
     */
    url?: string;
    /**
     * The favicon to display next to titles for bookmarks. When no icon or a
     * broken icon is provided, the default globe icon will be used instead. Omit
     * for folders.
     */
    favIcon?: string;
    /**
     * The id of the parent folder for this bookmark. Omit for bookmarks under
     * "All Bookmarks" and folders.
     */
    parentId?: string;
}
export type UpdatedBookmarkNodeAttrs = {
    /**
     * The new title to apply to the bookmark/folder.
     */
    title?: string;
    /**
     * The id of the parent folder to move this bookmark to. Leave undefined to
     * move bookmark under "All Bookmarks". Omit for folders.
     */
    parentId?: string;
    /**
     * The favicon to display next to titles for bookmarks. When no icon or a
     * broken icon is provided, the default globe icon will be used instead. Omit
     * for folders.
     */
    favIcon?: string;
};
/**
 * Request object to update a bookmark node.
 */
export interface UpdateBookmarkNodeRequest {
    /**
     * The unique id of the bookmark.
     */
    id: string;
    /**
     * The object describing which attributes of the bookmark to update.
     */
    changes: UpdatedBookmarkNodeAttrs;
}
/**
 * Represents the layout of a page with selected views.
 */
export interface PageLayoutsWithSelectedViews {
    /**
     * The unique id of the page.
     */
    pageId: string;
    /**
     * The key of the layout container.
     */
    layoutContainerKey: string;
    /**
     * Indicates if the page is active.
     */
    isActive: boolean;
    /**
     * The selected views in the layout.
     */
    selectedViews: OpenFin.Identity[];
}
export {};
