import type OpenFin from '@openfin/core';
import { AttachedPageInternal } from '../../../../common/src/api/pages/shapes';
export interface PagesLayoutSnapshot {
    layouts: {
        [layoutContainerKey: string]: OpenFin.LayoutOptions;
    };
    pages: AttachedPageInternal[];
}
export declare const convertPagesToLayoutSnapshot: (pages: AttachedPageInternal[], isEnterprise: boolean) => {
    layouts: Record<string, OpenFin.LayoutOptions>;
    pages: AttachedPageInternal[];
};
export declare const convertLayoutSnapshotToPages: ({ pages, layouts }: PagesLayoutSnapshot) => AttachedPageInternal[];
