import { CopyPagePayload, HandleSaveModalOnPageClosePayload, Page, SaveModalOnPageCloseResult, ShouldPageClosePayload, ShouldPageCloseResult } from '../../../../common/src/api/pages/shapes';
import { shouldWindowClose } from '../../../../client-api-platform/src/api/pages';
import { HandlePageChangesPayload, ModifiedPageState } from '../../../../client-api-platform/src/shapes';
export declare const requestPageSaveModalDecision: (req: HandleSaveModalOnPageClosePayload) => Promise<SaveModalOnPageCloseResult>;
export declare const requestShouldPageClose: (req: ShouldPageClosePayload) => Promise<ShouldPageCloseResult>;
export declare const requestShouldWindowClose: (payload: Parameters<typeof shouldWindowClose>[0]) => ReturnType<typeof shouldWindowClose>;
export declare const copyPage: (req: CopyPagePayload) => Promise<Page>;
export declare const requestPageChangesDecision: (req: HandlePageChangesPayload) => Promise<ModifiedPageState>;
