import { OpenFin } from '@openfin/core';
import { ExtendedPanelConfig, PageLayout, PanelConfig } from '../../../../client-api-platform/src/index';
export interface Page {
    /** A UI friendly title for the page. */
    title: string;
    /** The unique ID of the page. */
    pageId: string;
    /** An optional UI friendly description of the page. */
    description?: string;
    /** A optional UI friendly tooltip for the page. */
    tooltip?: string;
    /**
     * True if the page is read only. In this state, the page is locked and cannot be unlocked.
     *
     * @deprecated This property is deprecated and will be removed in a future release. Setting it has no effect. To _"lock"_ a page, and prevent the ability to close pages, drag pages within the window and drag pages into/out of the window, use the `isLocked` property.
     */
    isReadOnly?: boolean;
    /** Icon that appears on a page tab if there are unsaved changes (dirty state). If 'undefined', default icon will appear. */
    unsavedIconUrl?: string;
    /** The layout of the page. */
    layout: PageLayout;
    /** True if the page is locked. */
    isLocked?: boolean;
    /** Used to manipulate behaviour of a close button on a page tab. If `undefined`, then close button is visible and actionable.
     * If either property true, this page tab's context menu will disable its 'Close Page' option.
     */
    closeButton?: {
        hidden?: boolean;
        disabled?: boolean;
    };
    /** Used to configure fixed views on the edges of the browser window. Only one panel per side is supported. */
    panels?: PanelConfig[];
    /** Used to define the context group for the page */
    contextGroup?: string;
    /** Optional property to attach custom metadata to the page object, such as version or timestamp. Must be serializable. */
    customData?: any;
}
type AttachedPageMetadata = {
    /** The window the page is currently attached to. */
    parentIdentity?: OpenFin.Identity;
    /** True if the page is the currently active page for its parent window. */
    isActive?: boolean;
    /** True if the page has unsaved changes. */
    hasUnsavedChanges?: boolean;
    /** Panel config with all view identities in place */
    panels?: ExtendedPanelConfig[];
    /** The name of the layout this page contains, useful for interacting with OpenFin Core APIs. */
    layoutName?: string;
};
export type AttachedPage = Page & AttachedPageMetadata;
export type AttachedPageInternal = {
    layoutContainerKey?: string;
    singleViewName?: string;
    attachedPageType?: 'singleView' | 'multiView' | undefined;
    isLayoutCreated?: boolean;
    pageIcon?: string;
    isLayoutReady?: boolean;
} & AttachedPage;
export {};
