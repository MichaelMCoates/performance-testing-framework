import type OpenFin from '@openfin/core';
import type { Page } from '../../../../common/src/api/pages/shapes';
import { SearchSitesRequest, Site } from '../../../../client-api-platform/src/shapes';
export declare function getPage(id: string): Promise<Page | undefined>;
export declare function getPageList(filter?: string): Promise<Page[]>;
export declare function createPage({ page }: {
    page: Page;
}): Promise<void>;
export declare function deletePage(id: string): Promise<void>;
export declare function updatePage({ pageId, page }: {
    page: Page;
    pageId: string;
}): Promise<void>;
export declare const addRemovedTab: (payload: TrackedTab) => Promise<void>;
export declare const popLastRemovedTab: () => Promise<TrackedTab | undefined>;
export declare const trackVisitedSite: (payload: Site) => Promise<void>;
export declare const getRecentVisitedSites: (numOfSites?: number) => Promise<TrackedSite[] | []>;
export declare const getFrequentlyVisitedSites: () => Promise<TrackedSite[] | []>;
export declare const searchSites: (payload: {
    req: SearchSitesRequest;
} & {
    identity: OpenFin.Identity;
}) => Promise<TrackedSite[]>;
export type TrackedPageTab = {
    identity: OpenFin.Identity;
    page: Page;
};
export type TrackedWindowTab = {
    window: OpenFin.WorkspacePlatformOptions;
};
export declare function isPageTab(tab: TrackedTab): tab is TrackedPageTab;
export declare function isWindowTab(tab: TrackedTab): tab is TrackedWindowTab;
