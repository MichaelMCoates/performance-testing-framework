export declare const defaultBrandIcons: {
    light: {
        symbol: string;
    };
    dark: {
        symbol: string;
    };
};
