import type OpenFin from '@openfin/core';
import { ResponseModalConfig } from '../../../common/src/utils/menu-config';
import { ModalResponseEvent } from './menu-window-provider';
export type DeleteWorkspaceMenuPayload = {
    workspaceTitle: string;
    windowIdentity?: OpenFin.Identity;
};
export declare const restoreChangesMenu: (windowIdentity: OpenFin.Identity) => Promise<ResponseModalConfig>;
export declare const deletePageMenu: (windowIdentity: OpenFin.Identity, pageTitle: string) => Promise<ResponseModalConfig>;
/**
 *
 * @param targetWindowIdentity Parent or Current OpenFin Window Identity
 * @param workspaceTitle The platform label that was selected to be switched to
 * @param shouldCenterOnMonitor Boolean - determines if modal window is centered on the monitor.
 * @returns Boolean - Affirmative or Negative response from user
 */
export declare const showSwitchWorkspaceModal: (targetWindowIdentity: OpenFin.Identity | undefined, workspaceTitle: string, shouldCenterOnMonitor?: boolean) => Promise<boolean>;
export declare const showDeleteWorkspaceModal: ({ workspaceTitle, windowIdentity }: DeleteWorkspaceMenuPayload) => Promise<boolean>;
/**
 *
 * @param windowIdentity Parent or Current OpenFin Window Identity
 * @param workspaceTitle The platform label
 * @param shouldCenterOnMonitor Boolean - determines if modal window is centered on the monitor.
 * @returns Boolean - Affirmative or Negative response from user
 */
export declare const showPlatformQuitModal: (windowIdentity: OpenFin.Identity, workspaceTitle: string, shouldCenterOnMonitor?: boolean) => Promise<boolean>;
export declare const showQuitBrowserModal: (windowIdentity: OpenFin.Identity) => Promise<boolean>;
export declare const showRestoreChangesModal: (windowIdentity: OpenFin.Identity) => Promise<boolean>;
export declare const getOverwriteWorkspaceMenu: (workspaceTitle: string) => Promise<ResponseModalConfig>;
export declare const showDeletePageModal: (windowIdentity: OpenFin.Identity, pageTitle: string) => Promise<boolean>;
export declare const showUpdateVersionModal: ({ identity, title, description }: {
    identity: OpenFin.Identity;
    title: string;
    description: string;
}) => Promise<ModalResponseEvent["data"]>;
