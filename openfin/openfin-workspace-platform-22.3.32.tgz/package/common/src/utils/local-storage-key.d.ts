declare enum LocalStorageKey {
    CurrentWorkspaceId = "currentWorkspaceId",
    LastFocusedBrowserWindow = "lastFocusedBrowserWindow",
    MachineName = "machineName",
    NewTabPageLayout = "NewTabPageLayout",
    NewTabPageSort = "NewTabPageSort",
    DockPosition = "DockPosition",
    SelectedColorScheme = "SelectedColorScheme",
    ThemePaletteSheet = "ThemePaletteSheet",
    HasMovedStore = "HasMovedStore",
    PageDragState = "BrowserPageDragState",
    ThemePaletteDefaultScheme = "ThemePaletteDefaultScheme"
}
export default LocalStorageKey;
