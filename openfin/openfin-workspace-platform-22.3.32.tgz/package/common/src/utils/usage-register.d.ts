import type OpenFin from '@openfin/core';
import { AttachedPage } from '../../../client-api-platform/src/shapes';
export interface RegisterUsageStatus {
    apiVersion?: string;
    componentVersion?: string;
    allowed: boolean;
    rejectionCode?: string;
}
export declare enum ComponentName {
    Browser = "Browser",
    Dock = "Dock",
    EnterpriseDock = "EnterpriseDock",
    Home = "Home",
    Notification = "Notification",
    Storefront = "Storefront",
    Platform = "Platform",
    Theming = "Theming",
    Microflow = "Microflow"
}
export declare const registerBrowserUsage: (status: RegisterUsageStatus) => void;
export declare const registerHomeUsage: (status: RegisterUsageStatus) => void;
export declare const registerStorefrontUsage: (status: RegisterUsageStatus) => void;
export declare const registerDockUsage: (status: RegisterUsageStatus) => void;
export declare const registerNotificationUsage: (status: RegisterUsageStatus) => void;
export declare const registerPlatformUsage: (status: RegisterUsageStatus) => void;
export declare const registerThemingUsage: (status: RegisterUsageStatus) => void;
export declare const registerMicroflowUsage: (microflowName: string, status: RegisterUsageStatus) => void;
export type AnalyticsSource = 'Browser' | 'Dock' | 'Home' | 'Notification' | 'Store' | 'Platform' | 'Theming' | 'Interop';
/**
 * Event for analytics
 */
export type AnalyticsEvent = {
    source: AnalyticsSource;
    type: string;
    action: string;
    value?: string;
    entityId?: OpenFin.Identity;
    data?: any;
};
export interface AnalyticsEventInternal extends AnalyticsEvent {
    /**
     * By default, all event values are redacted before sending to OF.
     * For events not containing any identifiable information, set this to true.
     */
    skipValueHashing?: boolean;
}
export type AnalyticsEventRaise = Omit<AnalyticsEventInternal, 'source'>;
export declare const raiseBrowserAnalytics: (payload: AnalyticsEventRaise) => Promise<void>;
export declare const raiseBrowserPageAnalytics: (pages: AttachedPage[], action: string) => Promise<void>;
export declare const raiseHomeAnalytics: (platformIdentity: OpenFin.Identity, payload: AnalyticsEventRaise) => Promise<void>;
export declare const raiseDockAnalytics: (platformIdentity: OpenFin.Identity, payload: AnalyticsEventRaise) => Promise<void>;
export declare const raiseStorefrontAnalytics: (platformIdentity: OpenFin.Identity, payload: AnalyticsEventRaise) => Promise<void>;
export declare const raiseInteropAnalytics: (payload: AnalyticsEventRaise) => Promise<void>;
