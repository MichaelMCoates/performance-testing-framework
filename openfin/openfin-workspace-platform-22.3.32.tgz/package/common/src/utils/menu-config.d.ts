import type OpenFin from '@openfin/core';
import type { OptionalExceptFor } from '../../../common/src/utils/types';
export interface MenuConfig {
    windowOptions: OptionalExceptFor<OpenFin.WindowOptions, 'url' | 'name' | 'defaultHeight' | 'defaultWidth'> & {
        preventBlur?: boolean;
        closeOnResponse?: boolean;
    };
    title: string;
    parameters?: URLSearchParams;
}
export interface RightMenuConfig extends MenuConfig {
    windowOffset?: {
        x?: number;
        y?: number;
    };
}
export interface ResponseModalConfig extends MenuConfig {
    content: ResponseModalContent;
}
export interface ResponseModalContent {
    title: string;
    body: string;
    closeType?: 'page' | 'workspace';
    buttons: ResponseModalButtons;
    textInputOptions?: {
        placeholder?: string;
        defaultValue?: string;
    };
    invocationId?: string;
}
export type ResponseModalButtons = LeftButtonConfig | RightButtonConfig;
export interface LeftButtonConfig {
    left: ButtonConfig[];
    right?: ButtonConfig[];
}
export interface RightButtonConfig {
    left?: ButtonConfig[];
    right: ButtonConfig[];
}
export type ButtonConfig = {
    label: string;
    type: 'primary' | 'secondary';
    id: string;
    variant?: 'critical' | 'outline' | 'submit';
    dataTestId?: string;
};
