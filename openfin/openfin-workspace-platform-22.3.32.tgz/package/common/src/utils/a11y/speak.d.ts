import { AriaLive } from './search.a11y';
/**
 * Makes the screen reader speak the provided message.
 * https://a11y-guidelines.orange.com/en/web/components-examples/make-a-screen-reader-talk/
 */
export declare const speak: (msg: string, priority?: AriaLive) => void;
