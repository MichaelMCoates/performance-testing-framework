export type Role = string;
export type AriaOwns = undefined | string;
export type AriaHaspopup = boolean | 'false' | 'true' | 'menu' | 'listbox' | 'tree' | 'grid' | 'dialog';
export type AriaAutocomplete = 'none' | 'inline' | 'list' | 'both';
export type AriaControls = undefined | string;
export type AriaActivedescendant = undefined | string;
export type AriaExpanded = boolean | 'false' | 'true';
export type AriaLive = 'none' | 'polite' | 'assertive';
export type A11yBox = {
    'role': Role;
    'aria-expanded': AriaExpanded;
    'aria-owns': AriaOwns;
    'aria-haspopup': AriaHaspopup;
};
export type A11yInput = {
    'aria-controls': AriaControls;
    'aria-autocomplete': AriaAutocomplete;
    'aria-activedescendant': AriaActivedescendant;
};
export interface AriaSearchInput {
    role: Role;
    controls: AriaControls;
    autocomplete: AriaAutocomplete;
    owns: AriaOwns;
    haspopup: AriaHaspopup;
    searchLabelID: string;
    searchResultID: string;
    searchInputID: string;
    landingPageLabelText: string;
    labelText: string;
}
export declare const A11ySearch: AriaSearchInput;
