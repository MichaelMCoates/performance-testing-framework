import { BackgroundLayers, CustomPaletteSet } from '../../../common/src/api/theming';
/**
 * Parses a CSS color string (hex, rgb(a), or hsl(a)) into a structured RGB string and alpha value.
 *
 * This helper is designed to extract RGB and alpha components from theme-defined color values,
 * enabling usage in CSS `rgba(var(--color), <alpha>)` syntax by separating the color and opacity parts.
 *
 * Supported formats:
 * - Hex strings (`#RRGGBB` or `#RGB`) → parsed to `"r, g, b"` with `alpha: 1`
 * - `rgb()` / `rgba()` → extracts numeric values; alpha is preserved if present
 * - `hsl()` / `hsla()` → numeric values are extracted but visually may not reflect true RGB; alpha is preserved
 *
 * Example:
 * ```ts
 * const { rgb, alpha } = parseColorToRgbWithAlpha('rgba(255, 255, 255, 0.75)');
 * // rgb = "255, 255, 255"
 * // alpha = 0.75
 * ```
 *
 * @param color - The primary color string from the theme (may be hex, rgb[a], hsl[a]).
 * @returns An object with `rgb` as a comma-separated string, and `alpha` as a number between 0 and 1.
 */
export declare const parseColorToRgbWithAlpha: (color: string) => {
    rgb: string;
    alpha: number;
};
/**
 * Get hue from a CSS color
 *
 * The getHue function is used manage extracting hue from 3 types of css
 * string input types. An object including hue, hsl, hsla, lightness and
 * saturation are returned.
 *
 * Each function was copied css tricks and modified to fit this platform.
 * Links above each function for technical details.
 *
 * Allowed formats:
 *      RGB with or with out the alpha rgb(x,x,x) or rgba(x,x,x,x)
 *      HEX 3 or 6 characters, plus hashtag #333 or #333333
 *      HSL with or with out the alhpa hsl(x,x%,x%) or hsla(x,x%,x%,x)
 *
 * The hue value is used later to build an array of background colors in the
 * theme that are various shades of the hue returned from this function.
 *
 * An invalid format should error telling the integrator how to fix the error.
 * - Error for missing required options
 * - Error for invalid css strings that are unable to be processed
 *
 * @param colorInput string - Supported formats rgb/RGB/rgba/RGBA, #000/#000000, hsl/HSL/hsla/HSLA
 * @returns hue as string
 */
export declare const getHue: (colorInput: string) => string;
export declare const makeBackgroundLayers: (backgroundPrimary: string, isLightBackground?: boolean) => BackgroundLayers;
/**
 * makePalette() - generic - doesn't care about scheme
 *
 * Accepts a default palette object, and a custom palette object.
 * The default object gets overrides from customPalette and returns a new palette object.
 * @param defaultPalette
 * @param customPalette
 * @returns { light: newPalette, dark: newPalette }
 *
 * TODO: DefaultPaletteSet isn't working, need to redo.
 */
export declare const makePalette: (defaultPalette: any, customPalette: CustomPaletteSet) => CustomPaletteSet;
