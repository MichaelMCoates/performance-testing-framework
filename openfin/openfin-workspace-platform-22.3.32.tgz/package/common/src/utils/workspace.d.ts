import { Workspace, WorkspacePlatformModule } from '../../../client-api-platform/src/shapes';
export declare const saveWorkspaceInternal: (workspace: Workspace, p?: WorkspacePlatformModule) => Promise<void>;
export declare const createWorkspaceInternal: (workspace: Workspace, p?: WorkspacePlatformModule) => Promise<void>;
export declare const updateWorkspaceInternal: (workspace: Workspace, p?: WorkspacePlatformModule) => Promise<void>;
