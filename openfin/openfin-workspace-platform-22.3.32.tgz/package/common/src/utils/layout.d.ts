import type OpenFin from '@openfin/core';
import { WindowIdentity } from '../../../common/src/utils/window';
import { AttachedPageInternal } from '../../../common/src/api/pages/shapes';
import { AttachedPage, PageLayout } from '../../../client-api-platform/src/shapes';
export type LayoutDOMEventType = 
/**
 * Fired when a tab is created in a container. (Emmitted by ??)
 */
'tabs-list-resized'
/**
 * Fired when a tab is created in a container. (Emmitted by core)
 */
 | 'tab-created'
/**
 * Fired when the layout container is ready to be used. (Emitted by us)
 */
 | 'container-resized' | 'tab-closed';
export type LayoutDOMEvent = {
    type: Extract<LayoutDOMEventType, 'container-resized'>;
} | {
    type: Extract<LayoutDOMEventType, 'tab-created' | 'tab-closed'>;
    detail: {
        containerSelector: string;
        tabSelector: string;
        name: string;
        topic: string;
        type: string;
        uuid: string;
        originalElement: HTMLElement;
    };
    isInitialized: boolean;
    target: HTMLElement;
} | {
    type: Extract<LayoutDOMEventType, 'tabs-list-resized'>;
};
export type LayoutDOMEventListener = (ev: LayoutDOMEvent) => void;
export declare const VIEW_NAME_PREFIX: "internal-generated-view-";
export declare const getFirstActiveViewFromLayout: (identity: OpenFin.LayoutIdentity) => Promise<OpenFin.Identity>;
/**
 * Recursively clones a layout object, calling a passed callback on each `componentState` in the tree.
 * @param node Either the layout object itself, or one of the items in its tree.
 * @param callback Callback to be called on each component's `componentState`
 * @returns A mapped copy of the layout
 */
export declare const mapLayoutViewComponents: (node: any, callback: (arg0: any) => any) => any;
/**
 * Copies the componentState and generates a name if it's not there
 * @param componentState view's componentState in the layout object, corresponds to View options
 * @returns A copy of the componentState with name filled in
 */
export declare const generateViewNameIfNotExists: <T extends {
    name?: string;
}>(componentState: T) => Omit<T, "name"> & {
    name: string;
};
export declare const generateViewNameAndIdentifierNameIfNotExists: <T extends {
    name?: string;
    _internalWorkspaceData: any;
}>(componentState: T) => T & {
    name?: string;
};
/**
 * Deep clones a layout and converts view options (add names if necessary, apply defaults).
 * @param layout The Layout to be cloned
 * @returns A copy of the layout with view options converted
 */
export declare const cloneLayoutAndConvertViewOptions: (layout: PageLayout, initViewOptions?: Partial<OpenFin.ViewOptions>) => any;
export declare const cloneViewComponentWithoutName: (componentState: any) => any;
/**
 * Deep clones a layout and removes view names.
 * @param layout The Layout to be cloned
 * @returns A copy of the layout with names removed
 */
export declare const cloneLayoutAndRemoveNames: (layout: PageLayout) => any;
/**
 * Deep clones a layout and removes generated view names.
 * @param layout The Layout to be cloned
 * @returns A copy of the layout with generated names removed
 */
export declare const cloneLayoutAndRemoveGeneratedNames: (layout: PageLayout) => any;
export declare const mapContentComponentState: (content: OpenFin.LayoutContent) => OpenFin.LayoutComponent["componentState"][];
export declare const getLayoutWithSingleView: (title: string, url: string, winIdentity?: OpenFin.Identity) => Promise<any>;
export declare const layoutNameInitializedMap: Map<string, boolean>;
export declare const isLayoutTabActive: (tabSelector: string) => boolean;
export declare const containerId = "layout_container";
export declare const viewTabslistSelectors = ".lm_tabs";
export declare const addLayoutEventListener: (event: LayoutDOMEventType, listener: LayoutDOMEventListener) => void;
/**
 * Initialize the layout for the current OF window.
 */
export declare const initLayoutListeners: () => Promise<void>;
/**
 * Deep clones a layout and changes its settings to make it "locked".
 * @param layout The Layout to be locked
 * @returns A restricted copy of the layout
 */
export declare const getLockedPageLayout: (layout: PageLayout) => any;
/**
 * Accepts a locked layout and an unlocked layout as a reference.
 * Takes the layout settings of the reference layout and merges them into the locked layout, thereby unlocking it.
 * @param lockedLayout The Layout to unlock
 * @param referenceUnlockedLayout The Layout to serve as a reference of an unlocked layout
 * @returns An unlocked version of the target layout
 */
export declare const getUnlockedLayout: (lockedLayout: PageLayout, referenceUnlockedLayout: PageLayout) => any;
/**
 * Replaces the layout of the window with the provided layout and adjusts it based on provided page's options
 * @param layout Layout with which to replace current window's layout
 * @param page Page object
 * @returns
 */
export declare const replaceLayout: (layout: PageLayout, page: AttachedPage) => Promise<void>;
export declare const findViewInLayout: (node: any, viewId: OpenFin.Identity) => any[];
/**
 * Calculates the total number of views in a given layout configuration.
 *
 * @param node - The layout configuration to traverse.
 * @returns The total number of views in the layout configuration.
 */
export declare const countViews: (node: OpenFin.LayoutContent) => number;
export declare const getLayoutConfig: (layoutContainerKey: string) => Promise<any>;
export declare const updateTabStateBasedOnViewCount: (page: AttachedPageInternal, viewCount: number) => Promise<void>;
export declare const updatePageForViewCount: (activePage: AttachedPageInternal | undefined) => Promise<void>;
export declare const debouncedUpdatePageForViewCount: import("lodash").DebouncedFunc<(activePage: AttachedPageInternal | undefined) => Promise<void>>;
export declare const findPageForView: (viewName: string, browserWindowIdentity?: WindowIdentity) => Promise<AttachedPage | undefined>;
/**
 * Only show the view tab icon when not on the landing page
 */
export declare const hideFavIconForLandingPage: (view: OpenFin.View, tab: HTMLElement) => Promise<void>;
