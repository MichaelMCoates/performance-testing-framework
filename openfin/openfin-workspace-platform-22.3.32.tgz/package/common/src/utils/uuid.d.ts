/**
 * Generates a random UUID.
 *
 * Works in insecure contexts (e.g. HTTP).
 *
 * @returns A random UUID.
 */
export declare function randomUUID(): string;
