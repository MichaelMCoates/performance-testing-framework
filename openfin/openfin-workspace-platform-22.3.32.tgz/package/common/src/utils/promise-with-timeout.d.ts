export declare const awaitPromiseWithTimeout: (promise: Promise<any>, timeout: number, timoutErrorMessage: string) => Promise<any>;
