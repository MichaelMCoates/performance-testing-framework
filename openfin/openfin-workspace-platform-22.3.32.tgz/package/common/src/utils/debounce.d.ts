declare const makeDebouncedFunc: <T extends (...args: any[]) => Promise<any>>(func: T, debounceTimeout?: number) => T;
/**
 * Debounce a specified function.
 *
 * When the debounced function is called, the underlying wrapped function
 * will be called.
 *
 * If the function is called again while the promise returned by the wrapped
 * function is still resolving, the call will be blocked until the promise has
 * resolved.
 *
 * Once the promise has been resolved, the wrapped function will be called again
 * after a specified debounce timeout.
 *
 */
export default makeDebouncedFunc;
