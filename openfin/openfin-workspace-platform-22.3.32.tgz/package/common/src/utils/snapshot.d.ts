import type OpenFin from '@openfin/core';
export type SnapshotDetailsExtended = OpenFin.Snapshot['snapshotDetails'] & {
    machineId: string;
    machineName?: string;
};
export type SnapshotExtended = OpenFin.Snapshot & {
    snapshotDetails: SnapshotDetailsExtended;
};
export type ApplySnapshotOptionsExtended = OpenFin.ApplySnapshotOptions & {
    attachToExistingWindow: boolean;
};
/**
 * Set a friendly name of the current machine.
 * @param name the friendly name.
 */
export declare function setMachineName(name: string): void;
/**
 * Get the machine's friendly name.
 * @returns the machine's friendly name.
 */
export declare function getMachineName(): string;
/**
 * Get the current machine ID.
 * @returns the machine ID.
 */
export declare function getMachineId(): Promise<string>;
export declare const updateActivePage: (browserWindow: OpenFin.WindowOptions) => OpenFin.WindowOptions;
/**
 * Get a snapshot with extra snapshot details.
 * @param snapshot the snapshot to extend.
 * @returns the snapshot with more snapshot details.
 */
export declare function getSnapshotExtended(snapshot?: OpenFin.Snapshot): Promise<SnapshotExtended>;
