/**
 * LRU Cache
 */
export default class LRUCache<T> {
    #private;
    constructor(capacity: number);
    get(key: string): T | undefined;
    has(key: string): boolean;
    put(key: string, value: T): void;
    private updateQueue;
}
