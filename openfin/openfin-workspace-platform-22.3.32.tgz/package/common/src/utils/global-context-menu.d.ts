import type OpenFin from '@openfin/core';
import { MenuItemType } from '../../../common/src/utils/context-menu';
import * as WP from '../../../client-api-platform/src/index';
import { GlobalContextMenuItemTemplate, GlobalContextMenuOptionType, Workspace } from '../../../client-api-platform/src/shapes';
export declare const getCloseWindow: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const getQuitPlatform: (isEnterprise?: boolean) => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const newWindow: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const savePage: (isEnterprise?: boolean) => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const savePageAs: (isEnterprise?: boolean) => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const newPage: (enabled: boolean, isEnterprise?: boolean) => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
    enabled: boolean;
};
export declare const restoreChanges: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const saveWorkspace: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const saveWorkspaceAs: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const printMenuOptions: (isViewSelected: boolean) => Promise<GlobalContextMenuItemTemplate>;
export declare const manageDesktopSignals: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const renameWorkspace: () => {
    type: MenuItemType;
    label: string;
    data: {
        type: WP.GlobalContextMenuOptionType;
    };
};
export declare const switchWorkspace: () => {
    label: string;
};
export declare const deleteWorkspace: () => {
    label: string;
};
export declare const downloads: () => {
    label: string;
};
export declare const appearance: () => {
    label: string;
};
export declare const getSavedWorkspaceContextMenuOptions: (activeWorkspace: Workspace, savedWorkspaces: Pick<Workspace, "workspaceId" | "title">[], contextMenuOptionType: GlobalContextMenuOptionType) => {
    label: string;
    type: MenuItemType;
    enabled: boolean;
    checked: boolean;
    data: {
        type: WP.GlobalContextMenuOptionType;
        workspaceId: string;
    };
}[];
export declare const getAppearanceContextMenuOptions: () => Promise<{
    label: string;
    type: MenuItemType;
    checked: boolean;
    data: {
        type: WP.GlobalContextMenuOptionType;
        scheme: WP.ColorSchemeOptionType;
    };
}[]>;
export declare const getGlobalContextMenuTemplate: (winIdentity: OpenFin.Identity, selectedViews?: OpenFin.Identity[]) => Promise<GlobalContextMenuItemTemplate[]>;
