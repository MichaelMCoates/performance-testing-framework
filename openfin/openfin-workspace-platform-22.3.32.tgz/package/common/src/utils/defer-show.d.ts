import type OpenFin from '@openfin/core';
interface InternalWindowOptions extends OpenFin.PlatformWindowCreationOptions {
    workspacePlatform: OpenFin.WindowOptions['workspacePlatform'] & {
        _internalDeferShowOptions?: {
            setAsForeground?: boolean;
            autoShow?: boolean;
            deferShowEnabled?: boolean;
        };
    };
}
/**
 * This function prevents a created window from being auto shown by the Core.
 * The Core will auto show the window before the window has a chance to register a listener to prevent it.
 * With these options applied, the window must call `setCanShow(true)` when it is ready to be shown.
 * If `autoShow` was originally true, the window will be show upon the first call to `setCanShow(true)`.
 *
 * By applying these options it is assumed that the window calls `registerDeferShow()` and `setCanShow(true)`.
 *
 * This function should be used in conjunction the `withDeferShow` platform middleware.
 * `withDeferShow` will prevent the window from being shown before the window has launched and registered
 * its show requested listener.
 *
 * @param opts the options to modify.
 * @param setAsForeground the option to focus the window when it is shown
 * @returns the modified options.
 */
export declare const applyDeferShowOptions: <T>(opts: T, setAsForeground?: boolean) => InternalWindowOptions & T;
/**
 * This function is a middleware that can be applied to a platform's `createWindow` function.
 * If the defer show API has been enabled in window options using the `applyDeferShowOptions` function
 * the window will be prevented from showing.
 * @param superCreateWindow the create window method to decorate.
 * @returns the `createWindow` method wrapped with this middleware.
 */
export declare const withDeferShow: (superCreateWindow: (opts: OpenFin.PlatformWindowCreationOptions, callerIdentity: OpenFin.Identity) => Promise<OpenFin.Window>) => (opts: OpenFin.PlatformWindowCreationOptions, callerIdentity: OpenFin.Identity) => Promise<OpenFin.Window>;
/**
 * Assert if the window is able to be shown or not.
 * Upon calling `setCanShow(true)`, if the window was previously prevented
 * from being shown, this function will show the window.
 * @param bool true if the window should be able to be shown. (Default is false)
 */
export declare const setCanShow: (bool: boolean) => Promise<void>;
/**
 * Add a listener that defers showing the current window.
 * To allow the window to be shown, `setCanShow(true)` must be called.
 * Upon calling `setCanShow(true)`, if the window was previously prevented
 * from being shown, it will show.
 */
export declare const registerDeferShow: () => Promise<void>;
export {};
