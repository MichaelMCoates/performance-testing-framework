import { Dexie, EntityTable } from 'dexie';
export declare const getNamespacedDbName: (name: string) => string;
type DexieStore = {
    [key: string]: EntityTable<any, any>;
};
type DexieDB = Dexie & DexieStore;
export declare const getNewStoreAndMigrateLegacyStore: (storeName: string, tableName: string) => DexieDB;
export {};
