import type OpenFin from '@openfin/core';
import { ViewTabContextMenuTemplate } from '../../../client-api-platform/src/shapes';
export declare const getChannelsMenuOptions: (channelsForViews: string[], colorGroups: OpenFin.ContextGroupInfo[]) => Promise<ViewTabContextMenuTemplate[]>;
export declare const ENTERPRISE_COLOR_CHANNELS: Map<string, OpenFin.ContextGroupInfo['displayMetadata']>;
