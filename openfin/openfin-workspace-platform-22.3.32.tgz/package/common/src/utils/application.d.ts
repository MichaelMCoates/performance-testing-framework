import type OpenFin from '@openfin/core';
export declare enum ApplicationUUID {
    /**
     * The UUID of workspace.
     * Home is a part of this application.
     */
    Workspace = "openfin-workspace",
    OldWorkspace = "openfin-browser"
}
export interface ApplicationEvent {
    viewIdentity?: OpenFin.Identity;
    name?: string;
    uuid?: string;
}
export type ApplicationListener = (ev: ApplicationEvent) => void;
export declare enum LaunchModeType {
    FinProtocol = "fin-protocol"
}
export type ApplicationInfoExtended = OpenFin.ApplicationInfo & {
    initialOptions: OpenFin.ApplicationInfo['initialOptions'] & {
        userAppConfigArgs: any;
    };
};
export declare const getCurrentOFApplication: () => Promise<OpenFin.Application>;
export declare const getWorkspaceOFApplication: () => Promise<OpenFin.Application>;
