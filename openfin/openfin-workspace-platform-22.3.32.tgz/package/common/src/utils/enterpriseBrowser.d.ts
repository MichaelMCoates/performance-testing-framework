import type OpenFin from '@openfin/core';
import { BrowserInitConfig } from '../../../client-api-platform/src/shapes';
export declare const DEFAULT_ENTERPRISE_WINDOW_HEIGHT = 600;
export declare const DEFAULT_ENTERPRISE_WINDOW_WIDTH = 900;
export declare const ENTERPRISE_MIN_WINDOW_HEIGHT = 488;
export declare const ENTERPRISE_MIN_WINDOW_WIDTH = 654;
export declare const isEnterpriseBrowser: (id?: OpenFin.Identity) => Promise<boolean>;
export declare const isEnterpriseBrowserPlatform: (browserInitOptions: BrowserInitConfig) => boolean;
export declare function formatUrl(url: string): string;
export declare const getIsEnterpriseBrowser: (id?: OpenFin.Identity) => Promise<boolean>;
export declare const isLandingPage: (url: string) => boolean;
export declare const isLandingPageOrEmpty: (url: string) => boolean;
export declare const isDefaultEnterpriseView: (viewIdentity: OpenFin.Identity) => boolean;
export declare const getAICompanionViewIdentity: (browserIdentity?: OpenFin.Identity) => {
    uuid: string;
    name: string;
};
export declare const getSearchMenuViewIdentity: (browserIdentity?: OpenFin.Identity) => {
    uuid: string;
    name: string;
};
