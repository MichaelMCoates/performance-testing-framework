export declare enum Env {
    Local = "local",
    Dev = "dev",
    Staging = "staging",
    Prod = "prod"
}
export declare const finEnv: {
    isFin: boolean;
    uuid: string;
    name: string;
    entityType: "window" | "view" | "";
};
export declare let isFin: boolean;
export declare const isJest: boolean;
export declare const isWindowDefined: boolean;
export declare const isDocumentDefined: boolean;
export declare const isWindowDefinedWithIndexDB: boolean;
export declare let finUUID: string;
export declare let finName: string;
export declare let finEntityType: "" | "window" | "view";
export declare const finReady: Promise<void>;
export declare const isEnvLocal: boolean;
export declare const isEnvDev: boolean;
export declare const isEnvStaging: boolean;
export declare const isEnvProd: boolean;
export declare const workspaceProviderFinsLink: string;
export declare const workspaceProviderFallbackUrl: string;
export declare const workspaceCdnUrl: string;
export declare const workspaceCdnEnvUrl: string;
export declare const workspaceDocsPlatformUrl: string;
export declare const workspaceDocsClientUrl: string;
export declare const workspaceRuntimeVersion: string;
export declare const workspaceBuildVersion: string;
export declare const workspaceBuildSha: string;
