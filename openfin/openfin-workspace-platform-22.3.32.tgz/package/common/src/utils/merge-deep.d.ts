/**
 * Deep merge a set of source objects into a single target object.
 * @param target the target object to merge sources into.
 * @param sources the source objects to merge into the target. (FIFO)
 */
export declare function mergeDeep(target: any, ...sources: any[]): any;
