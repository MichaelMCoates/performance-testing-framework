import type OpenFin from '@openfin/core';
import { EnterpriseMainContextMenuItemData, EnterpriseMainContextMenuItemTemplate, OpenGlobalContextMenuPayload } from '../../../client-api-platform/src/shapes';
export declare const getEnterpriseContextMenuTemplate: ({ identity, selectedViews }: {
    identity: OpenFin.Identity;
    selectedViews: OpenFin.Identity[];
}) => Promise<EnterpriseMainContextMenuItemTemplate[]>;
export declare const handleEnterpriseMenuResponse: (data: EnterpriseMainContextMenuItemData, payload: OpenGlobalContextMenuPayload) => Promise<boolean>;
