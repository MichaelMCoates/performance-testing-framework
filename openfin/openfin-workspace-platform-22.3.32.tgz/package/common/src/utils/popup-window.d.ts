import type OpenFin from '@openfin/core';
import { UserMenuParams } from '../../../common/src/utils/menu';
import { OptionalExceptFor } from '../../../common/src/utils/types';
import { AnchorBehavior } from '../../../client-api-platform/src/api/context-menu';
import { Site, SiteAction } from '../../../client-api-platform/src/shapes';
export declare enum SaveMenuType {
    Save = "Save",
    SaveAs = "SaveAs"
}
type SearchViewExpansionState = {
    method?: 'click' | 'keystroke';
    shouldExpand: boolean;
};
export declare function showModalWin<T extends keyof UserMenuParams>(params: UserMenuParams[T], windowOpts: OptionalExceptFor<OpenFin.WindowOptions, 'x' | 'y' | 'defaultWidth' | 'url' | 'name'>): Promise<OpenFin.Window>;
export type SearchMenuChannelMessage = {
    selectedViews: OpenFin.Identity[];
    openViews: OpenFin.Identity[];
    windowId: OpenFin.Identity;
    searchText?: string;
    keyboardEvent?: BrowserSearchMenuKeyboardEvent;
    shouldExpandMenu?: SearchViewExpansionState;
    offsetLeft?: number;
    type: 'update-search-menu-state';
} | {
    type: 'ready';
};
export type BrowserSearchMenuKeyboardEvent = {
    type: string;
    options: {
        key: string;
        metaKey?: boolean;
        ctrlKey?: boolean;
        altKey?: boolean;
    };
};
export declare enum EnterpriseMenuType {
    GlobalMenu = "global-menu",
    ContextMenu = "context-menu",
    RenameSupertab = "rename-supertab",
    AddEditBookmark = "add-edit-bookmark",
    DropdownMenu = "dropdown-menu",
    ZoomControls = "zoom-controls"
}
export type BookmarkButtonPayload = {
    selectedViewIdentity: OpenFin.Identity;
};
export type BaseEnterpriseMenuChannelMessage = {
    type: EnterpriseMenuType;
    /**
     * The identity of the window the dialog/menu invocation came from.
     */
    parentIdentity: OpenFin.Identity;
    /**
     * The identity of the window the dialog/menu should respond to.
     *
     * This may differ from the parentIdentity, such as in the case of custom context menus, where the
     * parent is a browser window but the context menu should respond to the provider window.
     */
    responseIdentity: OpenFin.Identity;
    anchorBehavior?: AnchorBehavior;
    x: number;
    y: number;
};
export type ContextMenuChannelMessage = BaseEnterpriseMenuChannelMessage & {
    type: EnterpriseMenuType.ContextMenu | EnterpriseMenuType.GlobalMenu;
    /**
     * The unique request ID of the context menu invocation.
     */
    requestId: string;
    payload: OpenFin.ShowPopupMenuOptions;
};
export type BookmarkDialogChannelMessage = BaseEnterpriseMenuChannelMessage & {
    type: EnterpriseMenuType.AddEditBookmark;
    payload: BookmarkButtonPayload;
};
export type ZoomControlsDialogPayload = {
    selectedViewIdentity?: OpenFin.Identity;
    zoomPercent?: number;
};
export type ZoomControlsDialogChannelMessage = BaseEnterpriseMenuChannelMessage & {
    type: EnterpriseMenuType.ZoomControls;
    payload: ZoomControlsDialogPayload;
};
export type DropdownMenuChannelMessage = BaseEnterpriseMenuChannelMessage & {
    type: EnterpriseMenuType.DropdownMenu;
    payload: {
        template: Array<OpenFin.MenuItemTemplate>;
        /**
         * The width of the dropdown element in the DOM to determine the width of the menu window.
         */
        width: number;
    };
};
export type RenameSupertabChannelMessage = BaseEnterpriseMenuChannelMessage & {
    type: EnterpriseMenuType.RenameSupertab;
    payload: {
        /**
         * The pageId of the page being renamed.
         */
        pageId: string;
    };
};
export type SearchMenuChannelResponse = {
    type: 'ready';
} | {
    type: 'search-response';
    selectedSite?: Site;
    searchText?: string;
    selectedView: OpenFin.Identity;
    inputUpdate?: string;
    trigger?: SiteAction;
    handled?: boolean;
} | {
    type: 'resize-view';
    width: number;
} | {
    type: 'keyboard-event';
    keyboardEvent: BrowserSearchMenuKeyboardEvent;
} | {
    type: 'search-provider-changed';
};
export declare function showPopupWin<T extends keyof UserMenuParams>(parentWindow: OpenFin.Window, params: UserMenuParams[T], windowOpts: OpenFin.PopupOptions): Promise<OpenFin.PopupResult>;
export {};
