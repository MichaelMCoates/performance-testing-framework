/**
 * Pick specific keys from an object.
 * lodash.pick is deprecated and says to use destructuring instead, but that has one key flaw, it adds undefined properties to the result if the key is not present in the object.
 * ie `const { a, b } = obj; return {a,b};` will result in `{ a: undefined, b: undefined }` if `a` or `b` are not present in `obj`.
 * pick({}, ['a', 'b']) will result in `{}` if `a` or `b` are not present in the object.
 */
export declare function pick<T extends object, K extends keyof T>(obj: T, keys: K[]): Pick<T, K>;
