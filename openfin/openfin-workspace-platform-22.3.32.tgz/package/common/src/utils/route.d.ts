/**
 * All routes that serve HTML pages for the app.
 * Routes should include the zone that the HTML page is a part of.
 * Make sure to include trailing slash, as it is essential for deployed version to route correctly.
 */
declare enum WorkspaceRoute {
    Home = "/home/",
    HomeSearch = "/home/?deeplink=search",
    HomePagesRename = "/home/pages/rename/",
    Dock = "/dock/",
    Docs = "/provider/docs/",
    Storefront = "/storefront/",
    DeprecatedAlert = "/provider/deprecated-alert/",
    Analytics = "/provider/analytics/",
    Provider = "/provider/"
}
declare enum BrowserRoute {
    Browser = "/browser/",
    BrowserPopupMenu = "/popup-menu/",
    BrowserPopupMenuSaveModal = "/popup-menu/save-modal/",
    BrowserPopupMenuLayouts = "/popup-menu/layouts/layouts/",
    BrowserPopupMenuColorLinking = "/popup-menu/color-linking/color-linking/",
    BrowserIndicator = "/indicator/",
    BrowserPopupMenuAddressSearchResultsView = "/popup-menu/address-search-results-view/",
    ResponseModal = "/popup-menu/response-modal/",
    CloseConfirmationModal = "/popup-menu/close-confirmation-modal/",
    EnterpriseBrowser = "/enterprise/",
    EnterpriseLandingPage = "/enterprise/landing/",
    EnterpriseContextMenu = "/context-menu/",
    EnterpriseBookmarkDialog = "/bookmark-dialog/",
    EnterpriseAboutPage = "/popup-menu/about/",
    DropdownMenu = "/dropdown-menu/",
    EnterpriseDock = "/dock/",
    ZoomControlsDialog = "/zoom-controls-dialog/",
    DesktopSignalsModal = "/popup-menu/desktop-signals-modal/"
}
declare const PageRoute: {
    Browser: BrowserRoute.Browser;
    BrowserPopupMenu: BrowserRoute.BrowserPopupMenu;
    BrowserPopupMenuSaveModal: BrowserRoute.BrowserPopupMenuSaveModal;
    BrowserPopupMenuLayouts: BrowserRoute.BrowserPopupMenuLayouts;
    BrowserPopupMenuColorLinking: BrowserRoute.BrowserPopupMenuColorLinking;
    BrowserIndicator: BrowserRoute.BrowserIndicator;
    BrowserPopupMenuAddressSearchResultsView: BrowserRoute.BrowserPopupMenuAddressSearchResultsView;
    ResponseModal: BrowserRoute.ResponseModal;
    CloseConfirmationModal: BrowserRoute.CloseConfirmationModal;
    EnterpriseBrowser: BrowserRoute.EnterpriseBrowser;
    EnterpriseLandingPage: BrowserRoute.EnterpriseLandingPage;
    EnterpriseContextMenu: BrowserRoute.EnterpriseContextMenu;
    EnterpriseBookmarkDialog: BrowserRoute.EnterpriseBookmarkDialog;
    EnterpriseAboutPage: BrowserRoute.EnterpriseAboutPage;
    DropdownMenu: BrowserRoute.DropdownMenu;
    EnterpriseDock: BrowserRoute.EnterpriseDock;
    ZoomControlsDialog: BrowserRoute.ZoomControlsDialog;
    DesktopSignalsModal: BrowserRoute.DesktopSignalsModal;
    Home: WorkspaceRoute.Home;
    HomeSearch: WorkspaceRoute.HomeSearch;
    HomePagesRename: WorkspaceRoute.HomePagesRename;
    Dock: WorkspaceRoute.Dock;
    Docs: WorkspaceRoute.Docs;
    Storefront: WorkspaceRoute.Storefront;
    DeprecatedAlert: WorkspaceRoute.DeprecatedAlert;
    Analytics: WorkspaceRoute.Analytics;
    Provider: WorkspaceRoute.Provider;
};
type PageRoute = WorkspaceRoute | BrowserRoute;
export declare const Assets: {
    readonly IconOpenFinLogo: "/icons/openfinlogo.svg";
    readonly IconFilter: "/icons/filter.svg";
    readonly LightStorefront: "/icons/store-icon-light.png";
    readonly DarkStorefront: "/icons/store-icon-dark.png";
    readonly CallIconLight: "/icons/call-icon-light.svg";
    readonly CallIconDark: "/icons/call-icon-dark.svg";
    readonly ChatIconLight: "/icons/chat-icon-light.svg";
    readonly ChatIconDark: "/icons/chat-icon-dark.svg";
    readonly MessageIconLight: "/icons/message-icon-light.svg";
    readonly MessageIconDark: "/icons/message-icon-dark.svg";
    readonly Microsoft365Assets: {
        readonly Microsoft365DocumentIcon: "/microsoft-365-integration-assets/microsoft-365-document-icon.svg";
        readonly Microsoft365ExcelIcon: "/microsoft-365-integration-assets/microsoft-365-excel-icon.svg";
        readonly Microsoft365PowerpointIcon: "/microsoft-365-integration-assets/microsoft-365-powerpoint-icon.svg";
        readonly Microsoft365OutlookIcon: "/microsoft-365-integration-assets/microsoft-365-outlook-icon.svg";
        readonly Microsoft365TeamsIcon: "/microsoft-365-integration-assets/microsoft-365-teams-icon.svg";
        readonly Microsoft365Icon: "/microsoft-365-integration-assets/microsoft-365-icon.svg";
        readonly PDFFileIcon: "/microsoft-365-integration-assets/pdf-file-icon.svg";
    };
    readonly DockIconLight: "/icons/dock-icon-light.png";
    readonly DockIconDark: "/icons/dock-icon-dark.png";
};
/**
 * Home DeepLink Options
 */
export declare enum HomeDeepLink {
    Search = "search"
}
export default PageRoute;
