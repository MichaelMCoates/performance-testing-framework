import type OpenFin from '@openfin/core';
import { ResponseModalConfig } from './menu-config';
import { Point } from './window';
/**
 *
 * @param parentWindowIdentity parent window for the modal
 * @returns a point (top/left) that represents the center of the monitor the parent window is on
 */
export declare const getCenterOfParentWindowMonitor: (parentWindowIdentity?: OpenFin.Identity) => Promise<Point>;
/**
 * returns the correct bounds for the response modal to be displayed at
 * this will return the correct bounds regardless of whether the window is maximized
 *
 * @param modalOptions window options including height/width so that we can calculate the correct bounds
 * @param parentWindowIdentity the window to get the bounds from. If this is undefined, the primary monitor will be used
 * @param centerOnMonitor whether the modal should be centered on the monitor
 * @returns the bounds for where the modal is to be displayed
 */
export declare const getResponseModalBounds: (modalOptions: ResponseModalConfig["windowOptions"], parentWindowIdentity?: OpenFin.Identity, centerOnMonitor?: boolean) => Promise<OpenFin.Bounds>;
export declare function getResponseModalBoundsAndCenterParentIfModalOffScreen(modalOptions: ResponseModalConfig['windowOptions'], parentWindowIdentity?: OpenFin.Identity, centerOnMonitor?: boolean): Promise<OpenFin.Bounds>;
/**
 * Adjusts the given bounds to be within the closest monitor's available bounds if they are offscreen.
 *
 * @param {OpenFin.Bounds} bounds - The bounds to be adjusted.
 * @returns {Promise<OpenFin.Bounds>} - The adjusted bounds that are within the closest monitor's available bounds.
 */
export declare function getClosestBoundsIfModalBoundsOffscreen(bounds: OpenFin.Bounds): Promise<OpenFin.Bounds>;
/**
 * Adjusts the given bounds if they are offscreen to be within the closest monitor's available bounds.
 * Returns bounds relative to the parent window's bounds (as opposed to bounds relative to the monitor).
 *
 * @param {OpenFin.WindowBounds} parentWindowBounds - The bounds of the parent window.
 * @param {OpenFin.Bounds} bounds - The bounds to be adjusted.
 * @returns {Promise<OpenFin.Bounds>} - The adjusted bounds that are within the closest monitor's available bounds relative to the parent window's bounds.
 */
export declare const getClosestRelativeBoundsIfModalBoundsOffscreen: (parentWindowBounds: OpenFin.WindowBounds, bounds: OpenFin.Bounds) => Promise<OpenFin.Bounds>;
/**
 * Returns whether a window is maximized and the OS is Windows 10 or 11.
 * Relates to: https://github.com/electron/electron/issues/4045
 *
 * @param window - The OpenFin window.
 * @returns A promise that resolves to a boolean indicating whether a window is maximized and the OS is Windows 10 or 11.
 */
export declare const getIsWindowMaximizedOnWindows10Or11: (window: OpenFin.Window) => Promise<boolean>;
/**
 * Retrieves the current bounds of a window whether it's maximized or minimized.
 * For maximized windows on Windows 10 and 11, it will return adjusted bounds to account for an Electron bug where a 7px
 * shadow is included in the measurement of the window bounds.
 *
 * Relates to: https://github.com/electron/electron/issues/4045
 *
 * @param windowIdentity - The identity of the window.
 * @returns A promise that resolves to the current window bounds.
 */
export declare const getCurrentBounds: (windowIdentity: OpenFin.Identity) => Promise<OpenFin.WindowBounds>;
export declare function getBoundsCenteredAndFitOnMonitor(height: number, width: number, monitorRect?: OpenFin.MonitorDetails): Promise<{
    height: number;
    width: number;
    left: number;
    top: number;
}>;
