export declare function setLocalBrowserUrl(url: string): void;
export declare const removeTrailingSlash: (url: string) => string;
/**
 * Get the base url override if it exists
 *
 * @returns The base url override if it exists, otherwise null
 */
export declare function getBaseUrl(): Promise<string>;
/**
 * Get the browser base url
 * @param returnUrlWithATrailingSlash - if true, the url is returned with a trailing slash, if false it is not.
 * @returns The browser base url override if it exists, otherwise null
 */
export declare function getBrowserBaseUrl(returnUrlWithATrailingSlash?: boolean): Promise<string>;
/**
 * Get the enterprise browser base url
 * @param returnUrlWithATrailingSlash - if true, the url is returned with a trailing slash, if false it is not.
 * @returns The browser base url override if it exists, otherwise null
 */
export declare function getEnterpriseBaseUrl(returnUrlWithATrailingSlash?: boolean): Promise<string>;
export declare function getEnterpriseLandingUrl(): Promise<string>;
/**
 * Get the enterprise browser or the workspace browser base url
 * @param isEnterprise - if true, we are in enterprise browser
 * @param returnUrlWithATrailingSlash - if true, the url is returned with a trailing slash, if false it is not.
 * @returns The browser base url override if it exists, otherwise null
 */
export declare const getDefaultBrowserUrl: (isEnterprise: boolean, returnUrlWithATrailingSlash?: boolean) => Promise<string>;
