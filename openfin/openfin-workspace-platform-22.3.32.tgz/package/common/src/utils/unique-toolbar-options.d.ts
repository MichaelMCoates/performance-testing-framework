import { ToolbarButton } from '../../../client-api-platform/src/shapes';
export declare const checkUniqueToolbarOptions: (toolbarOptions?: ToolbarButton[]) => void;
