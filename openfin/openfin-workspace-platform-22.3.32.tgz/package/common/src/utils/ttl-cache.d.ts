/**
 * TTLCache class that provides a simple cache mechanism with TTL (Time To Live) functionality.
 * It also maintains a maximum capacity and evicts the oldest entry when the capacity is reached.
 */
export default class TTLCache<T> {
    #private;
    /**
     * TTLCache constructor.
     * @param ttl - Time to live in milliseconds. Defaults to 300000 (5 minutes).
     * @param capacity - Maximum capacity of the cache. Defaults to 100.
     */
    constructor(ttl?: number, capacity?: number);
    /**
     * Retrieves a value from the cache.
     * @param key - The key to identify the cached item.
     * @returns The cached item or null if the item does not exist or is expired.
     */
    get(key: string): T | null;
    /**
     * Stores a value in the cache.
     * If the cache is at capacity, the oldest entry will be removed.
     * @param key - The key to identify the item to be cached.
     * @param value - The value to be cached.
     */
    put(key: string, value: T): void;
    /**
     * Removes a value from the cache.
     * @param key - The key identifying the item to be removed.
     */
    remove(key: string): void;
    /**
     * Clears the entire cache.
     */
    clear(): void;
}
