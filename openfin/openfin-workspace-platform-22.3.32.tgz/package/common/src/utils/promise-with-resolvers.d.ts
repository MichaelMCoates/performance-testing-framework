/**
 * Polyfill for `Promise.withResolvers` which is not available in this typescript version.
 */
export declare function withResolvers<T>(): PromiseWithResolvers<T>;
export type PromiseWithResolvers<T> = {
    promise: Promise<T>;
    resolve: (value: T | PromiseLike<T>) => void;
    reject: (reason?: any) => void;
};
