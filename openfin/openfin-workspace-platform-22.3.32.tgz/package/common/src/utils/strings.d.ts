export declare const capitalize: (s: string) => string;
export declare const pascalize: (s: string) => string;
export declare const isStringMatchesQuery: (title: string, query?: string) => boolean;
export declare const log: {
    /**
     * Calls console.debug with provided parameters and stringifies JS objects prior to logging
     */
    debug: (...args: unknown[]) => void;
};
