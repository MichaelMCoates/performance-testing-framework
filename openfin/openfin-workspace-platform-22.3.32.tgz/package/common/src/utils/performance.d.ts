export declare const workspacePerformancePrefix = "of-workspace-";
type WorkspacePerformanceMarks = 'home-registration' | 'dock-registration' | 'store-registration' | 'home-show' | 'dock-show' | 'store-show' | 'workspace-app-started' | 'home-window-initialized' | 'dock-window-initialized' | 'store-window-initialized';
type BrowserWindowPerformanceMarks = string;
type PerformanceMarks = WorkspacePerformanceMarks | BrowserWindowPerformanceMarks;
/**
 * @classdesc
 * WorkspacePerformance is a class that provides a set of methods to measure performance of workspace
 *
 */
declare class WorkspacePerformance {
    mark(markName: PerformanceMarks): void;
    markStart(markName: PerformanceMarks): void;
    markEnd(markName: PerformanceMarks): void;
    markEndAndMeasure(markName: PerformanceMarks): PerformanceMeasure;
    markAndMeasure(markName: PerformanceMarks, measureAgainst: PerformanceMarks): PerformanceMeasure;
    reportWorkspacePerformanceEntries(): PerformanceEntry[];
    reportWorkspacePerformance(): {
        name: string;
        duration: number;
    }[];
}
declare const workspacePerformance: WorkspacePerformance;
export default workspacePerformance;
