export declare const createNamespacedLocalStorage: <TKey extends string>(namespace: string) => Pick<Storage, "setItem" | "getItem" | "removeItem">;
export declare const setItem: Storage['setItem'];
export declare const getItem: Storage['getItem'];
export declare const removeItem: Storage['removeItem'];
