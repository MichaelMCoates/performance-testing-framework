import { SaveModalType } from '../../../client-api-platform/src/shapes';
export declare enum Menu {
    SAVE = "SAVE_MENU",
    SHARE = "SHARE_MENU",
    COLOR_LINK = "COLOR_LINK_MENU",
    LAYOUT = "LAYOUT_MENU"
}
export interface UserMenuParams {
    [Menu.SAVE]: {
        id: string;
        menuType: SaveModalType;
        invocationId?: string;
    };
    [Menu.SHARE]: {
        id: string;
        title: string;
    };
    [Menu.LAYOUT]: null;
    [Menu.COLOR_LINK]: {
        selectedViews: string;
    } | null;
}
