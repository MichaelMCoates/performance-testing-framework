import type OpenFin from '@openfin/core';
export default function makeShowIndicator(opts?: OpenFin.PlatformWindowCreationOptions): (namespace: string, url: string, message: string, type: string, secondaryMessage: string) => Promise<void>;
