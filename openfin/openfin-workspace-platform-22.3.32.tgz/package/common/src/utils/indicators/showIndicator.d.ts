import { IconType } from '@openfin/ui-library';
import { PositioningType } from '../../../../common/src/utils/positioning';
import { IndicatorType } from '../../../../common/src/components/Indicator/Indicator.constants';
export type IndicatorIcon = Extract<IconType, 'LockClosedIcon' | 'LockOpen1Icon' | 'PageIcon' | 'BlockedIcon' | 'SupertabIcon' | 'BookmarkFilled'>;
export interface ShowIndicatorPayload {
    type: IndicatorType;
    message: string;
    parentBrowserName?: string;
    secondaryMessage?: string;
    icon?: IndicatorIcon;
    isEnterprise?: boolean;
    positioning?: PositioningType;
}
export interface ShowErrorPayload {
    message: string;
    parentBrowserName?: string;
    icon?: IndicatorIcon;
    isEnterprise?: boolean;
    positioning?: PositioningType;
}
export interface ShowSuccessPayload {
    message: string;
    parentBrowserName?: string;
    secondaryMessage?: string;
    icon?: IndicatorIcon;
    isEnterprise?: boolean;
    positioning?: PositioningType;
}
export interface ShowInfoPayload {
    message: string;
    parentBrowserName?: string;
    icon?: IndicatorIcon;
    isEnterprise?: boolean;
}
/**
 * Creates a window containing a visual indicator contained in a Browser Window
 * This function decides whether to call browser function or direct function
 */
export declare function showIndicator(payload: ShowIndicatorPayload): Promise<void>;
/**
 * Creates a window containing an error indicator
 */
export declare function showError(payload: ShowErrorPayload): Promise<void>;
/**
 * Creates a window containing a success indicator
 */
export declare function showSuccess(payload: ShowSuccessPayload): Promise<void>;
/**
 * Creates a window containing an info indicator
 */
export declare function showInfo(payload: ShowInfoPayload): Promise<void>;
/**
 * Creates a window centered on monitor containing a success indicator for switching workspaces
 */
export declare function showSwitchWorkspaceSuccess(): Promise<void>;
