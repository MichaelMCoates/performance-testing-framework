import { SaveButtonContextMenuItemTemplate } from '../../../client-api-platform/src/shapes';
export declare const getSaveButtonMenuTemplate: (pageId: string) => Promise<SaveButtonContextMenuItemTemplate[]>;
