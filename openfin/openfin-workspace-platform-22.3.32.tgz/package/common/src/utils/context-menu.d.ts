import type OpenFin from '@openfin/core';
import { AnchorBehavior } from '../../../client-api-platform/src/api/context-menu';
import { PageTabContextMenuItemTemplate, ViewTabContextMenuTemplate } from '../../../client-api-platform/src/shapes';
import { EnterpriseMenuType } from './popup-window';
export declare enum MenuItemType {
    Label = "normal",
    Separator = "separator",
    Submenu = "submenu",
    Checkbox = "checkbox"
}
export type ShowContextMenuResponse = OpenFin.MenuResult & {
    data: any;
    requestId?: string;
};
export declare function showContextMenu(opts: OpenFin.ShowPopupMenuOptions, win?: OpenFin.Window): Promise<ShowContextMenuResponse>;
export declare const showEnterpriseContextMenu: (opts: OpenFin.ShowPopupMenuOptions, type: EnterpriseMenuType, anchorBehavior: AnchorBehavior, win?: OpenFin.Window) => Promise<ShowContextMenuResponse>;
export declare const Separator: OpenFin.MenuItemTemplate;
export declare const EmptyContextMenuItem: OpenFin.MenuItemTemplate;
export declare const DefaultSaveMenuBounds: {
    width: number;
    height: number;
};
export declare const getBoundsBasedOnAnchorBehavior: (bounds: OpenFin.Bounds, anchorBehavior: AnchorBehavior) => OpenFin.Bounds | {
    bottom: number;
    top: number;
    left: number;
    height: number;
    width: number;
};
export declare const getPrintOption: () => Promise<ViewTabContextMenuTemplate | PageTabContextMenuItemTemplate>;
