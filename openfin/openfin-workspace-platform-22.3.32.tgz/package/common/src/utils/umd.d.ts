declare const injectAPI: (namespace: string, api: any) => void;
export default injectAPI;
