import type OpenFin from '@openfin/core';
import { ApplicationUUID } from './application';
export declare enum WindowName {
    Home = "openfin-home",
    Dock = "openfin-dock",
    Storefront = "openfin-storefront",
    HomeInternal = "openfin-home-internal",
    BrowserMenu = "openfin-browser-menu",
    BrowserSaveMenu = "openfin-browser-save-menu",
    DockSaveWorkspaceMenu = "openfin-dock3-save-workspace-menu",
    BrowserIndicator = "openfin-browser-indicator",
    BrowserWindow = "internal-generated-window",
    ClassicWindow = "internal-generated-classic-window",
    EnterpriseContextMenu = "openfin-enterprise-context-menu",
    BrowserAddressSearchPrefix = "openfin-browser-menu-address-search-",
    EnterpriseBookmarkDialogWindow = "openfin-enterprise-bookmark-dialog",
    DropdownMenu = "openfin-enterprise-dropdown-menu",
    DockCompanion = "openfin-dock-companion",
    AICompanionPrefix = "openfin-ai-companion-",
    UpdateVersionModal = "here-update-version-modal",
    ZoomControlsDialog = "here-zoom-controls-dialog",
    AboutPageWindow = "here-about-page",
    DesktopSignalsModal = "here-desktop-signals-modal"
}
export interface WindowIdentity {
    uuid: ApplicationUUID | string;
    name: WindowName | string;
}
export interface WindowCreationOptionsExtended extends OpenFin.PlatformWindowCreationOptions {
    backgroundThrottling?: boolean;
}
export interface Point {
    left: number;
    top: number;
}
interface Size {
    height: number;
    width: number;
}
/**
 * Gets the center point of a window given its bounds
 *
 * @param bounds OpenFin WindowBounds - left, top, height, width
 * @returns A {@link OpenFin.Point} representing the center of the monitor
 */
export declare const getCenterFromBounds: (bounds: OpenFin.WindowBounds) => Point;
/**
 * Gets the center point of a monitor given its bounds
 *
 * @param bounds RectangleByEdgePositions - left, top, right, bottom. The bounds of the monitor
 * @returns A {@link OpenFin.Point} representing the center of the monitor
 */
export declare const getCenterFromMonitorBounds: (bounds: OpenFin.RectangleByEdgePositions) => Point;
/**
 * Gets the top and left coords of a window given its size and center point
 * @param center point representing the desired center coords
 * @param size height and width of the window
 * @returns coords representing the left, top of window given the center point
 */
export declare const getBoundsFromCenter: (center: Point, size: Size) => OpenFin.Bounds;
/**
 * Get a wrapped OpenFin window.
 *
 * This method can only be used in an OF env.
 * If used outside of OF, such as in a pre-rendering context, will throw a clear and traceable error.
 *
 * @param identity the window identity.
 * @returns the wrapped OpenFin window identity.
 */
export declare function getOFWindow(identity: WindowIdentity): OpenFin.Window;
/** The OpenFin identity for the process. */
export declare const currentOFIdentity: WindowIdentity;
/** Get the current OpenFin window. */
export declare function getCurrentOFWindow(): OpenFin.Window;
/** The OpenFin identity for the Home window. */
export declare const homeOFIdentity: {
    readonly name: WindowName.Home;
    readonly uuid: ApplicationUUID.Workspace;
};
/** The OpenFin identity for the Dock window. */
export declare const dockOFIdentity: {
    readonly name: WindowName.Dock;
    readonly uuid: ApplicationUUID.Workspace;
};
/** The OpenFin identity for the Notification Center window. */
export declare const notificationCenterOFIdentity: {
    readonly name: "Notification-Center";
    readonly uuid: "notifications-service";
};
/** The OpenFin identity for the Storefront window. */
export declare const storefrontOFIdentity: {
    readonly name: WindowName.Storefront;
    readonly uuid: ApplicationUUID.Workspace;
};
/** The OpenFin identity for the Provider window. */
export declare const providerOFIdentity: {
    readonly name: ApplicationUUID.Workspace;
    readonly uuid: ApplicationUUID.Workspace;
};
/**
 * Get the Home OpenFin window.
 */
export declare function getHomeOFWindow(): OpenFin.Window;
export declare function getDockOFWindow(): OpenFin.Window;
/**
 * Helper for max and restoring a window.
 * @param identity the identity of the window to maximize or restore.
 */
export declare function maxOrRestore(identity: WindowIdentity): Promise<void>;
/**
 * Helper for showing a window.
 * This method ensures the window is shown, brought to front and focused.
 * @param identity the identity of the window to show.
 */
export declare function showAndFocus(identity: WindowIdentity): Promise<void>;
/**
 * Helper for hiding a window.
 * This method ensures the window is hidden and blurred.
 * @param identity the identity of the window to hide.
 */
export declare function hide(identity: WindowIdentity): Promise<void>;
/**
 * Helper for showing / hiding a window.
 * This method calls showAndFocus / hideAndBlur
 * @param identity the identity of the window to hide.
 */
export declare function toggleVisibility(identity: WindowIdentity): Promise<void>;
export declare const toggleDock: () => Promise<void>;
export declare function isAnimatingSize(): boolean;
/**
 * Resizes a window to width and height saved in the store
 * if they differ from current window size.
 */
export declare function restoreWindowSize(): Promise<void>;
export declare function setSize(width: number, height: number): Promise<void>;
export declare function animateSize(width: number, height: number): Promise<void>;
/**
 * Returns true if the window identity is that of a browser window.
 * @param identity the window identity
 * @returns boolean
 */
export declare const isBrowserWindow: (identity: OpenFin.Identity) => Promise<any>;
/**
 * Force document body size. Called when resizing or on scaling changes.
 */
export declare function forceBodySize(): void;
/**
 * Gets all currently open browser windows.
 */
export declare function getBrowserWindows(): Promise<OpenFin.Window[]>;
export declare function getModalWindows(): Promise<OpenFin.Window[]>;
/**
 * Returns true if the OpenFin window for the provided identity is running.
 * */
export declare const isWindowRunning: (identity: WindowIdentity) => Promise<boolean>;
/**
 * Check if Storefront window is running.
 * @returns true if the Storefront window is running.
 */
export declare const isStorefrontWindowRunning: () => Promise<boolean>;
export declare const isDockWindowRunning: () => Promise<boolean>;
export declare const isHomeWindowRunning: () => Promise<boolean>;
export declare const isNotificationCenterWindowRunning: () => Promise<boolean>;
export declare const showAndFocusStorefront: () => Promise<void>;
export declare const showAndFocusDock: () => Promise<void>;
export declare const getDisableMultiplePagesOption: (identity: WindowIdentity) => Promise<any>;
export declare const getIsLockedOption: (identity: WindowIdentity) => Promise<any>;
export declare const getPlatformWindowTitle: (identity: WindowIdentity) => Promise<any>;
export declare const getComponentWindowStatus: () => Promise<{
    storefrontRunning: boolean;
    homeRunning: boolean;
}>;
export declare const deserializeWindowBounds: (serialized: string) => OpenFin.WindowBounds | null;
export declare const serializeWindowBounds: (bounds: OpenFin.WindowBounds) => string;
export declare const getWindowBounds: (window: OpenFin.Window) => Promise<OpenFin.RectangleByEdgePositions>;
/**
 * calculates the percenage of the window that is present within the monitor (float in range 0-1)
 *
 * @param bounds the bounds of the window
 * @param monitor the monitor to check against
 */
export declare function getPercentageOfBoundsInMonitor(bounds: OpenFin.Bounds, monitor: OpenFin.MonitorDetails): number;
export declare function getMonitorWindowMostOn(parentWindowBounds: OpenFin.Bounds): Promise<OpenFin.MonitorDetails>;
export {};
