import type PageRoute from '../../../../common/src/utils/route';
/**
 * Multiple different Next projects can be merged together into one using zones.
 * This is the path prefix to a single one of those deployed projects.
 * More information can be found here:
 * https://nextjs.org/docs/advanced-features/multi-zones
 */
export declare enum Zone {
    Home = "/home",
    Browser = "/browser",
    Enterprise = "/enterprise",
    Provider = "/provider",
    Storefront = "/storefront",
    Dock = "/dock"
}
export declare function getRouterZone(): "" | Zone;
/**
 * Gets the router's base path with the zone stripped out.
 */
export declare function getBasePathWithoutZone(): string;
/**
 * Get the router path to assets like images, json, svg, etc.
 * @returns the path to the
 */
export declare function getAssetPath(route: string): string;
/**
 * Gets the route without the zone prefix.
 * @param route the route to remove the zone prefix from.
 * @returns the route without the zone.
 */
export declare function getRouteWithoutZone(route: PageRoute | string): string;
/**
 * Get the absolute path to the route.
 */
export declare function getAbsoluteRoutePath(route: PageRoute | string): string;
/**
 * Get the base path of the router.
 * The base path of the router contains the router's zone as a postfix.
 */
export declare function getBasePath(): string;
export declare function resolveAbsolutePath(path: string, baseUrl?: URL): string;
/**
 * Gets the path to the route with the router's base path.
 * @param route the route.
 * @returns the route with the router's base path.
 */
export declare function getRoutePath(route: PageRoute): string;
/**
 * Concatenates a specified origin URL with a specified path.
 * @returns the origin concatenated with the specified path.
 */
export declare function getOriginWithPath(origin: string, path: string): string;
/**
 * Read query parameters of current window location.
 * @returns the query parameters.
 */
export declare function getQuery(): URLSearchParams;
export declare const getUrlParams: (path: string) => {
    [k: string]: string;
};
export declare function getPathnameWithBasePath(pathname: string): string;
/**
 * Get the current route.
 * @returns
 */
export declare function getCurrentRoute(): PageRoute;
