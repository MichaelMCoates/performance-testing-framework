import type OpenFin from '@openfin/core';
export type withDisconnectListener<T> = T & {
    addDisconnectionListener: (listener: () => void) => void;
};
/**
 * Make a function that connects to a channel.
 * If already connected to the channel, will return the channel connection.
 * If disconnected from the channel, will automatically reconnect.
 * @param channelName the name of the channel to connect to.
 * @returns the function to connect to the channel.
 */
export default function makeGetChannelClient(channelName: string): () => Promise<withDisconnectListener<OpenFin.ChannelClient>>;
