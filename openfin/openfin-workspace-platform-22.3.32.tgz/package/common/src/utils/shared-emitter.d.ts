/**
 * Creates an event emitter that is shared between all windows within the same domain.
 */
export default function makeSharedEmitter<EventMap extends {
    [key: string | number]: any[];
}>(id: string): {
    emit: <EventKey extends keyof EventMap>(event: EventKey, ...payload: EventMap[EventKey]) => Promise<void>;
    addListener: <EventKey extends keyof EventMap>(event: EventKey, listener: (...payload: EventMap[EventKey]) => void) => void;
    /**
     * Creates a listener for a particular UUID instead of ApplicationUUID.Workspace.
     * @param uuid The UUID of the application to subscribe to.
     */
    addListenerWithUUID: (uuid: string) => <EventKey extends keyof EventMap>(event: EventKey, listener: (...payload: EventMap[EventKey]) => void) => void;
    removeListener: <EventKey extends keyof EventMap>(event: EventKey, listener: (...payload: EventMap[EventKey]) => void) => void;
    once: <EventKey extends keyof EventMap>(event: EventKey, listener: (...payload: EventMap[EventKey]) => void) => void;
};
