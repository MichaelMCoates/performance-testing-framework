import type OpenFin from '@openfin/core';
import { PageTabContextMenuItemTemplate } from '../../../client-api-platform/src/shapes';
export declare const getPageTabMenuTemplate: (pageId: string, winIdentity: OpenFin.Identity, isEnterprise: boolean) => Promise<PageTabContextMenuItemTemplate[]>;
