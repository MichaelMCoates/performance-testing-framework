import { AnalyticsEventInternal } from './usage-register';
export declare const generateHash: (text: string) => Promise<string>;
interface AnalyticsBackendPayload {
    d: {
        app_config: string;
        app_name: string;
        app_uuid: string;
        clientId: string;
        combined_id: string;
        content_url: string;
        machine_id: string;
        manifest_type: 'platform';
        os: string;
        runtime_version: string;
        rvm_version: string;
        type: 'workspace-analytics';
        u: string;
        data: AnalyticsEventInternal;
        timestamp: string;
    };
}
export declare const decorateAnalyticsPayload: (event: AnalyticsEventInternal) => Promise<AnalyticsBackendPayload>;
export {};
