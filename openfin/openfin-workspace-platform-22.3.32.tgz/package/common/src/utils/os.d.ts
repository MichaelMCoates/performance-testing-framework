export declare const isOSWindows: () => Promise<boolean>;
export declare const isWindows10Or11: () => Promise<boolean>;
