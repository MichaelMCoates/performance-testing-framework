import type OpenFin from '@openfin/core';
import { ResponseModalContent } from '../../../common/src/utils/menu-config';
import type { OptionalExceptFor } from '../../../common/src/utils/types';
type MenuEventTypes = {
    response: [ModalResponseEvent];
    ready: [OpenFin.Identity];
    update: [string, Partial<OpenFin.Bounds>, string];
};
export interface ModalResponseEvent {
    data: {
        actionName: string;
        data?: {
            textInputValue?: string;
        };
    };
    name: string;
}
export declare const menuEvents: {
    emit: <EventKey extends keyof MenuEventTypes>(event: EventKey, ...payload: MenuEventTypes[EventKey]) => Promise<void>;
    addListener: <EventKey extends keyof MenuEventTypes>(event: EventKey, listener: (...payload: MenuEventTypes[EventKey]) => void) => void;
    addListenerWithUUID: (uuid: string) => <EventKey extends keyof MenuEventTypes>(event: EventKey, listener: (...payload: MenuEventTypes[EventKey]) => void) => void;
    removeListener: <EventKey extends keyof MenuEventTypes>(event: EventKey, listener: (...payload: MenuEventTypes[EventKey]) => void) => void;
    once: <EventKey extends keyof MenuEventTypes>(event: EventKey, listener: (...payload: MenuEventTypes[EventKey]) => void) => void;
};
export declare const emitMenuResponse: (data: ModalResponseEvent["data"]) => Promise<void>;
type WindowOptionsWithBounds = OptionalExceptFor<OpenFin.WindowOptions, 'name' | 'url'> & {
    top: number;
    left: number;
};
type ModalWindowOptions = WindowOptionsWithBounds & {
    preventBlur?: boolean;
    closeOnResponse?: boolean;
};
export declare function createChildWindow(opts: OptionalExceptFor<OpenFin.WindowOptions, 'name' | 'url'> & {
    preventBlur?: boolean;
}, route?: string, bounds?: Partial<OpenFin.Bounds>): Promise<OpenFin.Window>;
export interface ShowChildOptions {
    options: ModalWindowOptions;
    parameters?: URLSearchParams;
}
export interface ResponseModalOptions {
    options: ModalWindowOptions;
    content: ResponseModalContent;
    parameters?: URLSearchParams;
}
export declare function createMenuPosition(windowOptions: OptionalExceptFor<OpenFin.WindowOptions, 'x' | 'y'>): Promise<{
    top: number;
    left: number;
}>;
export declare function showChildWindow({ options, parameters }: ShowChildOptions): Promise<OpenFin.Window>;
export declare const waitForModalResponse: ({ options, content, parameters }: ResponseModalOptions) => Promise<{
    data: ModalResponseEvent["data"];
}>;
export {};
