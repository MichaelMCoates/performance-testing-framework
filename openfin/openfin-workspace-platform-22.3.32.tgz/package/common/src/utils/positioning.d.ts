export declare enum PositioningType {
    RelativeToParentWindow = "relative-to-parent-window",
    RelativeToMonitor = "relative-to-monitor"
}
