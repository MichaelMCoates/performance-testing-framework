export type { EnterpriseDockChannelClient, EnterpriseDockChannelProvider } from '../api/protocol';
