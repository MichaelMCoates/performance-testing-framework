import type { OpenFin } from '@openfin/core';
import { WorkspaceButton } from '../../../client-api/src/dock';
import { ContentMenuEntry, DockEntry, TaskbarIcon } from '../../../client-api-platform/src/shapes';
export type { Dock3Provider, Dock3ConstructorOverride } from '../api/provider';
export type Dock3Button = WorkspaceButton | 'contentMenu' | 'manageWorkspaces';
/**
 * Configuration for the Dock 3.0 provider.
 */
export interface Dock3Config {
    title?: string;
    /**
     * icon URL for the dock provider.
     */
    icon?: string | TaskbarIcon;
    /**
     * Favorites to be displayed in the dock
     */
    favorites?: DockEntry[];
    /**
     * Content menu entries to be displayed in the dock
     */
    contentMenu?: ContentMenuEntry[];
    /**
     * The config for the default dock buttons
     */
    defaultDockButtons?: Dock3Button[];
    /**
     * The id of the target element for the content menu.
     */
    contentMenuTargetId?: string;
    /**
     * The config for the companion dock ui
     */
    uiConfig?: {
        contentMenu?: {
            enableBookmarking?: boolean;
        };
        /**
         * By default drag handle is visible. Set this to true to hide the drag handle
         */
        hideDragHandle?: boolean;
        /**
         * By default provider icon is just a drag region. Set this to true to convert it to content menu dropdown button.
         */
        providerIconContentMenu?: boolean;
        /**
         * Configuration for the dock more menu component.
         */
        moreMenu?: {
            quitPlatform?: {
                /**
                 * By default the quit button will contain platform title in its label. Set this to true to hide the platform title.
                 */
                hidePlatformTitle?: boolean;
                /**
                 * By default the quit button will show a quit confirmation dialog. Set this to true to skip the quit confirmation dialog.
                 */
                skipDialog?: boolean;
            };
        };
        manageWorkspaces?: {
            newWindow?: {
                behavior: 'view';
                viewOptions: OpenFin.PlatformViewCreationOptions;
            };
        };
    };
}
export type DockAllowedWindowOptions = Partial<Pick<OpenFin.PlatformWindowOptions, 'defaultCentered' | 'saveWindowState' | 'taskbarIconGroup' | 'defaultTop' | 'defaultLeft'>>;
