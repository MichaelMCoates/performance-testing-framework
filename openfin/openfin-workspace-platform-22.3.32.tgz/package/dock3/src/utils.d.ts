export type CamelCase<T extends string> = T extends `${infer Head}-${infer Tail}` ? `${Head}${Capitalize<CamelCase<Tail>>}` : T;
export type Async<T extends (...args: any[]) => any> = T extends (...args: infer P) => infer R ? (...args: P) => Promise<Awaited<R>> : never;
