import { Dock3Config, DockAllowedWindowOptions } from '../../../dock3/src/shapes';
import { Dock3ConstructorOverride, Dock3Provider } from './provider';
export type DockInitOptions = {
    config: Dock3Config;
    override: Dock3ConstructorOverride;
    windowOptions?: DockAllowedWindowOptions;
};
/**
 *
 * @param config Dock3 configuration object
 * @param override Constructor override to customize the Dock3Provider
 * @returns instance of Dock3Provider
 */
export declare function init(options: DockInitOptions): Promise<Dock3Provider>;
