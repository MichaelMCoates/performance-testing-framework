import type { CompanionDockConfig } from '../shapes/enterprise';
import type { Dock3Config, DockAllowedWindowOptions } from '../shapes/shapes';
export declare function launchDock(dockName: string, baseUrl: string, config: CompanionDockConfig | Dock3Config, additionalOptions?: DockAllowedWindowOptions): Promise<void>;
