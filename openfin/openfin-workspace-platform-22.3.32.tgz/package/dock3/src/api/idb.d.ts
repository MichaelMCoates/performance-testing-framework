import { Dock3Config } from '../../../client-api-platform/src/shapes';
export declare function getDock3ProviderConfig(): Promise<Dock3Config | undefined>;
export declare function saveDock3ProviderConfig(config: Dock3Config): Promise<void>;
