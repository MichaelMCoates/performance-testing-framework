import type { OpenFin } from '@openfin/core';
import { BookmarkDockEntryPayload, LaunchDockEntryPayload } from '../../../client-api-platform/src/index';
import { Dock3Config } from '../../../dock3/src/shapes';
import { Async, CamelCase } from '../../../dock3/src/utils';
import { Dock3ChannelProvider, Dock3ChannelProviderChannelActions } from './protocol';
type InternalDock3ChannelActions = 'ready';
type Dock3ProviderAPI = {
    [K in keyof Omit<Dock3ChannelProviderChannelActions, InternalDock3ChannelActions> as CamelCase<K>]: Async<Dock3ChannelProviderChannelActions[K]>;
};
type ExtendsProtocolProvider<T extends Dock3ProviderAPI> = T extends Dock3ProviderAPI ? T : never;
export type EnsureProviderMatchesProtocol = ExtendsProtocolProvider<Dock3Provider>;
export declare class Dock3Provider {
    #private;
    static getOverrideConstructor(...args: ConstructorParameters<typeof Dock3Provider>): new () => Dock3Provider;
    static instance: Dock3Provider | null;
    constructor(config: Dock3Config, channel: Dock3ChannelProvider);
    launchEntry(payload: LaunchDockEntryPayload): Promise<void>;
    /**
     * Returns a promise that resolves when the Dock3Provider is ready.
     * This is useful to ensure that the dock is fully initialized before performing any operations.
     * The promise will resolve when the dock sends the 'ready' action.
     */
    get ready(): Promise<void>;
    bookmarkContentMenuEntry(payload: BookmarkDockEntryPayload): Promise<void>;
    /**
     * Read-only access to the current configuration of the Dock3Provider.
     */
    get config(): Dock3Config;
    /**
     * Protected setter for the configuration of the Dock3Provider.
     * This does not save the configuration in storage nor notify the dock about the change.
     * Use `updateConfig` method to update the configuration and save it.
     * This should only be used internally in a `saveConfig` override if `super.saveConfig` is not called.
     */
    protected set config(newConfig: Dock3Config);
    /**
     * Updates the configuration of the Dock3Provider.
     * This method updates the configuration, notifies the dock about the change and saves the new configuration to storage (via `saveConfig`).
     * @param newConfig The new configuration to be applied.
     */
    updateConfig(config: Dock3Config): Promise<void>;
    /**
     * Shuts down the Dock3Provider and closes the dock window.
     * This method sends a shutdown message to the dock and then closes the window.
     */
    shutdown(): Promise<void>;
    /**
     * Called whenever the configuration is updated, this method saves the configuration to the storage.
     * This should not be called directly, if you need to update the configuration, use `updateConfig` method instead.
     */
    saveConfig({ config }: {
        config: Dock3Config;
    }): Promise<void>;
    private handleConfigChange;
    /**
     * Called on startup to load the current configuration of the Dock3Provider.
     * If you've overridden the `saveConfig` method, this should load the configuration from your storage.
     * By default it will load the configuration from local storage. This can  be overriden to prevent loading from local storage.
     * @example Prevent loading from local storage:
     * ```typescript
     * class MyDock3Provider extends Dock3Provider {
     *    async loadConfig(): Promise<Dock3Config> {
     *       // Do not load from local storage, return the default config
     *       return this.config;
     *   }
     *  }
     * ```
     * @example Load from a custom storage:
     * ```typescript
     * class MyDock3Provider extends Dock3Provider {
     *   async loadConfig(): Promise<Dock3Config> {
     *      // Load from a custom storage
     *      const configFromStorage = await myCustomStorage.getDockConfig();
     *      // Update local config to ensure it is used.
     *      if (configFromStorage) {
     *         this.config = configFromStorage;
     *      }
     *      return this.config;
     *   }
     * }
     * ```
     * @returns The current configuration of the Dock3Provider.
     */
    loadConfig(): Promise<Dock3Config>;
    getWindowSync(): OpenFin.Window;
    private registerChannelActions;
}
export type Dock3ConstructorOverride = (Base: new () => Dock3Provider) => new () => Dock3Provider;
export {};
