export declare const DOCK_COMPANION_HEIGHT = 56;
export declare const DOCK_COMPANION_WIDTH = 728;
export declare const DOCK_COMPANION_TOP = 150;
export declare const DOCK3_WINDOW_NAME = "dock3";
export declare const getDock3ChannelName: (uuid?: string) => string;
