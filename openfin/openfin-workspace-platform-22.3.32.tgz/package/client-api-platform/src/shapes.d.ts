import type OpenFin from '@openfin/core';
import { IconProps, IconType, Languages } from '@openfin/ui-library';
import type { AnalyticsEvent } from '../../common/src/utils/usage-register';
import { CustomActionSpecifier, CustomButtonConfig } from '../../common/src/api/action';
import { AddDefaultPagePayload, AttachedPage, BookmarkNode, CopyPagePayload, HandlePagesAndWindowClosePayload, HandlePagesAndWindowCloseResult, HandleSaveModalOnPageClosePayload, Page, PageLayoutsWithSelectedViews, PageWithUpdatableRuntimeAttribs, SaveModalOnPageCloseResult, SetActivePageForWindowPayload, ShouldPageClosePayload, ShouldPageCloseResult, ViewsPreventingUnloadPayload } from '../../common/src/api/pages/shapes';
import { NotificationsCustomManifestOptions } from '../../common/src/api/shapes/notifications';
import type { CustomThemes } from '../../common/src/api/theming';
import { App, DockProviderConfigWithIdentity, StoreButtonConfig } from '../../client-api/src/shapes';
import type { WorkflowIntegration } from '../../client-api/src/shapes/integrations';
export * from '../../dock3/src/shapes';
export { AppManifestType } from '../../client-api/src/shapes';
export type { App, AppIntent, Image } from '../../client-api/src/shapes';
export type { CustomActionSpecifier, CustomButtonConfig } from '../../common/src/api/action';
export type { AttachedPage, Page, PageLayout, PageLayoutDetails, PageWithUpdatableRuntimeAttribs, PanelConfigHorizontal, PanelConfigVertical, PanelConfig, ExtendedPanelConfig, CopyPagePayload, HandleSaveModalOnPageClosePayload, SaveModalOnPageCloseResult, SetActivePageForWindowPayload, ShouldPageClosePayload, ShouldPageCloseResult, ViewsPreventingUnloadPayload } from '../../common/src/api/pages/shapes';
export { PanelPosition } from '../../common/src/api/pages/shapes';
export type { CustomThemes, CustomThemeOptions, CustomThemeOptionsWithScheme, CustomPaletteSet, BaseThemeOptions, ThemeExtension, WorkspaceThemeSet, NotificationIndicatorColorsSet, NotificationIndicatorColorsSetDarkScheme, NotificationIndicatorColorsSetLightScheme, NotificationIndicatorColorsWithScheme } from '../../common/src/api/theming';
export type { AnalyticsEvent } from '../../common/src/utils/usage-register';
export type { WorkflowIntegration } from '../../client-api/src/shapes/integrations';
/**
 * Request for creating a saved page in persistent storage.
 */
export interface CreateSavedPageRequest {
    /** The page to create. */
    page: Page;
}
/**
 * Request for updating a saved page in persistent storage.
 */
export interface UpdateSavedPageRequest {
    /** The ID of the page to update. */
    pageId: string;
    /** The updated page. */
    page: Page;
}
export declare enum PageChangeEventType {
    UrlChange = "URL_CHANGE",
    ViewAdded = "VIEW_ADDED",
    ViewRemoved = "VIEW_REMOVED",
    PageContextAdded = "PAGE_CONTEXT_ADDED",
    PageContextRemoved = "PAGE_CONTEXT_REMOVED"
}
export type PageChangeEventDetails = UrlChangeDetails | ViewAddedDetails | ViewRemovedDetails | PageContextRemovedDetails | PageContextAddedDetails;
export interface PageContextRemovedDetails {
    type: PageChangeEventType.PageContextRemoved;
    viewIdentity: OpenFin.Identity;
}
export interface PageContextAddedDetails {
    type: PageChangeEventType.PageContextAdded;
    viewIdentity: OpenFin.Identity;
    contextId: string;
}
export interface UrlChangeDetails {
    type: PageChangeEventType.UrlChange;
    viewIdentity: OpenFin.Identity;
    urlBefore: string;
    urlAfter: string;
}
export interface ViewAddedDetails {
    type: PageChangeEventType.ViewAdded;
    viewIdentity: OpenFin.Identity;
}
export interface ViewRemovedDetails {
    type: PageChangeEventType.ViewRemoved;
    viewIdentity: OpenFin.Identity;
}
export interface HandlePageChangesPayload {
    /** The page with new changes. */
    page: AttachedPage;
    /** The OF window identity containing the page. */
    identity: OpenFin.Identity;
    /** Additional details about the page change event. */
    eventDetails?: PageChangeEventDetails;
}
export interface ModifiedPageState {
    hasUnsavedChanges?: boolean;
}
/**
 * Request for reordering the pages attached to a window.
 */
export interface ReorderPagesRequest {
    /** An array of page ids that specify the order of the pages attached to the window. */
    pageIds: string[];
}
/**
 * Request for opening a logo context menu in Browser.
 */
export interface OpenGlobalContextMenuRequest {
    /** Client x-coordinate where context menu should be shown. */
    x: number;
    /** Client y-coordinate where context menu should be shown. */
    y: number;
    /** Miscellaneous options necessary for implementing custom logic in the provider override. */
    customData?: any;
    /** Identities of the currently selected views */
    selectedViews?: OpenFin.Identity[];
}
/**Shape of the data property of a context menu template item */
export interface ContextMenuItemData {
    type: string;
    action?: CustomActionSpecifier;
}
/**Types of global context menu options, including pre-defined ones.
 * User-defined context menu items should use the value `Custom` */
export declare enum GlobalContextMenuOptionType {
    NewWindow = "NewWindow",
    NewPage = "NewPage",
    SavePage = "SavePage",
    SavePageAs = "SavePageAs",
    Print = "Print",
    PrintAll = "PrintAll",
    PrintScreen = "PrintScreen",
    CloseWindow = "CloseWindow",
    RestoreChanges = "RestoreChanges",
    SaveWorkspace = "SaveWorkspace",
    SaveWorkspaceAs = "SaveWorkspaceAs",
    RenameWorkspace = "RenameWorkspace",
    SwitchWorkspace = "SwitchWorkspace",
    DeleteWorkspace = "DeleteWorkspace",
    Downloads = "Downloads",
    OpenStorefront = "OpenStorefront",
    ManageDesktopSignals = "ManageDesktopSignals",
    Appearance = "Appearance",
    Quit = "Quit",
    Custom = "Custom"
}
/**
 * Types of color scheme.
 */
export declare enum ColorSchemeOptionType {
    Light = "light",
    Dark = "dark",
    System = "system"
}
/**
 * Defines the title used for the browser window.
 * `custom` - uses the value of `value` property
 * `page-title` - uses the title of the active page
 * `view-title` - uses the title of the active view
 */
export type WindowTitle = {
    type: 'custom';
    value: string;
} | {
    type: 'page-title';
} | {
    type: 'view-title';
};
/**Types of page tab context menu options, including pre-defined ones.
 * User-defined context menu items should use the value `Custom` */
export declare enum PageTabContextMenuOptionType {
    Close = "Close",
    Duplicate = "Duplicate",
    Rename = "Rename",
    Save = "Save",
    SaveAs = "Save As",
    NewPage = "New Page",
    DeletePage = "Delete Page",// Enterprise
    SaveWorkspaceAs = "SaveWorkspaceAs",// Enterprise
    Refresh = "Refresh",// Enterprise
    CloseOthers = "Close others",// Enterprise
    Delete = "Delete",// Enterprise
    Print = "Print",// Enterprise
    PrintAll = "PrintAll",// Enterprise
    PrintScreen = "PrintScreen",// Enterprise
    ManageDesktopSignals = "ManageDesktopSignals",// Enterprise
    AddToChannel = "AddToChannel",// Enterprise
    Custom = "Custom"
}
/**Shape of the data property of a global context menu template item */
export interface GlobalContextMenuItemData extends ContextMenuItemData {
    type: GlobalContextMenuOptionType;
}
export interface AddToChanel extends GlobalContextMenuItemData {
    workspaceId: string;
}
export interface WorkspaceContextMenuItemData extends GlobalContextMenuItemData {
    workspaceId: string;
}
export interface AppearanceContextMenuItemData extends GlobalContextMenuItemData {
    scheme: ColorSchemeOptionType;
}
/**Configuration of an option in the global context menu */
export type GlobalContextMenuItemTemplate = OpenFin.MenuItemTemplate<GlobalContextMenuItemData>;
/**Shape of the data property of a page tab context menu template item */
export interface PageTabContextMenuItemData extends ContextMenuItemData {
    type: PageTabContextMenuOptionType;
    /** Property to specify which option was selected when there are
     * several options of the same type (e.g. which channel was selected) */
    option?: string;
}
/**Configuration of an option in the page tab context menu */
export interface PageTabContextMenuItemTemplate extends OpenFin.MenuItemTemplate {
    data?: PageTabContextMenuItemData;
}
/**Payload received by a Custom Action that is invoked by a custom global context menu option */
export interface GlobalContextMenuOptionActionPayload {
    callerType: CustomActionCallerType.GlobalContextMenu;
    /** Identity of the browser window where the context menu is invoked */
    windowIdentity: OpenFin.Identity;
    /** Any data necessary for the functioning of specified custom action*/
    customData?: any;
}
/**Payload received by a Custom Action that is invoked by a custom page tab context menu option */
export interface PageTabContextMenuOptionActionPayload {
    callerType: CustomActionCallerType.PageTabContextMenu;
    /** Identity of the browser window where the context menu is invoked */
    windowIdentity: OpenFin.Identity;
    /** Any data necessary for the functioning of specified custom action*/
    customData?: any;
    /** Id of the page on which the context menu is invoked */
    pageId: string;
}
/**
 * Payload received by the openGlobalContextMenu provider override.
 */
export type OpenGlobalContextMenuPayload = OpenGlobalContextMenuRequest & {
    /** Template defining the options to show in the context menu. */
    template: GlobalContextMenuItemTemplate[];
    /** Identity of the Browser window where context menu should be shown. */
    identity: OpenFin.Identity;
    /** Default function that handles stock context menu options. */
    callback: (data: GlobalContextMenuItemData, payload: OpenGlobalContextMenuPayload) => any;
};
export type ViewTabContextMenuTemplate = OpenFin.MenuItemTemplate<ViewTabMenuData>;
/**
 * Request for opening a view tab context menu in Browser.
 */
export interface OpenViewTabContextMenuRequest {
    /** Client x-coordinate where context menu should be shown. */
    x: number;
    /** Client y-coordinate where context menu should be shown. */
    y: number;
    /** Miscellaneous options necessary for implementing custom logic in the provider override. */
    customData?: any;
    /** Template defining the options to show in the context menu. */
    template: ViewTabContextMenuTemplate[];
    /** Ids of selected views */
    selectedViews: OpenFin.Identity[];
}
/**
 * Request for opening a page tab context menu in Browser.
 */
export interface OpenPageTabContextMenuRequest {
    /** Client x-coordinate where context menu should be shown. */
    x: number;
    /** Client y-coordinate where context menu should be shown. */
    y: number;
    /** Miscellaneous options necessary for implementing custom logic in the provider override. */
    customData?: any;
    /** Id of the page on which the context menu is invoked */
    pageId: string;
}
/**
 * View tab context menu types for {@link WorkspacePlatformProvider.openViewTabContextMenu} override.
 */
export declare enum ViewTabMenuOptionType {
    /**
     * Create new view in a page.
     */
    NewView = "NewView",
    /**
     * Duplicate selected views in a page.
     */
    DuplicateViews = "DuplicateView",
    /**
     * Open content from the selected view in system's default web browser.
     */
    OpenWithDefaultBrowser = "OpenWithDefaultBrowser",
    /**
     * Reload the selected views.
     */
    ReloadViews = "ReloadTab",
    /**
     * Close the selected views.
     */
    CloseViews = "CloseTab",
    /**
     * Add selected views to a color channel.
     */
    AddToChannel = "AddToChannel",
    /**
     * Remove selected views from a color channel.
     */
    RemoveFromChannel = "RemoveFromChannel",
    /**
     * Navigate back to the previous content.
     */
    Back = "Back",
    /**
     * Navigate forward to the next content.
     */
    Forward = "Forward",
    /**
     * Print the selected view.
     */
    Print = "Print",
    /**
     * Prints visible views.
     */
    PrintAll = "PrintAll",
    /**
     * Prints a screenshot of the browser window.
     */
    PrintScreen = "PrintScreen",
    /**
     * Custom context menu option defined by API client.
     */
    Custom = "Custom"
}
export interface ViewTabMenuData {
    type: ViewTabMenuOptionType;
    action?: CustomActionSpecifier;
    option?: string;
}
export interface ViewTabCustomActionPayload {
    callerType: CustomActionCallerType.ViewTabContextMenu;
    /** Any data necessary for the functioning of specified custom action*/
    customData: any;
    /** Identity of the Browser window where context menu should be shown. */
    windowIdentity: OpenFin.Identity;
    selectedViews: OpenFin.Identity[];
}
/**
 * Payload received by the openViewTabContextMenu provider override.
 */
export type OpenViewTabContextMenuPayload = OpenViewTabContextMenuRequest & {
    /** Identity of the Browser window where context menu should be shown. */
    identity: OpenFin.Identity;
    /** Default function that handles stock context menu options. */
    callback: (data: ViewTabMenuData, req: OpenViewTabContextMenuPayload) => any;
};
/**
 * Payload received by the openViewTabContextMenu provider override.
 */
export type OpenPageTabContextMenuPayload = OpenPageTabContextMenuRequest & {
    /** Identity of the Browser window where context menu should be shown. */
    identity: OpenFin.Identity;
    /** Template defining the options to show in the context menu. */
    template: PageTabContextMenuItemTemplate[];
    /** Default function that handles stock context menu options. */
    callback: (data: PageTabContextMenuItemData, req: OpenPageTabContextMenuPayload) => any;
};
/**
 * Request to update the attributes of a page in which is attached to a running browser window.
 */
export interface UpdateAttachedPageRequest {
    /** The ID of the page to update. */
    pageId: string;
    /** The updated page. */
    page: Partial<PageWithUpdatableRuntimeAttribs>;
}
export interface ReparentPageRequest {
    /** The ID of the page to reparent. */
    pageId: string;
}
/**
 * Types of buttons on browser windows
 */
export declare enum BrowserButtonType {
    ShowHideTabs = "ShowHideTabs",
    ColorLinking = "ColorLinking",
    PresetLayouts = "PresetLayouts",
    LockUnlockPage = "LockUnlockPage",
    SaveMenu = "SaveMenu",
    SavePage = "SavePage",
    Minimise = "Minimise",
    Maximise = "Maximise",
    Close = "Close",
    Custom = "Custom"
}
/**
 * The shape of the payload sent by a custom button click to a custom action handler
 */
export interface CustomButtonActionPayload {
    /** Calling the CustomButton type */
    callerType: CustomActionCallerType.CustomButton;
    /** Identity for the current window. */
    windowIdentity: OpenFin.Identity;
    /** Any data necessary for the functioning of specified custom action*/
    customData: any;
    /** Screen x-coordinate where custom button should be shown. */
    x: number;
    /** Screen y-coordinate where custom button should be shown. */
    y: number;
}
/**
 * The shape of the payload that is sent by a store app primary button or secondary button click to a platform custom action handler
 */
export interface StoreCustomButtonActionPayload extends Omit<CustomButtonActionPayload, 'callerType'> {
    /**
     * Invoking application id.
     */
    appId: string;
    sourceButtonConfig: StoreButtonConfig;
    secondaryButtons: StoreButtonConfig[];
    primaryButton: StoreButtonConfig;
    callerType: CustomActionCallerType.StoreCustomButton;
    storeFrontProviderId: string;
}
/**
 * The shape of the payload sent by a custom dropdown menu item to a custom action handler
 */
export interface CustomDropdownItemActionPayload {
    /** Calling the CustomButton type */
    callerType: CustomActionCallerType.CustomDropdownItem;
    /** Identity for the current window. */
    windowIdentity: OpenFin.Identity;
    /** Any data necessary for the functioning of specified custom action*/
    customData: any;
}
/**
 * Custom browser buttons
 */
export interface CustomBrowserButtonConfig extends CustomButtonConfig {
    /** Type of custom browser button */
    type: BrowserButtonType.Custom;
}
/**
 * Default Browser Button types
 */
export interface PreDefinedButtonConfig {
    /** Type of default browser button */
    type: Exclude<BrowserButtonType, BrowserButtonType.ShowHideTabs | BrowserButtonType.LockUnlockPage | BrowserButtonType.Custom>;
    /** Button name text when hovered over */
    tooltip?: string;
    /** icon URL for icon image */
    iconUrl?: string;
    iconProps?: IconProps;
    disabled?: boolean;
    parentHover?: boolean;
}
/**
 * Configuration Object for the show/hide tabs button within the browser toolbar
 *
 * @example
 * ```ts
 * const showHideTabsConfig: ShowHideTabsConfig = {
 *     type: BrowserButtonType.ShowHideTabs,
 *     disabled: false
 * };
 * ```
 */
export type ShowHideTabsConfig = {
    type: BrowserButtonType.ShowHideTabs;
    disabled?: boolean;
    tabsShownIconUrl?: {
        /**
         * The URL of the icon to display when the button is disabled and tabs are hidden.
         *
         * The button is disabled when the page is locked.
         */
        disabled?: string;
        /**
         * The URL of the icon to display when the button is enabled and tabs are hidden.
         */
        enabled?: string;
    };
    tabsHiddenIconUrl?: {
        /**
         * The URL of the icon to display when the button is disabled and tabs are hidden.
         *
         * The button is disabled when the page is locked.
         */
        disabled?: string;
        /**
         * The URL of the icon to display when the button is enabled and tabs are hidden.
         */
        enabled?: string;
    };
};
/**
 * Configuration Object for the page lock/unlock button within the browser toolbar
 *
 * @example
 * ```ts
 * const lockUnlockPageConfig: LockUnlockPageConfig = {
 *     type: BrowserButtonType.LockUnlockPage,
 *     disabled: false
 * };
 * ```
 */
export type LockUnlockPageConfig = {
    type: BrowserButtonType.LockUnlockPage;
    disabled?: boolean;
    lockedIconUrl?: string;
    unlockedIconUrl?: string;
};
/**
 * Buttons on the left of WindowStateButtonOptions
 */
export type ToolbarButton = ShowHideTabsConfig | LockUnlockPageConfig | CustomBrowserButtonConfig | PreDefinedButtonConfig;
export interface ToolbarOptions {
    buttons: ToolbarButton[];
}
/**
 * Buttons to the top far right of Browser
 */
export type WindowStateButton = CustomBrowserButtonConfig | PreDefinedButtonConfig;
export interface WindowStateButtonOptions {
    buttons: WindowStateButton[];
}
/**Types of context menu options for Save button, including pre-defined ones.
 * User-defined context menu items should use the value `Custom` */
export declare enum SaveButtonContextMenuOptionType {
    SavePage = "SavePage",
    SaveWorkspace = "SaveWorkspace",
    SavePageAs = "SavePageAs",
    SaveWorkspaceAs = "SaveWorkspaceAs",
    Custom = "Custom"
}
/**Shape of the data property of a save button context menu template item */
export interface SaveButtonContextMenuItemData extends ContextMenuItemData {
    type: SaveButtonContextMenuOptionType;
}
/**Configuration of an option in the save button context menu */
export interface SaveButtonContextMenuItemTemplate extends OpenFin.MenuItemTemplate {
    data?: SaveButtonContextMenuItemData;
}
/**
 * Request for opening a context menu from save button in Browser.
 */
export interface OpenSaveButtonContextMenuRequest {
    /** Client x-coordinate where context menu should be shown. */
    x: number;
    /** Client y-coordinate where context menu should be shown. */
    y: number;
    /** Screen x-coordinate of save button */
    buttonLeft: number;
    /** width of save button */
    buttonWidth: number;
    /** Miscellaneous options necessary for implementing custom logic in the provider override. */
    customData?: any;
    /** Id of the page on which the context menu is invoked */
    pageId: string;
}
/**
 * Payload received by the openSaveButtonContextMenu provider override.
 */
export type OpenSaveButtonContextMenuPayload = OpenSaveButtonContextMenuRequest & {
    /** Identity of the Browser window where context menu should be shown. */
    identity: OpenFin.Identity;
    /** Template defining the options to show in the context menu. */
    template: SaveButtonContextMenuItemTemplate[];
    /** Default function that handles stock context menu options. */
    callback: (data: SaveButtonContextMenuItemData, req: OpenSaveButtonContextMenuPayload) => any;
};
/**Payload received by a Custom Action that is invoked by a custom save button context menu option */
export interface OpenSaveContextMenuOptionActionPayload {
    callerType: CustomActionCallerType.SaveButtonContextMenu;
    /** Identity of the browser window where the context menu is invoked */
    windowIdentity: OpenFin.Identity;
    /** Any data necessary for the functioning of specified custom action*/
    customData?: any;
    /** Id of the page on which the context menu is invoked */
    pageId: string;
}
export declare enum WindowType {
    Browser = "browser",
    Platform = "platform"
}
export interface BrowserWorkspacePlatformViewOptions {
    browserNavigationButtons?: RequireAtLeastOne<{
        back?: boolean;
        forward?: boolean;
        reload?: boolean;
    }>;
}
type RequireAtLeastOne<T, Keys extends keyof T = keyof T> = Pick<T, Exclude<keyof T, Keys>> & {
    [K in Keys]-?: Required<Pick<T, K>> & Partial<Pick<T, Exclude<Keys, K>>>;
}[Keys];
export interface BrowserCreateViewPayload {
    opts: BrowserCreateViewRequest;
    target?: OpenFin.CreateViewTarget;
    targetView?: OpenFin.Identity;
}
export interface BrowserCreateViewRequest extends OpenFin.PlatformViewCreationOptions {
    workspacePlatform?: BrowserWorkspacePlatformViewOptions;
}
export interface BrowserViewState extends OpenFin.ViewState {
    workspacePlatform?: BrowserWorkspacePlatformViewOptions;
}
export interface BrowserWorkspacePlatformWindowOptions {
    /** For internal usage.  Defaults to 'browser' when Browser is enabled when the WorkspacePlatform is initialized.  In order to use
     * non-Browser layout windows ('platform' windows) in a Browser-enabled workspace platform, set windowType to `platform`. In that instance, the other properties
     * in the workspacePlatform object are not relevant.
     * */
    windowType?: WindowType;
    /** The initial set of pages to add to the created browser window. */
    pages: Page[];
    /** The favicon to display on the top left of the created browser window. */
    favicon?: string;
    /**
     * A UI friendly title for the created browser window.
     * Type string for window title is deprecated, please use WindowTitle type instead.
     */
    title?: WindowTitle | string;
    /**
     * Landing page that shows up when you add a new tab from the plus button that exists in the tabstrip.
     * If you do not provide a newTabUrl, then the plus button in the tabstrip will not be shown and users cannot create a new empty tab.
     */
    newTabUrl?: string;
    /**
     * Landing page that shows up when you add a new page from the plus button that exists in the window frame where the page selector is shown.
     * If you do not provide a newPageUrl, then the new Page plus button will not be shown and you cannot create a new empty Page or Window.
     */
    newPageUrl?: string;
    toolbarOptions?: ToolbarOptions;
    windowStateButtonOptions?: WindowStateButtonOptions;
    /** Specifies the min and max sizes for page tabs.
     * Page tabs will expand to take all available space up to the specified maximum size.
     * Similarly, they will collapse down to the specified minimum size.
     * When there is not enough room to fit the tabs, the tabstrip will become scrollable.
     * Sizes can be specified as pixels (e.g. "100px") or as percentage of tab strip width (e.g. "20%").
     * The default value for both min and max is "120px". To maintain usability, minimum values below 28px will be ignored and 28px will be used as the minimum.
     */
    pageTabDimensions?: {
        minWidth?: string;
        maxWidth?: string;
    };
    /** Specifies the min and max sizes for view tabs in a layout.
     * View tabs will expand to take all available space up to the specified maximum size.
     * Similarly, they will collapse down to the specified minimum size.
     * When there is not enough room to fit the tabs, the tabstrip will become scrollable.
     * Sizes can be specified as pixels (e.g. "100px") or as percentage of tab strip width (e.g. "20%").
     * The default value for both min and max is "120px". To maintain usability, minimum values below 28px will be ignored and 28px will be used as the minimum.
     */
    viewTabDimensions?: {
        minWidth?: string;
        maxWidth?: string;
    };
    /**
     * Use when you want to display navigation buttons in Browser toolbar. Disabled by default.
     *
     * @example
     * ```
     * import * as WP from "@openfin/workspace-platform";
     *
     * const platform = WP.getCurrentSync();
     * const browserWin = platform.Browser.createWindow({
     *   ...,
     *   workspacePlatform: {
     *     ...,
     *     navigationButtons: {
     *       enabled: true;
     *     }
     *   }
     * });
     * ```
     *
     * @example
     * ```
     * // With disabled default keyboard shortcuts
     * const browserWin = platform.Browser.createWindow({
     *   ...,
     *   workspacePlatform: {
     *     ...,
     *     navigationButtons: {
     *       enabled: true;
     *       hotkeysDisabled: true;
     *     }
     *   }
     * });
     * ```
     */
    navigationButtons?: {
        enabled: false;
    } | {
        enabled: true;
        hotkeysDisabled?: boolean;
    };
    /**
     * Remove the Page UI and only allow a single page in the browser window.
     * Must be set to true for this behavior.  If this is not set to false,
     * then an empty `pages` option will be populated with a single page.
     */
    disableMultiplePages?: boolean;
    /**
     * When true, disables the ability to drag pages into the window. False by default.
     */
    preventPageDragIn?: boolean;
    /**
     * When true, disables the ability to close pages, drag pages within the window,
     * and drag pages into/out of the window. False by default.
     */
    isLocked?: boolean;
    /**
     * When true, disables the ability to drag pages out of a window. False by default.
     */
    preventPageDragOut?: boolean;
    /**
     * When true, page tabs in the window will not be draggable.
     * This includes reordering pages and dragging them out of the window.
     * False by default.
     */
    preventPageDrag?: boolean;
    /**
     * When true, disables the ability to close pages in the window. False by default.
     */
    preventPageClose?: boolean;
    /**
     * Taskbar Icon for the Browser Window. If light and dark icon are defined, then the taskbar icon will change when the scheme changes.
     */
    icon?: string | TaskbarIcon;
}
/**
 * Request for creating a browser window.
 */
export interface BrowserCreateWindowRequest extends Omit<OpenFin.PlatformWindowCreationOptions, 'workspacePlatform' | 'icon'> {
    /** WorkspacePlatform specific window options. These options will not work unless a workspace platform has been initialized. */
    workspacePlatform: BrowserWorkspacePlatformWindowOptions | {
        /** For internal usage.  Defaults to 'browser' when Browser is enabled when the WorkspacePlatform is initialized.  In order to use
         * non-Browser layout windows ('platform' windows) in a Browser-enabled workspace platform, set windowType to `platform`. In that instance, the other properties
         * in the workspacePlatform object are not relevant.
         * */
        windowType: WindowType.Platform;
    };
    /** The icon to display on the taskbar.
     * @deprecated Use the icon property in the workspacePlatform object instead.
     */
    icon?: string;
    /**
     * @interal - The Ai Panel options for the window. If the url is not set, the panel will not show up.
     */
    aiPanelOptions?: AiPanelOptions;
}
/**
 * A window that is part of a browser snapshot.
 */
export type BrowserSnapshotWindow = OpenFin.WindowCreationOptions & BrowserCreateWindowRequest;
/**
 * A browser snapshot.
 */
export interface BrowserSnapshot {
    /** The state of the windows that were running at the time the snapshot was taken. */
    windows: BrowserSnapshotWindow[];
}
/**
 * Controller for interacting with a browser window.
 */
export interface BrowserWindowModule {
    /** The identity of the browser window. */
    identity: OpenFin.Identity;
    /** Underlying OpenFin window Controller. */
    openfinWindow: OpenFin.Window;
    /**
     * Get a page that is attached to the browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * // assume a browser window already exists
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * const page = await windows[0].getPage('MyPageId');
     * ```
     * @param id the id of the page to get.
     */
    getPage(id: string): Promise<AttachedPage>;
    /**
     * Return all the pages that are attached to a browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * // assume a browser window already exists
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * const pages = await windows[0].getPages();
     * ```
     */
    getPages(): Promise<AttachedPage[]>;
    /**
     * Set the active page for the browser window.  If `multiplePagesDisabled` is `true` an error will be thrown.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * // assume a browser window already exists
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * await windows[0].setActivePage('MyPageId');
     * ```
     * @param id the id of the attached page to set as active.
     */
    setActivePage(id: string): Promise<void>;
    /**
     * Attach a page to a browser window.
     * If `multiplePagesDisabled` is `true` or a page with same id or title is attached to an existing browser window, an error will be thrown.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const layout = {
     *      content: [
     *          {
     *              type: 'stack',
     *              content: [
     *                  {
     *                      type: 'component',
     *                      componentName: 'view',
     *                      componentState: {
     *                          name: 'myViewName',
     *                          url: 'http://google.com'
     *                      }
     *                  }
     *              ]
     *           }
     *      ]
     * };
     * const page = {
     *      title: 'myPageTitle',
     *      pageId: 'myPageId',
     *      layout
     * };
     * // assume a browser window already exists
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * await windows[0].addPage(page);
     * // focus window
     * await windows[0].openfinWindow.focus();
     * // restore window if minimized
     * await windows[0].openfinWindow.restore();
     * ```
     * @param page the attach page to a browser window.
     */
    addPage(page: PageWithUpdatableRuntimeAttribs): Promise<void>;
    /**
     * Remove an existing page from an existing browser window and reparent it to another existing browser window.
     * If `multiplePagesDisabled` is `true` an error will be thrown.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     *
     * // assume a page and multiple browser windows already exists
     * const wrappedTargetWindow = workspacePlatform.Browser.wrapSync(identity)
     * const reparentPageRequest = { pageId: 'my-target-page' }
     * // wrap the window to which you wish to move the page and call reparentPage
     * await wrappedTargetWindow.reparentPage(reparentPageRequest);
     * // focus window
     * await wrappedTargetWindow.openfinWindow.focus();
     * // restore window if minimized
     * await wrappedTargetWindow.openfinWindow.restore();
     * ```
     * @param req the reparent page request.
     */
    reparentPage(req: ReparentPageRequest): Promise<void>;
    /**
     * Remove an attached page from the browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * // assume a browser window already exists
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * await windows[0].removePage('myPageId');
     * ```
     * @param id the id of the attached page to remove from the browser window.
     */
    removePage(id: string): Promise<void>;
    /**
     * Update a page in which is attached to the browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const layout = {
     *      content: [
     *          {
     *              type: 'stack',
     *              content: [
     *                  {
     *                      type: 'component',
     *                      componentName: 'view',
     *                      componentState: {
     *                          name: 'myViewName',
     *                          url: 'http://google.com'
     *                      }
     *                  }
     *              ]
     *           }
     *      ]
     * };
     * const page = {
     *      title: 'myPageTitle',
     *      pageId: 'myPageId',
     *      layout
     * };
     * // assume a browser window already exists
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * const req = {
     *      pageId: 'myPageId',
     *      page
     * };
     * await windows[0].updatePage(req);
     * ```
     * @param req the update request.
     */
    updatePage(req: UpdateAttachedPageRequest): Promise<void>;
    /**
     * Reorder pages attached to the browser window.  If `multiplePagesDisabled` is `true` an error will be thrown.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * // assume a browser window already exists and has three pages in it
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * await windows[0].reorderPages(['myPageId2', 'myPageId1', 'myPageId3']);
     * ```
     * @param req the reorder pages request.
     */
    reorderPages(req: ReorderPagesRequest): Promise<void>;
    /**
     * Replace toolbar options with custom toolbar options
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * // to set the array to our default buttons, pass in null
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * workspacePlatform.Browser.wrapSync(identity).replaceToolbarOptions({buttons:[{
     *      type: 'Custom',
     *      tooltip: 'Custom Tooltip',
     *      disabled: false,
     *      iconUrl: 'https://www.openfin.co/favicon.ico',
     *      action: {
     *          id: 'sample-custom-action-name',
     *          customData: {
     *              message: 'Clicked on custom Toolbar button'
     *          }
     *      }
     *  }]})
     *
     *  const openFinWindow = fin.Window.wrapSync(identity);
     *  // call getOptions() to view updated toolbarOptions under workspacePlatform
     *  await openFinWindow.getOptions()
     * ```
     * @param options new toolbar options.
     */
    replaceToolbarOptions(options: ToolbarOptions): Promise<void>;
    /**
     * Replace window state button options with custom window state button options
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * // to set the array to our default buttons, pass in null
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * workspacePlatform.Browser.wrapSync(identity).replaceWindowStateButtonOptions({buttons:[{
     *     type: 'Custom',
     *     tooltip: 'Custom tooltip',
     *     disabled: false,
     *     iconUrl: 'https://www.openfin.co/favicon.ico',
     *     action: {
     *         id: 'sample-custom-action-name',
     *         customData: {
     *             message: 'Clicked on custom window state button'
     *         }
     *     }
     * }]})
     *
     *  const openFinWindow = fin.Window.wrapSync(identity);
     *  // call getOptions() to view updated windowStateButtonOptions under workspacePlatform
     *  await openFinWindow.getOptions()
     * ```
     * @param options new window state options.
     */
    replaceWindowStateButtonOptions(options: WindowStateButtonOptions): Promise<void>;
    /**
     * Updates the browser window title based on the provided title object.
     *
     * @param title The new title object for the browser window.
     *
     * @example
     * ```typescript
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * workspacePlatform.Browser.wrapSync(identity).updateBrowserWindowTitle({type: 'view-title'});
     * ```
     *
     * @example
     * ```typescript
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * workspacePlatform.Browser.wrapSync(identity).updateBrowserWindowTitle({type: 'custom', value: 'My Custom Title'});
     * ```
     *
     * @typedef WindowTitle
     * @type {Object}
     * @property {string} type - The type of the window title ('custom', 'page-title', or 'view-title').
     * @property {string} [value] - The value associated with the 'custom' type.
     */
    updateBrowserWindowTitle(title: WindowTitle): Promise<void>;
    /**
     * Internal implementation to retrieve selected view ids from available layouts in a browser window instances
     */
    _getLayoutsWithSelectedViews(): Promise<PageLayoutsWithSelectedViews[]>;
    _bookmarks: BrowserBookmarks;
}
export interface BrowserBookmarks {
}
/**
 * Factory for wrapping browser windows and global operations.
 */
export interface BrowserWindowFactory {
    /**
     * Synchronously returns a Browser Window object that represents an existing window
     *
     * @param identity of the window
     */
    wrapSync: (identity: OpenFin.Identity) => BrowserWindowModule;
    /**
     * Get a list of all pages that are attached to any running browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const attachedPages = await workspacePlatform.Browser.getAllAttachedPages();
     * ```
     */
    getAllAttachedPages(): Promise<AttachedPage[]>;
    /**
     *  Get all the Browser Windows that are running in the Workspace Platform.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const windows = await workspacePlatform.Browser.getAllWindows();
     * ```
     */
    getAllWindows(): Promise<BrowserWindowModule[]>;
    /**
     * Create a new browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const layout = {
     *      content: [
     *          {
     *              type: 'stack',
     *              content: [
     *                  {
     *                      type: 'component',
     *                      componentName: 'view',
     *                      componentState: {
     *                          name: 'myViewName',
     *                          url: 'http://google.com'
     *                      }
     *                  }
     *              ]
     *           }
     *      ]
     * };
     * const page = {
     *      title: 'myPageTitle',
     *      pageId: 'myPageId',
     *      layout
     * };
     * const options: BrowserCreateWindowRequest = {
     *      workspacePlatform: {
     *          pages: [page],
     *          title: 'My Window Title',
     *          favicon: 'https://google.com/favicon.ico',
     *          disableMultiplePages: true,  // disable page functionality for the window
     *          toolbarOptions: {  // configure the set of tray icons for the window
     *              buttons: [
     *                  {  // adding a custom tray icon for the window
     *                      type: BrowserButtonType.Custom,
     *                      tooltip: 'Sample Tray Icon',
     *                      disabled: false,
     *                      iconUrl: 'https://www.openfin.co/favicon.ico',
     *                      action: {
     *                          // This action needs to be registed in customActions property in the call WorkspacePlatform.init
     *                          id: 'sample-trayicon-custom-action',
     *                          customData: {
     *                              message: 'Clicked on custom Toolbar button'
     *                          }
     *                      }
     *                  },
     *                  {
     *                      type: BrowserButtonType.ShowHideTabs
     *                  },
     *                  {
     *                      type: BrowserButtonType.ColorLinking
     *                  },
     *                  {
     *                      type: BrowserButtonType.PresetLayouts
     *                  },
     *                  {
     *                      type: BrowserButtonType.SaveMenu
     *                  }
     *             ]
     *          }
     *          windowStateButtonOptions: {
     *          //configure the set of icons for setting window states
     *              buttons: [
     *                   {   // adding a custom window state icon for the window
     *                       id: 'windowState123',
     *                       type: BrowserButtonType.Custom,
     *                       tooltip: 'Sample Window State button',
     *                       disabled: false,
     *                       iconUrl: 'https://www.openfin.co/favicon.ico',
     *                       action: {
     *                          // This action needs to be registered in customActions property in the call WorkspacePlatform.init
     *                           id: 'sample-window-state-custom-action',
     *                           customData: {
     *                               message: 'Clicked on custom Window State button'
     *                           }
     *                       }
     *                   },
     *                   {  // override tooltip and icon URL for standard Maximise button
     *                      type: BrowserButtonType.Maximise,
     *                      tooltip: overrideWindowStateIcons ? 'Studio Maximise' : undefined,
     *                      iconUrl: overrideWindowStateIcons ? 'https://www.openfin.co/favicon.ico' : undefined
     *                   },
     *                   {
     *                      type: BrowserButtonType.Minimise
     *                   },
     *                   {
     *                      type: BrowserButtonType.Close
     *                   }
     *              ]
     *          }
     *      }
     * };
     * const window = await workspacePlatform.Browser.createWindow(options);
     * ```
     *
     * @param options the browser window creation options
     * @remarks
     * **View names are singleton**: It is not recommended to provide view names, but if they are provided, they can only be used by one view at a time.
     *
     * **Expected Behavior**: If a new view is created using the same view name as an already existing view, the new view will be created, with the view name, and the existing view will be destroyed.
     */
    createWindow(options: BrowserCreateWindowRequest): Promise<BrowserWindowModule>;
    /**
     * Get a unique title for a page.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const uniqueTitle = await workspacePlatform.Browser.getUniquePageTitle('myTitle');
     * ```
     * @param title a prefix for the title.
     */
    getUniquePageTitle(title?: string): Promise<string>;
    /**
     * Get the identity of the last focused Browser window.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const windowIdentity = await workspacePlatform.Browser.getLastFocusedWindow();
     * ```
     */
    getLastFocusedWindow(): Promise<OpenFin.Identity | undefined>;
    /**
     * Gets a page that contains a given view identity.
     *
     * @param viewIdentity the identity of the view to search for.
     */
    getPageByViewIdentity(viewIdentity: OpenFin.Identity): Promise<{
        page: AttachedPage;
        windowIdentity: OpenFin.Identity;
        pageIndex: number;
    }>;
}
/**
 * API for interacting with persistent storage.
 */
export interface WorkspacePlatformStorage {
    /**
     * Get all pages that are saved in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const pages = await workspacePlatform.Storage.getPages();
     * ```
     */
    getPages(): Promise<Page[]>;
    /**
     * Get a specific page in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const myPage = await workspacePlatform.Storage.getPage('myPageId');
     * ```
     * @param id the id of the page to get.
     *
     * * @returns a page object or undefined if page doesn't exist.
     */
    getPage(id: string): Promise<Page | undefined>;
    /**
     * Create a page in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const layout = {
     *      content: [
     *          {
     *              type: 'stack',
     *              content: [
     *                  {
     *                      type: 'component',
     *                      componentName: 'view',
     *                      componentState: {
     *                          name: 'myViewName',
     *                          url: 'http://google.com'
     *                      }
     *                  }
     *              ]
     *           }
     *      ]
     * };
     * const page = {
     *      title: 'myPageTitle',
     *      pageId: 'myPageId',
     *      layout
     * };
     * await workspacePlatform.Storage.createPage({page});
     * ```
     * @param page the page to create in persistent storage.
     */
    createPage(page: CreateSavedPageRequest): Promise<void>;
    /**
     * Update a page in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const layout = {
     *      content: [
     *          {
     *              type: 'stack',
     *              content: [
     *                  {
     *                      type: 'component',
     *                      componentName: 'view',
     *                      componentState: {
     *                          name: 'myViewName',
     *                          url: 'http://google.com'
     *                      }
     *                  }
     *              ]
     *           }
     *      ]
     * };
     * const page = {
     *      title: 'myPageTitle',
     *      pageId: 'myPageId',
     *      layout
     * };
     * const req = {
     *      pageId: 'myPageId',
     *      page
     * };
     * await workspacePlatform.Storage.updatePage(req);
     * ```
     * @param req the update saved page request.
     */
    updatePage(req: UpdateSavedPageRequest): Promise<void>;
    /**
     * Delete a page from persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * await workspacePlatform.Storage.deletePage('myPageId');
     * ```
     * @param id the id of the page to delete.
     */
    deletePage(id: string): Promise<void>;
    /**
     * Save a page in persistent storage.
     *
     * This is a helper function that will call `getPage` to determine if a page is already in storage.
     * If the page is already in storage, it will call `updatePage`.
     * If it does not exist in storage, the function will call `createPage` instead.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const layout = {
     *      content: [
     *          {
     *              type: 'stack',
     *              content: [
     *                  {
     *                      type: 'component',
     *                      componentName: 'view',
     *                      componentState: {
     *                          name: 'myViewName',
     *                          url: 'http://google.com'
     *                      }
     *                  }
     *              ]
     *           }
     *      ]
     * };
     * const page = {
     *      title: 'myPageTitle',
     *      pageId: 'myPageId',
     *      layout
     * };
     * await workspacePlatform.Storage.savePage(page);
     * ```
     * @param page the page to save.
     */
    savePage(page: Page): Promise<void>;
    /**
     * Get all workspaces that are saved in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const workspaces = await workspacePlatform.Storage.getWorkspaces();
     * ```
     */
    getWorkspaces(): Promise<Workspace[]>;
    /**
     * Get all workspaces metadata including the workspaceId and title that are saved in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const workspacesMetadata = await workspacePlatform.Storage.getWorkspacesMetadata();
     * ```
     */
    getWorkspacesMetadata(): Promise<Pick<Workspace, 'workspaceId' | 'title'>[]>;
    /**
     * Get a specific workspace in persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const myWorkspace = await workspacePlatform.Storage.getWorkspace('myWorkspaceId');
     * ```
     * @param id the id of the workspace to get.
     *
     * * @returns a workspace object or undefined if workspace doesn't exist.
     *
     */
    getWorkspace(id: string): Promise<Workspace | undefined>;
    /**
     * Create a workspace in persistent storage.
     *
     * @param workspace the workspace to create in persistent storage.
     */
    createWorkspace(workspace: CreateSavedWorkspaceRequest): Promise<void>;
    /**
     * Update a workspace in persistent storage.
     * @param req the update saved workspace request.
     */
    updateWorkspace(req: UpdateSavedWorkspaceRequest): Promise<void>;
    /**
     * Delete a workspace from persistent storage.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * await workspacePlatform.Storage.deleteWorkspace('myWorkspaceId');
     * ```
     * @param id the id of the workspace to delete.
     */
    deleteWorkspace(id: string): Promise<void>;
    /**
     * Save a workspace in persistent storage.
     *
     * This is a helper function that will call `getWorkspace` to determine if a workspace is already in storage.
     * If the workspace is already in storage, it will call `updateWorkspace`.
     * If it does not exist in storage, the function will call `createWorkspace` instead.
     *
     * @param workspace the workspace to save.
     */
    saveWorkspace(workspace: Workspace): Promise<void>;
    /**
     * Implementation for getting the dock provider from persistent storage.
     *
     * @param id The id of the dock provider to get.
     */
    getDockProviderConfig(id: string): Promise<DockProviderConfigWithIdentity | undefined>;
    /**
     * Implementation for saving a dock provider config to persistent storage.
     *
     * @param config The new dock config to save to persistent storage.
     */
    saveDockProviderConfig(config: DockProviderConfigWithIdentity): Promise<void>;
}
/**
 * Request for launching an application.
 */
export interface LaunchAppRequest {
    target?: OpenFin.EntityInfo;
    app: App;
}
/**
 * Get Themes from API
 */
export interface ThemeApi {
    getThemes(): Promise<CustomThemes>;
    setSelectedScheme(newScheme: ColorSchemeOptionType): Promise<void>;
    getSelectedScheme(): Promise<ColorSchemeOptionType>;
}
/**
 * Controller for a Workspace Platform.
 */
export interface WorkspacePlatformModule extends OpenFin.Platform {
    /**
     * Launch a browser snapshot that contains windows with pages.
     *
     * @param snapshot the browser snapshot to launch or a url or filepath to retrieve a JSON snapshot.
     * @param options options for launching the snapshot.
     */
    applySnapshot(snapshot: BrowserSnapshot | string, options?: OpenFin.ApplySnapshotOptions): Promise<OpenFin.Platform>;
    /**
     * Get a snapshot that contains browser windows with pages.
     */
    getSnapshot(): Promise<BrowserSnapshot>;
    /**
     * Preferred way of getting View options with Workspace Platform.
     *
     * @param viewIdentity
     *
     * @example
     * ```
     * import * as WP from "@openfin/workspace-platform";
     *
     * const platform = WP.getCurrentSync();
     * const view = await platform.createView(options);
     * const viewOptions = await platform.getViewSnapshot(view.identity);
     *
     * console.log(viewOptions.workspacePlatform);
     * ```
     */
    getViewSnapshot(viewIdentity: OpenFin.Identity): Promise<BrowserViewState>;
    /**
     * Use when you need to create a View into Browser window. In addition to what regular platfom `createView` offers, here you can specify `workspacePlatform` options for settings related to Workspace Platform.
     *
     * For general details about this method, see docs for `@openfin/core`.
     *
     *
     * @example
     * ```
     * import * as WP from "@openfin/workspace-platform";
     *
     * const platform = WP.getCurrentSync();
     *
     * platform.createView({
     *   url: "https://url-to-your-app.com",
     *   ...,
     *   workspacePlatform: {
     *     browserNavigationButtons: {
     *       reload: false,
     *       back: true,
     *       forward: true
     *     }
     *   }
     * });
     * ```
     * @remarks
     * **View names are singleton**: It is not recommended to provide view names, but if they are provided, they can only be used by one view at a time.
     *
     * **Expected Behavior**: If a new view is created using the same view name as an already existing view, the new view will be created, with the view name, and the existing view will be destroyed.
     */
    createView(viewOptions: Partial<OpenFin.ViewOptions> | BrowserCreateViewRequest, target?: OpenFin.CreateViewTarget, targetView?: OpenFin.Identity): Promise<OpenFin.View>;
    /**
     * Launch an application.
     *
     * @deprecated This method is deprecated. It is recommended to use [createView](https://developers.openfin.co/of-docs/docs/platform-getting-started#add-a-view-to-an-existing-window) or [createWindow](https://developers.openfin.co/of-docs/docs/platform-getting-started#create-a-platform-window) instead.
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * const workspacePlatform = WorkspacePlatform.getCurrentSync();
     * const req = {
     *      app: {
     *          appId: 'myAppId',
     *          title: 'appTitle',
     *          manifest: 'http://localhost/app.json',
     *          manifestType: AppManifestType.Manifest,
     *          icons:[
     *              {
     *                  icon: "https://cdn.openfin.co/demos/notifications/generator/images/icon-blue.png",
     *                  src: "https://cdn.openfin.co/demos/notifications/generator/images/icon-blue.png",
     *                  type: "ico",
     *              },
     *          ]
     *      }
     * }
     * workspacePlatform.launchApp(req);
     *
     * ```
     * @param req the launch app request.
     */
    launchApp(req: LaunchAppRequest): Promise<void>;
    /**
     * Gets a workspace data structure that represents the current state of the user's desktop.
     * @param options Options for getting the current workspace.
     */
    getCurrentWorkspace(options?: GetCurrentWorkspaceOptions): Promise<Workspace>;
    /**
     * Sets the workspace as the current active workspace.  Does not apply the workspace to the user's desktop.
     * @param workspace the workspace to set as current active workspace.
     */
    setActiveWorkspace(workspace: Workspace): Promise<void>;
    /**
     * Applies the given workspace to the user's desktop.  Makes that workspace the active workspace.
     *
     * @param workspace the workspace to apply to the desktop and set as the current active workspace.
     * @param options see {@link ApplyWorkspaceOptions}.
     *
     * @returns true if the workspace was applied, false if the workspace was not applied.
     *
     * @example Brief example of how to apply a workspace, currently stored in storage, to the desktop.
     *
     * ```ts
     * const workspacePlatform = getCurrentSync();

     * // This assumes that there is at least one workspace in storage.
     * const allWorkspaces = await workspacePlatform.Storage.getWorkspaces();
     *
     * // Apply the first workspace in storage to the desktop.
     * await workspacePlatform.applyWorkspace(allWorkspaces[0], {
     *     // Customize the behavior of the applyWorkspace call.
     *     skipPrompt: false,
     *     applySnapshotOptions: {
     *       closeExistingWindows: false,
     *       closeSnapshotWindows: false,
     *       skipOutOfBoundsCheck: false,
     *     },
     * });
     * ```
     */
    applyWorkspace(workspace: Workspace, options?: ApplyWorkspaceOptions): Promise<boolean>;
    /**
     * Applies last saved version of current workspace.
     * @param options see {@link ApplyWorkspaceOptions}.
     * @returns String indicating the outcome of the API call, one of: 'success', 'not-saved-workspace', 'user-declined'.
     * See {@link RestoreLastSavedWorkspaceResult} for detailed description.
     */
    restoreLastSavedWorkspace(options?: ApplyWorkspaceOptions): Promise<RestoreLastSavedWorkspaceResult>;
    /**
     * Returns ISO language code of current set language
     *
     * @returns One of the seven ISO language codes Browser supports
     *
     * @example Example of how to get the current language on Browser
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     * WorkspacePlatform.getCurrentSync().getLanguage();
     * ```
     */
    getLanguage(): Promise<Locale>;
    /**
     * Sets the language to ISO language code passed in
     * @param locale the ISO language code
     *
     * @example Example of how to set a different language on Browser
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     * WorkspacePlatform.getCurrentSync().setLanguage('zh-CN');
     * ```
     */
    setLanguage(locale: Locale): Promise<void>;
    /**
     * Implementation for getting the notifications workspace platform configuration.
     */
    getNotificationsConfig(): Promise<NotificationsCustomManifestOptions | undefined>;
    /**
     * The browser window factory for the Workspace Platform.
     */
    Browser: BrowserWindowFactory;
    /**
     * The storage API for the Workspace Platform.
     */
    Storage: WorkspacePlatformStorage;
    /**
     * Theme API for the Workspace Platform.
     */
    Theme: ThemeApi;
}
export interface WorkspacePlatformProvider extends OpenFin.PlatformProvider {
    /**
     * Implementation for getting a list of saved pages from persistent storage.
     * @param query an optional query.
     */
    getSavedPages(query?: string): Promise<Page[]>;
    /**
     * Implementation for getting a single page in persistent storage.
     * @param id
     *
     * @returns a page object or undefined if page doesn't exist.
     */
    getSavedPage(id: string): Promise<Page | undefined>;
    /**
     * Implementation for creating a saved page in persistent storage.
     * @param req the create saved page request.
     */
    createSavedPage(req: CreateSavedPageRequest): Promise<void>;
    /**
     * Implementation for updating a saved page in persistent storage.
     * @param req the update saved page request.
     */
    updateSavedPage(req: UpdateSavedPageRequest): Promise<void>;
    /**
     * Implementation for deleting a saved page in persistent storage.
     * @param id of the id of the page to delete.
     */
    deleteSavedPage(id: string): Promise<void>;
    /**
     * Implementation for detecting if a page change qualifies as putting the page in an unsaved state.
     * @param payload the page with new changes and the identity of the OF window where the page change occured.
     */
    handlePageChanges(payload: HandlePageChangesPayload): Promise<ModifiedPageState>;
    /**
     * Implementation for getting a list of saved workspaces from persistent storage.
     * @param query an optional query.
     */
    getSavedWorkspaces(query?: string): Promise<Workspace[]>;
    /**
     * Implementation for getting a list of saved workspaces metadata from persistent storage.
     * @param query an optional query.
     */
    getSavedWorkspacesMetadata(query?: string): Promise<Pick<Workspace, 'workspaceId' | 'title'>[]>;
    /**
     * Implementation for getting a single workspace in persistent storage.
     * @param id
     *
     * * @returns a workspace object or undefined if workspace doesn't exist.
     */
    getSavedWorkspace(id: string): Promise<Workspace | undefined>;
    /**
     * Implementation for creating a saved workspace in persistent storage.
     * @param req the create saved workspace request.
     */
    createSavedWorkspace(req: CreateSavedWorkspaceRequest): Promise<void>;
    /**
     * Implementation for updating a saved workspace in persistent storage.
     * @param req the update saved workspace request.
     */
    updateSavedWorkspace(req: UpdateSavedWorkspaceRequest): Promise<void>;
    /**
     * Implementation for getting the dock provider from persistent storage.
     *
     * @param id The id of the dock provider to get.
     */
    getDockProviderConfig(id: string): Promise<DockProviderConfigWithIdentity | undefined>;
    /**
     * Implementation for saving a dock provider config to persistent storage.
     *
     * @param config The new dock config to save to persistent storage.
     */
    saveDockProviderConfig(config: DockProviderConfigWithIdentity): Promise<void>;
    /**
     * Implementation for deleting a saved workspace in persistent storage.
     * @param id of the id of the workspace to delete.
     */
    deleteSavedWorkspace(id: string): Promise<void>;
    /**
     * Applies a workspace to the user's desktop.  Makes that workspace the active workspace.
     * @param payload {@link ApplyWorkspacePayload}
     *
     * @returns true if the workspace was applied, false if the workspace was not applied.
     */
    applyWorkspace(payload: ApplyWorkspacePayload): Promise<boolean>;
    /**
     * Implementation for showing a global context menu given a menu template,
     * handler callback, and screen coordinates. For an example of overriding, see {@link WorkspacePlatformOverrideCallback}.
     * @param req the payload received by the provider call
     * @param callerIdentity OF identity of the entity from which the request originated
     */
    openGlobalContextMenu(req: OpenGlobalContextMenuPayload, callerIdentity: OpenFin.Identity): Promise<void>;
    /**
     * Implementation for showing a view tab context menu given a menu template,
     * handler callback, and screen coordinates. For an example of overriding, see {@link WorkspacePlatformOverrideCallback}.
     * @param req the payload received by the provider call
     * @param callerIdentity OF identity of the entity from which the request originated
     */
    openViewTabContextMenu(req: OpenViewTabContextMenuPayload, callerIdentity: OpenFin.Identity): Promise<void>;
    /**
     * Implementation for showing a page tab context menu given a menu template,
     * handler callback, and screen coordinates. For an example of overriding, see {@link WorkspacePlatformOverrideCallback}.
     * @param req the payload received by the provider call
     * @param callerIdentity OF identity of the entity from which the request originated
     */
    openPageTabContextMenu(req: OpenPageTabContextMenuPayload, callerIdentity: OpenFin.Identity): Promise<void>;
    /**
     * Implementation for showing a context menu for save button given a menu template,
     * handler callback, and screen coordinates. For an example of overriding, see {@link WorkspacePlatformOverrideCallback}.
     * @param req the payload received by the provider call
     * @param callerIdentity OF identity of the entity from which the request originated
     */
    openSaveButtonContextMenu(req: OpenSaveButtonContextMenuPayload, callerIdentity: OpenFin.Identity): Promise<void>;
    /**
     * Implementation for getting selected {@link CustomThemes theme} scheme.
     */
    getSelectedScheme(): ColorSchemeOptionType | null | undefined;
    /**
     * Implementation for setting selected {@link CustomThemes theme} scheme.
     * @param schemeType {@link ColorSchemeOptionType scheme} to be set
     */
    setSelectedScheme(schemeType: ColorSchemeOptionType): Promise<void>;
    /**
     * Implementation for handling Workspace analytics events
     * @param req the payload received by the provider
     */
    handleAnalytics(req: AnalyticsEvent[]): Promise<void>;
    /**
     * Override when you need to add custom functionality when creating a view.
     *
     * @param payload creatin options for the new view
     * @param callerIdentity identity of the entity that called {@link WorkspacePlatformModule.createView}
     */
    createView(payload: BrowserCreateViewPayload, callerIdentity: OpenFin.Identity): Promise<OpenFin.View>;
    /**
     * Implementation for deciding whether a modal informing about loss of unsaved changes will be displayed when closing a page.
     * The default implementation returns `{ shouldShowModal: true }` if the page has unsaved changes (`hasUnsavedChanges` page property)
     * and `false` otherwise.
     */
    handleSaveModalOnPageClose(payload: HandleSaveModalOnPageClosePayload): Promise<SaveModalOnPageCloseResult>;
    /**
     * This override is called upon closing of the page by user or for each page in a window that is being closed by user.
     *
     * In case of closing a page individually, the close operation will be aborted if a False value is returned.
     *
     * In case of closing a window, the return value will be used to form payload of handlePagesAndWindowClose override, which determines whether the window should proceed with closing.
     *
     * Default behavior: if beforeunload is disabled for the platform, True is always returned.
     * If enableBeforeUnload is set to true and getUserDecisionForBeforeUnload override is configured to respect beforeunload decisions of views,
     * then True is only returned if no views are preventing unload.
     */
    shouldPageClose(payload: ShouldPageClosePayload): Promise<ShouldPageCloseResult>;
    /**
     * This override is called upon closing of a window by user and its return value determines whether the window should proceed closing.
     * pagesPreventingClose and pagesNotPreventingClose represent pages in the window, grouped based on the value returned by shouldPageClose override for each page.
     * Default implementation will abort closing of the window if any of the pages within it are prevented from closing.
     * @param payload Contains pages that were prevented from closing, pages that weren't, and identity of the window
     * @returns `Promise<{shouldWindowClose: boolean}>` which determines whether closing of the window will proceed
     */
    handlePagesAndWindowClose(payload: HandlePagesAndWindowClosePayload): Promise<HandlePagesAndWindowCloseResult>;
    /**
     * Handle the decision of whether a Window, Page or specific View should close when trying to prevent an unload. This is meant to be overridden.
     * Called in {@link WorkspacePlatformProvider.closeWindow} and {@link WorkspacePlatformProvider.closeView}.
     *
     * When closing a Page, this override is called by {@link WorkspacePlatformProvider.shouldPageClose}
     * and page proceeds to close if all views passed in are determined to close. In this case, the `closeType` property will have `'page'` value.
     *
     * Normally you would use this method to show a dialog indicating that there are Views that are trying to prevent an unload.
     * By default it will always return all Views passed into it as meaning to close.
     * @param payload
     * @example
     *
     * ```js
     * const overrideCallback = (PlatformProvider) => {
     *     class Override extends PlatformProvider {
     *         async getUserDecisionForBeforeUnload(payload, callerIdentity) {
     *             const { windowShouldClose, viewsPreventingUnload, viewsNotPreventingUnload, windowId, closeType } = payload;
     *
     *             // launch dialog and wait for user response
     *             const continueWithClose = await showDialog(viewsPreventingUnload, windowId, closeType);
     *
     *             if (continueWithClose) {
     *                 return { windowShouldClose, viewsToClose: [...viewsNotPreventingUnload, ...viewsPreventingUnload] };
     *             } else {
     *                 return { windowShouldClose: false, viewsToClose: [] };
     *             }
     *         }
     *     }
     *     return new Override();
     * }
     *
     * fin.Platform.init({ overrideCallback });
     *
     * async function showDialog(viewsPreventingUnload, windowId, closeType) {
     *     // Show a dialog and await for user response
     * }
     * ```
     *
     */
    getUserDecisionForBeforeUnload(payload: ViewsPreventingUnloadPayload): Promise<OpenFin.BeforeUnloadUserDecision>;
    /**
     * Implementation for setting the active page in a browser window.
     * Called when the active page is changed and on browser window creation.
     */
    setActivePage(payload: SetActivePageForWindowPayload): Promise<void>;
    /**
     * Implementation for creating a copy of a page. Called when a page is Saved-As or Duplicated.
     *
     * Note: The `page.layout` and `page.panels` property cannot be overridden for 'Save As' operations,
     * the `page.layout` and `page.panels` property provided in the return value will be ignored, and the layout and panels of
     * the original page will remain after 'Save As' is performed.
     */
    copyPage(payload: CopyPagePayload): Promise<Page>;
    /**
     * Implementation for getting current selected language
     * @returns language in ISO language code
     */
    getLanguage(): Promise<Locale>;
    /**
     * Implementation for setting a language
     * @param locale in ISO language code format
     */
    setLanguage(locale: Locale): Promise<void>;
    /**
     * Implementation for adding custom default page
     * @param payload {@link AddDefaultPagePayload}
     */
    addDefaultPage(payload: AddDefaultPagePayload): Promise<void>;
    getPageByViewIdentity(viewIdentity: OpenFin.Identity): Promise<Awaited<ReturnType<BrowserWindowFactory['getPageByViewIdentity']>>>;
}
/**
 * The origins from which a custom action can be invoked
 */
export declare enum CustomActionCallerType {
    CustomButton = "CustomButton",
    StoreCustomButton = "StoreCustomButton",
    CustomDropdownItem = "CustomDropdownItem",
    GlobalContextMenu = "GlobalContextMenu",
    ViewTabContextMenu = "ViewTabContextMenu",
    PageTabContextMenu = "PageTabContextMenu",
    SaveButtonContextMenu = "SaveButtonContextMenu",
    API = "API"
}
/**The payload received by a Custom Action.
 * The `callerType` property can be used to determine what data is available in the payload and cast accordingly.
 * When `callerType == CustomActionCallerType.API`, the payload is defined by the code directly invoking the action.*/
export type CustomActionPayload = {
    callerType: CustomActionCallerType.API;
} | CustomButtonActionPayload | StoreCustomButtonActionPayload | CustomDropdownItemActionPayload | GlobalContextMenuOptionActionPayload | ViewTabCustomActionPayload | PageTabContextMenuOptionActionPayload | OpenSaveContextMenuOptionActionPayload;
export interface GetCurrentWorkspaceOptions {
    skipSnapshotUpdate?: boolean;
}
/**
 * Options for the {@link WorkspacePlatformModule.applyWorkspace applyWorkspace} method.
 *
 */
export interface ApplyWorkspaceOptions {
    /**
     * If true, the workspace will be applied without prompting the user to confirm.
     * If false, the user will be prompted to confirm the workspace application.
     * @default false
     */
    skipPrompt?: boolean;
    /**
     * The window to use as the parent for the workspace switch confirmation dialog.
     */
    promptContainerWindowIdentity?: OpenFin.Identity;
    /**
     * Options to apply the workspace snapshot with.
     */
    applySnapshotOptions?: ApplySnapshotOptions;
    /** Should the dialog modal be centered on the monitor instead of on top of the platform window */
    shouldCenterModalOnMonitor?: boolean;
}
/**
 * Options used within the {@link WorkspacePlatformModule.applyWorkspace applyWorkspace} method.
 *
 * @inheritDoc OpenFin.ApplySnapshotOptions
 */
export interface ApplySnapshotOptions extends OpenFin.ApplySnapshotOptions {
    /**
     * When true, applyWorkspace will close all existing windows,
     * replacing current Platform state with the given snapshot.
     *
     * @default true
     */
    closeExistingWindows?: boolean;
}
/**
 * Payload received by applyWorkspace platform provider method
 */
export type ApplyWorkspacePayload = Workspace & {
    options?: ApplyWorkspaceOptions;
};
/**
 * Variants of results returned by restoreLastSavedWorkspace method.
 * * 'success' - workspace was successfully applied
 * * 'not-saved-workspace' - currently active workspace has never been saved, hence no changes were applied
 * * 'user-declined' - confirmation modal was shown and user declined to apply last saved workspace (only relevant when skipPrompt==false)
 */
export type RestoreLastSavedWorkspaceResult = 'success' | 'not-saved-workspace' | 'user-declined';
/**
 * Defines custom action map where the key is the custom action ID and value is the action handler
 */
export interface CustomActionsMap {
    [actionId: string]: (payload: CustomActionPayload) => any;
}
/**
 * Configuration object of the Workspace Platform's Analytics Config.
 */
export interface AnalyticsConfig {
    /**
     * Enable sending of Analytics data to OpenFin
     *
     * @default false
     *
     * @remarks OpenFin workspace utilizes a [HTML iframe](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/iframe) in order to send analytics data to OpenFin. In order to facilitate this, and allow for the use of `fin` APIs within the iframe, you must enable injection of the OpenFin API into cross-origin iframes. This can be configured within the [manifest](https://developers.openfin.co/of-docs/docs/application-configuration) like so:
     * ```json
     * {
     *     "platform": {
     *         "api": {
     *             "iframe": {
     *                 "crossOriginInjection": true
     *             }
     *         },
     *         // The rest of the manifest configuration is omitted for brevity
     *     }
     * }
     * ```
     */
    sendToOpenFin: boolean;
}
export declare const SUPPORTED_LANGUAGES: string[];
export type Locale = Languages;
/**
 * Configures the workspace to self-host using an asar bundle at the
 * specified path.
 *
 * @remarks Intended as a development tool - in production,
 * use {@link WorkspaceAsarAssetConfig}.
 */
export type WorkspaceAsarPathConfig = {
    /**
     * Path of the asar bundle with which to self-host.
     */
    path: string;
};
/**
 * Configures the workspace to self-host using the specified asar bundle
 * app asset.
 */
export type WorkspaceAsarAssetConfig = {
    /**
     * App asset alias of the asar bundle with which to self-host.
     */
    alias: string;
};
/**
 * Configuration for initializing a Workspace platform.
 */
export interface WorkspacePlatformInitConfig {
    customActions?: CustomActionsMap;
    /**
     * Config for overriding browser options and behavior.
     * Set to null to initialize the platform without the browser
     */
    browser?: BrowserInitConfig | null;
    /**
     * Customize the Looks and Feel of the Workspace Platform by providing a custom palette.
     *
     * The `backgroundPrimary` color **must** be either a hex, rgb, rgba, hsl, or hsla value.
     *
     * Two palettes are provided by default: `light` and `dark`.
     * The `dark` palette is used by default.
     *
     * @example
     *
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     *
     * // This is the palette used to create the OpenFin dark theme
     * const customPalette: WorkspacePlatform.CustomPaletteSet = {
     *     brandPrimary: '#504CFF',
     *     brandSecondary: '#383A40',
     *     backgroundPrimary: '#000',
     *     background1: '#111214',
     *     background2: '#1E1F23',
     *     background3: '#24262B',
     *     background4: '#2F3136',
     *     background5: '#383A40',
     *     background6: '#53565F',
     *     statusSuccess: '#35C759',
     *     statusWarning: '#C93400',
     *     statusCritical: '#000',
     *     statusActive: '#0879C4',
     *     inputBackground: '#53565F',
     *     inputColor: '#FFFFFF',
     *     inputPlaceholder: '#C9CBD2',
     *     inputDisabled: '#7D808A',
     *     inputFocused: '#C9CBD2',
     *     textDefault: '#FFFFFF',
     *     textHelp: '#C9CBD2',
     *     textInactive: '#7D808A',
     * };
     *
     * const customTheme: WorkspacePlatform.CustomThemes = [{
     *   label: "My Custom Theme",
     *   palette: customPalette
     * }];
     *
     * await WorkspacePlatform.init({
     *   browser: {
     *      title: "My Browser"
     *   },
     *   theme: customThemes,
     *   overrideCallback
     * });
     * ```
     */
    theme?: CustomThemes;
    /**
     * Set a language on Browser by providing one of the seven languages that Workspace supports
     * Must specify one of the ISO language codes 'en-US', 'ja-JP', 'zh-CN', 'ko-KR', 'ru-RU', 'de-DE' or 'zh-Hant'
     *
     * @example
     * ```ts
     * await WorkspacePlatform.init({
     *   browser: {
     *      title: "My Browser"
     *   },
     *   language: {
     *      initialLanguage: 'ru-RU'
     *   }
     * });
     * ```
     * @default 'en-EN'
     *
     */
    language?: {
        initialLanguage?: Locale;
    };
    /**
     * Override workspace platform behavior
     */
    overrideCallback?: WorkspacePlatformOverrideCallback | OpenFin.ConstructorOverride<WorkspacePlatformProvider>[];
    /**
     * Override workspace platform interop behavior
     * https://developer.openfin.co/docs/javascript/stable/classes/OpenFin.InteropBroker.html
     */
    interopOverride?: OpenFin.OverrideCallback<OpenFin.InteropBroker, OpenFin.InteropBroker> | OpenFin.ConstructorOverride<OpenFin.InteropBroker>[];
    /**
     * Config for Workspace Platform analytics
     */
    analytics?: AnalyticsConfig;
    /**
     * Config for Workspace Platform Integrations
     *
     * @example
     * ```ts
     * import * as WorkspacePlatform from '@openfin/workspace-platform';
     * import { Integrations } from '@openfin/workspace';
     *
     * const microsoftIntegration = new Integrations.Microsoft365WorkflowIntegration({
     *     connect: {
     *         clientId: '',
     *         redirectUri: '',
     *         tenantId: ''
     *     }
     * });
     *
     * await WorkspacePlatform.init({
     *   browser: { },
     *   integrations: [microsoftIntegration]
     * });
     * ```
     */
    integrations?: WorkflowIntegration[];
    /**
     * Config for overriding default notifications behaviour.
     * Leave undefined to use OpenFin hosted Notification Center.
     */
    notifications?: NotificationsCustomManifestOptions;
    /**
     * Configuration for self-hosting of workspace assets.
     */
    workspaceAsar?: WorkspaceAsarAssetConfig | WorkspaceAsarPathConfig;
}
/**
 * Extend or replace default functionality in order to customize behavior of a Workspace Platform Provider.
 *
 * To implement your own handlers for Workspace Platform behavior, extend the provided class and override any methods you'd like to alter.
 *
 * ```ts
 * import * as WorkspacePlatform from '@openfin/workspace-platform';
 * import { UpdateSavedPageRequest } from '../../client-api-platform/src/shapes';
 *
 * const overrideCallback: WorkspacePlatform.WorkspacePlatformOverrideCallback = async (
 *    WorkspacePlatformProvider
 * ) => {
 *   class Override extends WorkspacePlatformProvider {
 *       // Override the default behavior of updateSavedPage
 *       updateSavedPage = async (req: UpdateSavedPageRequest): Promise<void> => {
 *           console.log(`saving page ${req.page.pageId}`);
 *           // calling custom function to the save page here
 *       };
 *
 *       // add a custom menu item in Global Context Menu
 *       openGlobalContextMenu(req: WorkspacePlatform.OpenGlobalContextMenuPayload, callerIdentity: any) {
 *            return super.openGlobalContextMenu(
 *               {
 *                   ...req,
 *                   template: [
 *                       ...req.template,
 *                       {
 *                           label: 'Sample custom global option',
 *                           data: {
 *                               type: GlobalContextMenuOptionType.Custom,
 *                               action: {
 *                                      // This action needs to be registered in customActions property in the call WorkspacePlatform.init
 *                                   id: 'sample-custom-global-menu-action'
 *                               }
 *                           }
 *                       }
 *                   ]
 *               },
 *               callerIdentity
 *           );
 *       }
 *
 *       // add a custom menu item in View Tab Context Menu
 *       openViewTabContextMenu = async (payload: OpenViewTabContextMenuPayload, callerIdentity) => {
 *           const viewsInfo = await Promise.all(payload.selectedViews.map(async (v) => fin.View.wrapSync(v).getInfo()));
 *
 *           const enableBack = viewsInfo.every((viewInfo) => viewInfo.canNavigateBack === true);
 *           const enableForward = viewsInfo.every((viewInfo) => viewInfo.canNavigateForward === true);
 *
 *           return super.openViewTabContextMenu({
 *               ...payload,
 *               template: [
 *                   {
 *                       label: 'Sample View Tab Context Menu',
 *                       data: {
 *                           type: ViewTabMenuOptionType.Custom,
 *                           action: {
 *                                  // This action needs to be registered in customActions property in the call WorkspacePlatform.init
 *                               id: 'sample-viewtab-action',
 *                               customData: 'Custom View Tab Action'
 *                           }
 *                       }
 *                   },
 *                   {
 *                      type: 'normal',
 *                      label: 'Back',
 *                      data: {
 *                          type: ViewTabMenuOptionType.Back
 *                      },
 *                      enabled: enableBack
 *                   },
 *                   {
 *                      type: 'normal',
 *                      label: 'Forward',
 *                      data: {
 *                          type: ViewTabMenuOptionType.Forward
 *                      },
 *                      enabled: enableForward
 *                   },
 *                   ...payload.template
 *               ]
 *           }, callerIdentity);
 *       };
 *
 *       // add a custom menu item in Save Context Menu
 *       openSaveButtonContextMenu = (req: WorkspacePlatform.OpenSaveButtonContextMenuPayload, callerIdentity: OpenFin.Identity) => {
 *         return super.openSaveButtonContextMenu(
 *             {
 *                 ...req,
 *                 template: [
 *                     ...req.template,
 *                     {
 *                         label: 'Save custom option',
 *                         data: {
 *                             type: SaveButtonContextMenuOptionType.Custom,
 *                             action: {
 *                                 id: 'sample-custom-action-name',
 *                                 customData: {
 *                                     someProp: 'Save Button task'
 *                                 }
 *                             }
 *                         }
 *                     }
 *                 ]
 *             },
 *             callerIdentity
 *            );
 *        }
 *   }
 *   return new Override();
 * };
 *
 * await WorkspacePlatform.init({
 *  browser: {
 *      title: "My Workspace Platform"
 *  }
 *  overrideCallback,
 *  customActions: {
 *    'sample-custom-global-menu-action': (payload: CustomActionPayload) => {
 *      alert('This custom action works ' + JSON.stringify(payload));
 *      return 'someresponse';
 *    },
 *    'sample-viewtab-action': (payload: ViewTabCustomActionPayload) => {
 *      alert('This custom action works ' + JSON.stringify(payload));
 *      return 'someresponse';
 *    }
 *  }
 * });
 * ```
 */
export type WorkspacePlatformOverrideCallback = OpenFin.OverrideCallback<WorkspacePlatformProvider>;
/**
 * @deprecated
 */
export type BrowserOverrideCallback = WorkspacePlatformOverrideCallback;
export type LaunchDockEntryPayload = {
    entry: DockEntry;
    sourceEvent?: Pick<MouseEvent, 'ctrlKey' | 'metaKey' | 'shiftKey'>;
};
export type BookmarkDockEntryPayload = {
    entry: DockEntry;
};
/**
 * Configuration options for Browser window's icons.
 */
export type IconSize = 'large' | 'default';
/**
 * Configuration for initializing a Browser.
 */
export interface BrowserInitConfig {
    /**
     * Default options for creating a new Browser window. These options are not applied on any non-Browser windows that get created.  These default options will take precedence over
     * defaultWindowOptions included in the manifest.  Any option not included in WorkspacePlatform.getCurrentSync().Browser.createWindow(options) call will default to the value provided in this field.
     */
    defaultWindowOptions?: Partial<BrowserCreateWindowRequest>;
    /** Default options when creating a new page. If `iconUrl`, `unsavedIconUrl`, `panels` or `closeButton` are not defined when creating a page, setting will default to `defaultPageOptions`. */
    defaultPageOptions?: Pick<Page, 'iconUrl' | 'unsavedIconUrl' | 'closeButton' | 'panels'>;
    /**
     * The default options when creating a new browser window. Any option not included in WorkspacePlatform.getCurrentSync().Browser.createView(options) call will default to the value provided in this field.
     */
    defaultViewOptions?: Partial<OpenFin.ViewOptions>;
    /**
     * The platform title. UI friendly title for the platform in browser.
     */
    title?: string;
    /**
     * By default, the icons in the browser are displayed at the default size. If you
     * want to display the icons at a larger size, set this property to 'large'. This
     * will increase the size of the icons in the browser. If you have custom icons
     * that are PNGs you will need to update these assets for best results.
     */
    browserIconSize?: IconSize;
    /**
     * Override workspace platform behavior
     *
     * @deprecated Please use the `overrideCallback` property of {@link WorkspacePlatformInitConfig}
     */
    overrideCallback?: BrowserOverrideCallback;
    /**
     * @deprecated
     * Override workspace platform interop behavior
     *
     * https://developer.openfin.co/docs/javascript/stable/classes/OpenFin.InteropBroker.html
     */
    interopOverride?: OpenFin.OverrideCallback<OpenFin.InteropBroker, OpenFin.InteropBroker>;
}
interface WorkspaceMetadata {
    APIVersion: string;
}
export interface Workspace {
    workspaceId: string;
    /** While not required, it is suggested that Workspace titles be unique. */
    title: string;
    metadata?: WorkspaceMetadata;
    snapshot: BrowserSnapshot;
}
/**
 * Request for creating a saved workspace in persistent storage.
 */
export interface CreateSavedWorkspaceRequest {
    /** The workspace to create. */
    workspace: Workspace;
}
/**
 * Request for updating a saved workspace in persistent storage.
 */
export interface UpdateSavedWorkspaceRequest {
    /** The ID of the workspace to update. */
    workspaceId: string;
    /** The updated workspace. */
    workspace: Workspace;
}
export type OpenSaveWorkspaceMenuRequest = {
    menuType: SaveModalType.SAVE_WORKSPACE | SaveModalType.SAVE_WORKSPACE_AS | SaveModalType.RENAME_WORKSPACE;
    id?: never;
};
/**
 * Request to create a save modal.
 * @private
 */
export type OpenSaveMenuRequest = {
    menuType: SaveModalType.SAVE_PAGE | SaveModalType.SAVE_PAGE_AS | SaveModalType.RENAME_PAGE;
    id: string;
} | OpenSaveWorkspaceMenuRequest;
export type TaskbarIcon = {
    dark: string;
    light: string;
};
/**
 * Launch bookmark request payload
 */
export interface LaunchBookmarkPayload {
    bookmark: BookmarkNode;
    sourceIdentity: OpenFin.Identity;
    sourceEvent: Pick<MouseEvent, 'ctrlKey' | 'metaKey' | 'shiftKey'>;
}
export type SearchProviderFilter = {
    id: string;
    title: string;
    icon?: {
        light: string;
        dark: string;
    };
};
