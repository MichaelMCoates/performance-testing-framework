import { CustomThemes } from '../shapes';
export declare const getThemes: () => CustomThemes;
/**
 * initTheming()
 * @param customThemes array of theme objects
 * Accepts an array of CustomThemes objects and stores it
 * @returns array of custom theme objects
 */
export default function initTheming(customThemes: CustomThemes | undefined): Promise<void>;
