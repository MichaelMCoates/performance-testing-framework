export declare class Mutex {
    private queue;
    private locked;
    constructor();
    lock(): Promise<void>;
    unlock(): void;
}
