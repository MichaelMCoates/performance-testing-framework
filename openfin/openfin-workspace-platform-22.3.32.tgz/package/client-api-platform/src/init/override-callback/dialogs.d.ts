import type OpenFin from '@openfin/core';
import { ShowQuitPlatformDialogRequest, ShowUpdateVersionModalRequest } from '../../../../client-api-platform/src/shapes';
export declare const showQuitPlatformDialogInternal: (req: ShowQuitPlatformDialogRequest, identity: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Promise<void>;
export declare const showUpdateVersionModalInternal: (req: ShowUpdateVersionModalRequest, identity: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Promise<void>;
