import type OpenFin from '@openfin/core';
import { BrowserInitConfig } from '../../../../client-api-platform/src/shapes';
export declare const PAGE_CONTEXT_GROUP = "CONTEXT_GROUP_PAGE";
/**
 * Create the interop override for WorkspacePlatform / Enterprise Browser
 * @param browser - optional - browser init config to determine if this is Enterprise Browser or not
 */
export declare const getConstructorOverride: (browser?: BrowserInitConfig) => OpenFin.ConstructorOverride<OpenFin.InteropBroker>;
export declare const getInteropOverrideCallback: (overrideCallback?: OpenFin.OverrideCallback<OpenFin.InteropBroker, OpenFin.InteropBroker> | OpenFin.ConstructorOverride<OpenFin.InteropBroker>[], browser?: BrowserInitConfig) => OpenFin.OverrideCallback<OpenFin.InteropBroker, OpenFin.InteropBroker> | OpenFin.ConstructorOverride<OpenFin.InteropBroker>[];
