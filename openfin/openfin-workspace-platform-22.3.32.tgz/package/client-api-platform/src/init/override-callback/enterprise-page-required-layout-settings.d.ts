import { PageLayout } from '../../../../common/src/api/pages/shapes';
export type EnterprisePageRequiredLayoutSettings = {
    newTabButtonUrl: string;
};
export declare const applyEnterprisePageRequiredLayoutSettings: (requiredSettings: EnterprisePageRequiredLayoutSettings, layout: PageLayout) => void;
