import { OpenFin } from '@openfin/core';
export declare const createNonLayoutViewComponents: (overrideOptions: OpenFin.PlatformWindowCreationOptions) => Promise<void>;
