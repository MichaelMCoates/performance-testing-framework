import type OpenFin from '@openfin/core';
export declare const parseInternalWorkspaceDataOnWindows: <T extends OpenFin.Snapshot>(snapshot: T) => T;
export declare const parseWorkspacePlatformOnWindows: <T extends OpenFin.Snapshot>(snapshot: T) => T;
