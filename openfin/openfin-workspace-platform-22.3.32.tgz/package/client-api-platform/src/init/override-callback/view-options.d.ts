import type OpenFin from '@openfin/core';
import { BrowserCreateViewRequest, BrowserViewState, BrowserWorkspacePlatformViewOptions } from '../../../../client-api-platform/src/shapes';
export declare function preserveInteropIfManifestConflict(opts: Partial<OpenFin.ViewOptions>, fetchManifest: ({ manifestUrl }: {
    manifestUrl: string;
}, callerIdentity: OpenFin.Identity) => any, callerIdentity: OpenFin.Identity): Promise<any>;
type ViewStateBase = Pick<BrowserViewState, '_internalWorkspaceData' | 'workspacePlatform'>;
export declare const mapInternalWorkspaceDataToWorkspacePlatform: <T extends ViewStateBase>(viewState: T) => T;
export declare const mapWorkspacePlatformToInternalWorkspaceData: <T extends ViewStateBase>(viewState: T) => T;
export declare const setHotkeysIfNavigationButtonsEnabled: (options: BrowserCreateViewRequest) => Promise<BrowserCreateViewRequest>;
export declare const registerHotkeyListenersIfEnabled: (viewIdentity: OpenFin.Identity, buttonOptions?: BrowserWorkspacePlatformViewOptions["browserNavigationButtons"]) => void;
export {};
