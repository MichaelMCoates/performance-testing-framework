import type OpenFin from '@openfin/core';
type DefaultViewOptions = Partial<OpenFin.MutableViewOptions> & {
    downloadShelf?: OpenFin.ConstWindowOptions['downloadShelf'];
};
export declare const DEFAULT_VIEW_OPTIONS: DefaultViewOptions;
export declare function applyViewDefaults(options: Partial<OpenFin.ViewOptions>, initViewOptions?: Partial<OpenFin.ViewOptions>): any;
export {};
