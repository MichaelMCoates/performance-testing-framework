export declare const mockSnapshotWithInternalData1: {
    windows: {
        layout: {
            content: {
                type: string;
                content: ({
                    type: string;
                    content: {
                        type: string;
                        componentName: string;
                        componentState: {
                            _internalWorkspaceData: {
                                viewIdentifier: string;
                                browserNavigationButtons: {
                                    back: boolean;
                                    forward: boolean;
                                    reload: boolean;
                                };
                            };
                        };
                    }[];
                } | {
                    type: string;
                    content: ({
                        type: string;
                        content: {
                            type: string;
                            content: {
                                type: string;
                                componentName: string;
                                componentState: {
                                    _internalWorkspaceData: {
                                        viewIdentifier: string;
                                        browserNavigationButtons: {
                                            back: boolean;
                                            forward: boolean;
                                            reload: boolean;
                                        };
                                    };
                                };
                            }[];
                        }[];
                    } | {
                        type: string;
                        content: {
                            type: string;
                            componentName: string;
                            componentState: {
                                _internalWorkspaceData: {
                                    viewIdentifier: string;
                                    browserNavigationButtons: {
                                        reload: boolean;
                                    };
                                };
                            };
                        }[];
                    })[];
                })[];
            }[];
        };
    }[];
};
export declare const mockSnapshotWithWorkspacePlatform1: {
    windows: {
        layout: {
            content: {
                type: string;
                content: ({
                    type: string;
                    content: {
                        type: string;
                        componentName: string;
                        componentState: {
                            _internalWorkspaceData: {
                                viewIdentifier: string;
                            };
                            workspacePlatform: {
                                browserNavigationButtons: {
                                    back: boolean;
                                    forward: boolean;
                                    reload: boolean;
                                };
                            };
                        };
                    }[];
                } | {
                    type: string;
                    content: ({
                        type: string;
                        content: {
                            type: string;
                            content: {
                                type: string;
                                componentName: string;
                                componentState: {
                                    _internalWorkspaceData: {
                                        viewIdentifier: string;
                                    };
                                    workspacePlatform: {
                                        browserNavigationButtons: {
                                            back: boolean;
                                            forward: boolean;
                                            reload: boolean;
                                        };
                                    };
                                };
                            }[];
                        }[];
                    } | {
                        type: string;
                        content: {
                            type: string;
                            componentName: string;
                            componentState: {
                                _internalWorkspaceData: {
                                    viewIdentifier: string;
                                };
                                workspacePlatform: {
                                    browserNavigationButtons: {
                                        reload: boolean;
                                    };
                                };
                            };
                        }[];
                    })[];
                })[];
            }[];
        };
    }[];
};
export declare const mockSnapshotWithInternalData2: {
    windows: {
        workspacePlatform: {
            pages: {
                layout: {
                    content: {
                        type: string;
                        content: ({
                            type: string;
                            content: {
                                type: string;
                                content: {
                                    type: string;
                                    componentName: string;
                                    componentState: {
                                        _internalWorkspaceData: {
                                            viewIdentifier: string;
                                            browserNavigationButtons: {
                                                back: boolean;
                                                forward: boolean;
                                                reload: boolean;
                                            };
                                        };
                                    };
                                }[];
                            }[];
                        } | {
                            type: string;
                            content: {
                                type: string;
                                content: {
                                    type: string;
                                    componentName: string;
                                    componentState: {
                                        _internalWorkspaceData: {
                                            viewIdentifier: string;
                                            browserNavigationButtons: {
                                                reload: boolean;
                                            };
                                        };
                                    };
                                }[];
                            }[];
                        })[];
                    }[];
                };
            }[];
        };
    }[];
};
export declare const mockSnapshotWithWorkspacePlatform2: {
    windows: {
        workspacePlatform: {
            pages: {
                layout: {
                    content: {
                        type: string;
                        content: ({
                            type: string;
                            content: {
                                type: string;
                                content: {
                                    type: string;
                                    componentName: string;
                                    componentState: {
                                        _internalWorkspaceData: {
                                            viewIdentifier: string;
                                        };
                                        workspacePlatform: {
                                            browserNavigationButtons: {
                                                back: boolean;
                                                forward: boolean;
                                                reload: boolean;
                                            };
                                        };
                                    };
                                }[];
                            }[];
                        } | {
                            type: string;
                            content: {
                                type: string;
                                content: {
                                    type: string;
                                    componentName: string;
                                    componentState: {
                                        _internalWorkspaceData: {
                                            viewIdentifier: string;
                                        };
                                        workspacePlatform: {
                                            browserNavigationButtons: {
                                                reload: boolean;
                                            };
                                        };
                                    };
                                }[];
                            }[];
                        })[];
                    }[];
                };
            }[];
        };
    }[];
};
