import OpenFin from '@openfin/core';
import type { AttachedPage, AttachedPageInternal } from '../../../../common/src/api/pages/shapes';
import { BrowserInitConfig } from '../..';
export declare const applyPageDefaults: (pages: AttachedPage[], initOptions?: Pick<BrowserInitConfig, "defaultPageOptions" | "defaultViewOptions" | "defaultWindowOptions">, overrideOptions?: OpenFin.PlatformWindowCreationOptions) => Promise<AttachedPageInternal[]>;
