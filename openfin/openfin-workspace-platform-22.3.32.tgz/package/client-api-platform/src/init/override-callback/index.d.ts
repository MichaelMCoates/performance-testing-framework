import type OpenFin from '@openfin/core';
import { NotificationsCustomManifestOptions } from '../../../../common/src/api/shapes/notifications';
import { BrowserInitConfig, WorkspacePlatformOverrideCallback, WorkspacePlatformProvider } from '../../../../client-api-platform/src/shapes';
export declare const getConstructorOverride: (browserInitOptions: BrowserInitConfig | null, notificationsConfig?: NotificationsCustomManifestOptions) => OpenFin.ConstructorOverride<WorkspacePlatformProvider>;
export declare function getOverrideCallback(browserInitOptions: BrowserInitConfig | null, overrideCallback?: WorkspacePlatformOverrideCallback | OpenFin.ConstructorOverride<WorkspacePlatformProvider>[], notificationsConfig?: NotificationsCustomManifestOptions): WorkspacePlatformOverrideCallback | OpenFin.ConstructorOverride<WorkspacePlatformProvider>[];
