import type OpenFin from '@openfin/core';
import type { PreloadedThemeData } from '../../../../common/src/api/theming';
import { BrowserInitConfig } from '../../../../client-api-platform/src/shapes';
/**
 * Applies default options to the creation of browser windows.
 */
export declare function applyBrowserDefaults(options: OpenFin.PlatformWindowCreationOptions, initOptions: Pick<BrowserInitConfig, 'defaultWindowOptions' | 'defaultPageOptions' | 'defaultViewOptions' | 'browserIconSize'> | undefined, themeData?: PreloadedThemeData): Promise<OpenFin.PlatformWindowCreationOptions>;
