import type OpenFin from '@openfin/core';
/**
 * Gets the last focused browser window.
 * @returns {Promise<OpenFin.Identity | undefined>} The last focused browser window identity, or undefined if not found.
 */
export declare function getLastFocusedBrowserWindow(): Promise<OpenFin.Identity | undefined>;
/**
 * Gets the last focused browser window that isn't minimized.
 * @returns {Promise<OpenFin.Identity | undefined>} The last focused browser window identity that isn't minimized, or undefined if not found.
 */
export declare function getLastFocusedUnminimizedBrowserWindow(): Promise<OpenFin.Identity | undefined>;
/**
 * Listen for browser window events to track focus and window state.
 */
export declare function listenForBrowserWindowFocus(): Promise<void>;
/**
 * Selects the appropriate browser window based on the product requirements:
 * 1. Most recently active visible window
 * 2. Most recently active minimized window if no visible windows
 * 3. New window if no existing windows
 */
export declare function selectAppropriateWindow(): Promise<OpenFin.Identity>;
