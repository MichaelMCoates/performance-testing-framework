import type OpenFin from '@openfin/core';
import { AttachedPage, ExtendedPanelConfig, PanelConfig } from '../../../common/src/api/pages/shapes';
export declare function convertPanelViewOpts(panels: PanelConfig[], updatePageRequest?: {
    identity: OpenFin.Identity;
    pageId: string;
}): Promise<ExtendedPanelConfig[]>;
export declare function createPanelViewsForPages(pages: AttachedPage[]): Promise<void>;
export declare function createPanelViews(panels: PanelConfig[]): Promise<(void | OpenFin.View)[]>;
