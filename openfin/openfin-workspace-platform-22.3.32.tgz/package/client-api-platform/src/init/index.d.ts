import OpenFin from '@openfin/core';
import { WorkspacePlatformInitConfig } from '../../../client-api-platform/src/shapes';
/**
 * Initilaize a Workspace Platform.
 *
 * ```ts
 * import * as WorkspacePlatform from '@openfin/workspace-platform';
 *
 * const customThemes: WorkspacePlatform.CustomThemes = [{
 *   label: "OpenFin's Custom Theme",
 *   palette: {
 *      // Required color options
 *      brandPrimary: '#F51F63',
 *      brandSecondary: '#1FF58A',
 *      backgroundPrimary: '#F8E71C', // hex, rgb/rgba, hsl/hsla only - no string colors: 'red'
 *   }
 * }];
 *
 * const overrideCallback: WorkspacePlatform.WorkspacePlatformOverrideCallback = async (
 *     WorkspacePlatformProvider
 *   ) => {
 *   class Override extends WorkspacePlatformProvider {
 *     async quit(payload, callerIdentity) {
 *       return super.quit(payload, callerIdentity);
 *     }
 *   }
 *   return new Override();
 * };
 *
 *
 * await WorkspacePlatform.init({
 *   browser: { overrideCallback },
 *   theme: customThemes
 * });
 * ```
 * @param options options for configuring the platform.
 */
export declare const init: ({ theme, customActions, language, ...rest }: WorkspacePlatformInitConfig) => Promise<OpenFin.Platform>;
