export declare const getPlatformLabel: () => Promise<string>;
/**
 * registerPlatformLabel()
 * @param platformLabel - UI Friendly title for platform in browser. Defaults to "Platform" internally
 */
export default function registerPlatformLabel(platformLabel: string): void;
