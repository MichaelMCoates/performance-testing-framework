/**
 * Cleanup browser modals.
 *
 * Once the last OpenFin Browser window is closed, any remaining modals will close.
 */
export declare const registerBrowserModalsCleanup: () => Promise<void>;
