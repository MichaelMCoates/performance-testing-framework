import { AiPanelOptions, BrowserInitConfig } from '../../../client-api-platform/src/shapes';
export declare const setIsEnterprisePlatform: (value: boolean) => void;
export declare const getIsEnterprisePlatform: () => boolean;
export declare const getAiPanelOptions: () => AiPanelOptions;
export declare const setAiPanelOptions: (browserInitOptions: BrowserInitConfig) => AiPanelOptions;
