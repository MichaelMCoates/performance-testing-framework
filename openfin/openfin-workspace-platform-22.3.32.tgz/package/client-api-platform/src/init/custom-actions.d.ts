import { CustomActionsMap, InvokeCustomActionRequest } from '..';
export declare const initCustomActions: (actions: CustomActionsMap) => void;
export declare const invokeCustomActionInternal: ({ actionId, payload }: InvokeCustomActionRequest) => Promise<any>;
