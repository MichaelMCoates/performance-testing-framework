import type OpenFin from '@openfin/core';
import type { Page } from '../../../common/src/api/pages/shapes';
import type { BrowserSnapshot } from '..';
export declare const filterSnapshotWindows: (win: OpenFin.WindowOptions) => boolean;
/**
 * fitToMonitor()
 * Function to determine if window size is too large
 * for available rectangle area.
 *
 * - Checks monitor data for available rectangle coords
 * - Defines max width/height for current monitor
 * - Defines default width/height if property is not set
 * - Updates options object default width/height if they exceed max values
 *
 * Ticket: WRK-1084
 *
 * @param options - Object passed into createWindow -> contains height and width
 * @returns unprocessed or processed options object
 */
export declare const fitToMonitor: (options: OpenFin.PlatformWindowCreationOptions) => Promise<OpenFin.PlatformWindowCreationOptions>;
type LegacyWindowOptions = Omit<OpenFin.PlatformWindowCreationOptions, 'workspacePlatform'> & {
    pages?: Page[];
    workstacks?: Page[];
};
export declare const initWorkspacePlatformOptions: (options: LegacyWindowOptions | OpenFin.PlatformWindowCreationOptions) => OpenFin.PlatformWindowCreationOptions;
export type WindowType = 'browser' | 'platform' | 'classic' | 'mixed' | 'enterprise';
/**
 * checkHasBrowserWindows
 * Determines whether the snapshot has browser windows.
 *
 * @param snapshot - The snapshot to check.
 *
 * @returns - Whether the snapshot has browser windows.
 */
export declare function checkHasBrowserWindows(snapshot: BrowserSnapshot): boolean;
export declare const copyObject: <T>(obj: T) => T;
export declare function validateTabDimensionsIfAny(overrideOptions: OpenFin.PlatformWindowCreationOptions): void;
export {};
