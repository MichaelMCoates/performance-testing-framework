import { BookmarkNode, CreateBookmarkNodeRequest, UpdateBookmarkNodeRequest } from '../../../../common/src/api/pages/shapes';
export declare const createBookmarkNodeInternal: (req: CreateBookmarkNodeRequest) => Promise<BookmarkNode>;
export declare const getBookmarkNodeInternal: (id?: string) => Promise<BookmarkNode | undefined>;
export declare const searchBookmarkNodesInternal: (query: string) => Promise<BookmarkNode[]>;
export declare const updateBookmarkNodeInternal: (req: UpdateBookmarkNodeRequest) => Promise<BookmarkNode | undefined>;
export declare const deleteBookmarkNodeInternal: (id: string) => Promise<void>;
