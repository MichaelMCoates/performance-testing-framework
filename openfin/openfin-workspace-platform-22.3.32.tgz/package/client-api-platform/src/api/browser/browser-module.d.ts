import type OpenFin from '@openfin/core';
import { BrowserWindowModule } from '../../../../client-api-platform/src/shapes';
export declare const getBrowserModule: (identity: OpenFin.Identity) => BrowserWindowModule;
