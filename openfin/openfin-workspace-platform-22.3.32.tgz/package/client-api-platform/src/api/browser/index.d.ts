import type OpenFin from '@openfin/core';
import type { BrowserWindowFactory } from '../../shapes';
export declare const getBrowserApi: (identity: OpenFin.ApplicationIdentity) => BrowserWindowFactory;
