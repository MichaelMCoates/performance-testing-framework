import type { i18next as i18n } from '../../../common/src/api/i18next';
/**
 * Returns a score for a version string depending on how specific it is. Higher == more specific.
 * E.g. 16.x.0 gives a score of 101 whereas 16.5.0 returns 111
 * @param versionString 3-fragment version string, e.g. 15.0.4, where fragments can be 'x' for generic templates
 * @returns score from 0 to 111
 */
export declare const weighVersionString: (versionString: string) => number;
/**
 * Returns array of versions from less specific to more specific
 * @param matchingVersions versions and templates relevant to the running build
 */
export declare const getVersionsSortedByPriority: (matchingVersions: string[]) => string[];
/**
 * Applies translation overrides to the i18next dictionary.
 * In case of failure logs an error without preventing further execution.
 * @param i18next i18next instance to which to apply the overrides
 */
export declare const applyTranslationOverrides: (i18next: typeof i18n) => Promise<void>;
