import { ThemeStorageController } from '../../../../client-api-platform/src/api/controllers/theme-storage-controller';
import { CustomThemes } from '../../../../client-api-platform/src/shapes';
export declare const initialiseStoragePalettes: (customThemes: CustomThemes | undefined, isWindows: boolean) => CustomThemes;
export declare const getThemeStorageController: () => ThemeStorageController;
