import { ColorSchemeOptionType, CustomPaletteSet } from '../../../../client-api-platform/src/shapes';
/**
 * Palette extensions can be used to add new variables to the palette set.
 *
 * This is particularly useful if a value uses a different palette constant depending on scheme.
 */
export declare const getPaletteExtensions: (palette: CustomPaletteSet, paletteScheme: "light" | "dark", isWindows: boolean) => {
    dockExpandedContainerBorderColor: string;
    dockExpandedContainerBorderRadius: string;
    dockExpandedContainerBackground: string;
    fillerBackgroundColor: string;
    dockCompanionContainerBackground: string;
    dockComponentContainerBackground: string;
    styledDropdownActiveBackground: string;
    contentMenuWrapperInternalDivBorderColor: string;
    contentMenuItemContainerActiveBackground: string;
    contentMenuItemContainerHoverBackground: string;
    contentMenuHeaderBorderColor: string;
    dockCompanionSeparatorBorderColor: string;
    dockComponentContainerBorderColor: string;
    companionDockButtonActiveBackground: string;
    companionDockButtonHoverBackground: string;
    'computed-scrollbar-thumb-alpha': number;
    'computed-scrollbar-track-alpha': number;
    'scrollbar-thumb-rgb': string;
    'scrollbar-track-rgb': string;
    selectedTab: string;
};
export type Palettes = {
    dark: CustomPaletteSet;
    light: CustomPaletteSet;
};
export declare class ThemeStorageController {
    private providerStorage;
    private darkPaletteVars?;
    private lightPaletteVars?;
    private workspaceStorage?;
    constructor(providerStorage: Pick<Storage, 'getItem' | 'setItem'>);
    private getVarsByScheme;
    /**
     * Set the current Storage Proxy to enable Workspace Storage properties to be populated.
     *
     * Currently, we only support same Storage Based theming for same origin scenarios like EB, where the provider
     * is in the same origin as the workspace pages.
     *
     * A workaround that can be leveraged in cross origin scenarios (which is the majority of the workspace use case) is available in this commit: 233e843cda6cd68968fd5831fb20597e0d5bb7cc
     * `git revert 233e843cda6cd68968fd5831fb20597e0d5bb7cc --no-commit`
     */
    setWorkspaceStorage: (proxy: Pick<Storage, "setItem">) => void;
    /**
     * Check if there's an explicit user preference stored in localStorage.
     * A user preference is indicated by the presence of a SelectedColorScheme key. Which is something assigned if you click on the Appearance dropdown.
     * @returns true if user has manually selected a scheme, false if using defaults
     */
    private hasUserPreference;
    /**
     * Synchronize the current palette and scheme with workspace's storage instance if
     * storage based theming is enabled. Only syncs when user has explicitly selected a scheme.
     */
    trySynchronizeWorkspaceStorage: () => void;
    /**
     * Set the current Palette to be used by workspace. This palette will be converted into
     * css vars and combined into a single stylesheet. This stylesheet is exposed in localstorage
     * to allow workspace UI elements to load the palette before their first paint.
     * @param palettes Light and Dark Palette constants
     */
    setPalettes: ({ light, dark }: Palettes, isWindows: boolean) => Promise<void>;
    /**
     * Set the current scheme of workspace. Specifically setting light or dark
     * will ignore the OS scheme, whereas 'system' will always respect it.
     *
     * This will also update the CSS vars to either support media queries in System mode or force a palette.
     * @param scheme 'light', 'dark' or 'system'.
     */
    setScheme(scheme: ColorSchemeOptionType): void;
    /**
     * Set the theme's default scheme from palette configuration
     * @param scheme The default scheme specified in the palette
     */
    setThemeDefaultScheme(scheme: ColorSchemeOptionType): void;
    /**
     * Returns the current scheme
     * @returns 'light' | 'system' | 'dark'
     */
    getScheme(): ColorSchemeOptionType;
}
