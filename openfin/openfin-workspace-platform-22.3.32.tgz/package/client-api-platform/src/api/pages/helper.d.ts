import { SnapshotExtended } from '../../../../common/src/utils/snapshot';
/**
 * Get a snapshot with pages.
 *
 * Makes sure that the layout of the page is up to date with the window's layout.
 * Skips over classic windows
 *
 * @returns a snapshot with windows that contain pages.
 */
export declare function getSnapshotWithPages(superGetSnapshot?: () => Promise<SnapshotExtended>): Promise<SnapshotExtended>;
