/**
 * Raise missed page close events.
 * This function is used to raise page close events for pages that were closed without the client
 * knowing about it.
 */
export declare const raiseMissedPageCloseEvents: () => Promise<void>;
