import { AnalyticsEventInternal } from '../../../../common/src/utils/usage-register';
import { Page } from '../../../../client-api-platform/src/shapes';
export declare const getOpenPages: () => Map<string, AnalyticsEventInternal>;
export declare const addOpenPageToCache: (pageId: Page["pageId"], event: AnalyticsEventInternal) => void;
export declare const removeOpenPageFromCache: (pageId: Page["pageId"]) => boolean;
