/**
 * Handles a name collision (if required) by appending a progressive number to the name
 *
 * @param initialName The initial name to test
 * @param existingNames The list of existing names
 * @returns a unique name
 *
 * @example
 *
 * ```ts
 * handleNameCollision('test', ['test', 'test (1)']) // returns 'test (2)'
 * ```
 */
export declare const handleNameCollision: (initialName: string, existingNames: string[]) => string;
