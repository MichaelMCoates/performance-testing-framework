import type { ApplyWorkspacePayload, CreateSavedWorkspaceRequest, GetCurrentWorkspaceOptions, RestoreLastSavedWorkspacePayload, RestoreLastSavedWorkspaceResult, Workspace } from '../../../../client-api-platform/src/shapes';
/**
 * Apply the given workspace and set it as active.
 * @param payload, the workspace to apply and the options to apply it with.
 *
 * @returns true if the workspace was applied, false if the user cancelled the switch or an error occurred.
 */
export declare function applyWorkspace(payload: ApplyWorkspacePayload): Promise<boolean>;
export declare function restoreLastSavedWorkspaceInternal(options?: RestoreLastSavedWorkspacePayload): Promise<RestoreLastSavedWorkspaceResult>;
/**
 * Set the current active workspace.
 */
export declare function setActiveWorkspace(workspace: Workspace): void;
/**
 * Get the initial workspace data structure that represents the an untitled empty workspace.
 * @returns the current active workspace.
 */
export declare function getInitialWorkspace(): Promise<Workspace>;
/**
 * Get a workspace data structure that represents the users current desktop.
 * @returns the current active workspace.
 */
export declare function getCurrentWorkspace(options?: GetCurrentWorkspaceOptions): Promise<Workspace>;
export declare function getLastSavedWorkspace(): Promise<Workspace | undefined>;
export declare const createWorkspaceInStorage: (req: CreateSavedWorkspaceRequest) => Promise<any>;
export declare const getWorkspacesInStorage: () => Promise<Workspace[]>;
export declare const getWorkspaceInStorage: (id: string) => Promise<Workspace>;
export declare const deleteWorkspaceInStorage: (id: string) => Promise<any>;
export declare const markUnsavedPagesAsSaved: () => Promise<any>;
export declare const saveWorkspace: (workspace: Workspace) => Promise<any>;
/**
 * Checks if a given workspace name is unique
 * If not, add a progressive number to it
 * @param initialName The initial name to test
 * @returns string: a unique workspace name
 */
export declare function getUniqueWorkspaceTitle(initialName?: string): Promise<string>;
