import { Workspace } from '../../../../client-api-platform/src/shapes';
export declare function getWorkspace(id: string): Promise<Workspace | undefined>;
export declare function getWorkspaceList(filter?: string): Promise<Workspace[]>;
export declare function createWorkspace({ workspace }: {
    workspace: Workspace;
}): Promise<void>;
export declare function deleteWorkspace(id: string): Promise<void>;
export declare function updateWorkspace({ workspaceId, workspace }: {
    workspaceId: string;
    workspace: Workspace;
}): Promise<void>;
