import type OpenFin from '@openfin/core';
import { WorkspacePlatformModule } from '../shapes';
/**
 * Synchronously returns a Platform object that represents an existing platform.
 *
 * ```ts
 * import * as WorkspacePlatform from '@openfin/workspace-platform';
 *
 * // declare platform identity
 * const myPlatformIdentity: OpenFin.ApplicationIdentity = {
 *      uuid: 'testPlatform',
 *      name: 'Test Platform'
 * };
 *
 * // get the platform representing myPlatformIdentity
 * const platform = WorkspacePlatform.wrapSync(myPlatformIdentity);
 *
 * // do something with platform. e.g. create a window
 * platform.createWindow({
 *      layout: {
 *          content: [
 *              {
 *                  type: 'component',
 *                  componentName: 'Example View',
 *                  componentState: {
 *                      name: 'example_view_1'
 *                      url: 'https://developer.openfin.co/docs/javascript/stable/index.html'
 *                  }
 *              }
 *          ]
 *      }
 * });
 * ```
 */
export declare const wrapSync: (identity: OpenFin.ApplicationIdentity) => WorkspacePlatformModule;
/**
 * Synchronously returns a Platform object that represents the current platform.
 *
 * ```ts
 * import * as WorkspacePlatform from '@openfin/workspace-platform';
 * // get current Workspace Platform
 * const workspacePlatform = WorkspacePlatform.getCurrentSync();
 * // do something with workspacePlatform. e.g. get snapshot of browser window with pages
 * const snapshot = await workspacePlatform.getSnapshot();
 * ```
 */
export declare const getCurrentSync: () => WorkspacePlatformModule;
