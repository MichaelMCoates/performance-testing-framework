import type OpenFin from '@openfin/core';
import type { WorkspacePlatformStorage } from '../shapes';
export declare const getStorageApi: (identity: OpenFin.ApplicationIdentity) => WorkspacePlatformStorage;
