import { DockProviderConfigWithIdentity } from '../../../../client-api/src/shapes';
export declare function getDockProviderConfig(providerId: string): Promise<DockProviderConfigWithIdentity | undefined>;
export declare function saveDockProviderConfig(config: DockProviderConfigWithIdentity): Promise<void>;
