export declare const browserWindowPerformanceMarkStart: () => string;
export declare const browserWindowPerformanceMarkAPIReturn: (performanceMarkTitle: string) => void;
export declare const setupBrowserWindowShownPerformanceMark: (performanceMarkTitle: string) => void;
export declare const contextMenuPerformanceMarkStart: () => string;
export declare const contextMenuPerformanceMarkEnd: (performanceMarkTitle: string) => void;
export declare const contextMenuPerformanceMarkAPIReturn: (performanceMarkTitle: string) => void;
export declare const setupContextMenuPerformanceMark: (performanceMarkTitle: string) => void;
