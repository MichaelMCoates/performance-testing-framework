import { LaunchBookmarkPayload } from '../../../client-api-platform/src/shapes';
export declare const launchBookmark: (payload: LaunchBookmarkPayload) => Promise<void>;
