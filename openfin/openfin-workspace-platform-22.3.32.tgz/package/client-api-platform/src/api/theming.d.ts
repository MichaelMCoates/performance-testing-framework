import type OpenFin from '@openfin/core';
import { ColorSchemeOptionType, ThemeApi } from '../../../client-api-platform/src/shapes';
export declare const getThemingApi: (identity: OpenFin.ApplicationIdentity) => ThemeApi;
export declare const setSelectedScheme: (schemeType: ColorSchemeOptionType) => Promise<void>;
export declare const getSelectedScheme: () => ColorSchemeOptionType | null | undefined;
