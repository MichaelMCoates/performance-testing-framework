import { Locale } from '../../../client-api-platform/src/shapes';
export declare function getLanguage(): Locale;
export declare const dispatchLanguageToBrowserWindows: (language: Locale) => Promise<void[]>;
export declare const setLanguage: (locale: Locale) => Promise<void>;
export declare function getLanguageResourcesInternal(): {
    currentLanguage: "en-US" | "ja-JP" | "zh-CN" | "ko-KR" | "ru-RU" | "de-DE" | "zh-Hant";
    resources: import("i18next/typescript/options").Resource;
};
/**
 * initLanguage()
 * @param language - optional - ISO language code
 */
export default function initLanguage(language?: Locale): Promise<void>;
