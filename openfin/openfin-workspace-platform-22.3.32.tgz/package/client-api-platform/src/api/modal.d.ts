import type OpenFin from '@openfin/core';
import { AboutPageConfig, SendUpdateVersionModalResponsePayload } from '../../../client-api-platform/src/shapes';
export declare const enterpriseModalChannelClient: () => Promise<OpenFin.ChannelClient>;
export declare function sendUpdateVersionModalResponse(payload: SendUpdateVersionModalResponsePayload): Promise<void>;
export declare const showAboutPagePopup: (payload: AboutPageConfig) => Promise<OpenFin.Window>;
export declare const showDesktopSignalsModal: (winIdentity: OpenFin.Identity) => Promise<OpenFin.Window>;
