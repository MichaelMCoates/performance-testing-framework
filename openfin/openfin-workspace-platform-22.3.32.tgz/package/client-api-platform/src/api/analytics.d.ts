import { AnalyticsEventInternal } from '../../../common/src/utils/usage-register';
import { AnalyticsConfig, WorkspacePlatformProvider } from '../../../client-api-platform/src/shapes';
declare global {
    interface Window {
        TextEncoder: {
            new (): {
                encode(string: string): Uint8Array;
            };
        };
    }
}
export declare function analyticsInternal(this: WorkspacePlatformProvider, events: AnalyticsEventInternal[]): Promise<void>;
export declare const initPlatformAnalytics: (config?: AnalyticsConfig) => Promise<void>;
