import type OpenFin from '@openfin/core';
import { EnterpriseMenuType } from '../../../../common/src/utils/popup-window';
import { InternalOpenGlobalContextMenuRequest, InternalOpenPageTabContextMenuRequest, OpenGlobalContextMenuPayload, OpenPageTabContextMenuPayload, OpenSaveButtonContextMenuPayload, OpenSaveButtonContextMenuRequest, OpenViewTabContextMenuPayload, OpenViewTabContextMenuRequest, WorkspacePlatformProvider } from '../../../../client-api-platform/src/shapes';
/**
 * Enum representing the possible anchor behaviors for positioning context menus.
 * These are relative to an element/cursor position (as opposed to a corner of the context menu window).
 *
 * e.g. AnchorBehavior.BottomRight implies a context menu will expand aligned with the bottom and right edge of an element.
 *
 * @enum {number}
 */
export declare enum AnchorBehavior {
    TopLeft = 0,
    TopRight = 1,
    BottomLeft = 2,
    BottomRight = 3,
    Center = 4
}
type ContextMenuPayload = OpenGlobalContextMenuPayload | OpenViewTabContextMenuPayload | OpenPageTabContextMenuPayload | OpenSaveButtonContextMenuPayload;
export declare const openCommonContextMenu: (payload: ContextMenuPayload, _callerIdentity: OpenFin.Identity, type?: EnterpriseMenuType, anchorBehavior?: AnchorBehavior) => Promise<void>;
export declare function openGlobalContextMenuInternal(this: WorkspacePlatformProvider, payload: InternalOpenGlobalContextMenuRequest & {
    identity: OpenFin.Identity;
}, callerIdentity: OpenFin.Identity): Promise<void>;
export declare function openViewTabContextMenuInternal(this: WorkspacePlatformProvider, payload: OpenViewTabContextMenuRequest & {
    identity: OpenFin.Identity;
}, callerIdentity: OpenFin.Identity): Promise<void>;
export declare function openPageTabContextMenuInternal(this: WorkspacePlatformProvider, payload: InternalOpenPageTabContextMenuRequest & {
    identity: OpenFin.Identity;
}, callerIdentity: OpenFin.Identity): Promise<void>;
export declare function openSaveButtonContextMenuInternal(this: WorkspacePlatformProvider, payload: OpenSaveButtonContextMenuRequest & {
    identity: OpenFin.Identity;
}, callerIdentity: OpenFin.Identity): Promise<void>;
export {};
