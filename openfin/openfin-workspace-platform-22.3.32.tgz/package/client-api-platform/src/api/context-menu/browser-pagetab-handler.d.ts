import { OpenPageTabContextMenuPayload } from '../../../../client-api-platform/src/index';
import { PageTabContextMenuItemData } from '../../../../client-api-platform/src/shapes';
export declare const pageTabContextMenuItemHandler: (data: PageTabContextMenuItemData, payload: OpenPageTabContextMenuPayload, pageTabRect?: DOMRect) => Promise<void>;
