import { GlobalContextMenuItemData, OpenGlobalContextMenuPayload } from '../../shapes';
declare const handler: (data: GlobalContextMenuItemData, payload: OpenGlobalContextMenuPayload) => Promise<void>;
export default handler;
