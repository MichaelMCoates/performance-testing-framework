import type OpenFin from '@openfin/core';
import { OpenViewTabContextMenuPayload, ViewTabMenuData } from '../../../../client-api-platform/src/index';
export declare const addToChannel: (winIdentity: OpenFin.Identity, newChannelId: string, selectedViews: OpenFin.Identity[]) => Promise<void>;
export declare const removeFromChannel: (winIdentity: OpenFin.Identity, selectedViews: OpenFin.Identity[]) => Promise<void>;
declare const handler: (data: ViewTabMenuData, payload: OpenViewTabContextMenuPayload) => Promise<void>;
export default handler;
