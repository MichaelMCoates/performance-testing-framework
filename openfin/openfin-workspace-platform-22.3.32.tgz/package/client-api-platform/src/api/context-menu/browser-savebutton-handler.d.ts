import { OpenSaveButtonContextMenuPayload } from '../../../../client-api-platform/src/index';
import { SaveButtonContextMenuItemData } from '../../../../client-api-platform/src/shapes';
export declare const saveButtonContextMenuItemHandler: (data: SaveButtonContextMenuItemData, payload: OpenSaveButtonContextMenuPayload) => Promise<void>;
