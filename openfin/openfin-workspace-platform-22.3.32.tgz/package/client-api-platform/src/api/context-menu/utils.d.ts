import type OpenFin from '@openfin/core';
import { PositioningType } from '../../../../common/src/utils/positioning';
import { WorkspaceContextMenuItemData } from '../../../../client-api-platform/src/shapes';
export declare const saveWorkspaceHandlerWithInjectables: ({ showModal, afterSuccessSave }: {
    showModal?: () => Promise<void>;
    afterSuccessSave?: () => Promise<void>;
}) => Promise<void>;
export declare const saveWorkspaceHandler: (identity: OpenFin.Identity) => Promise<void>;
export declare const saveWorkspaceAsHandler: (identity: OpenFin.Identity) => void;
/**
 * @param identity Identity of browser window to create a new page on.
 */
export declare const createNewPageHandler: (identity: OpenFin.Identity) => Promise<void>;
/**
 * @param identity Identity of browser window to execute save on.
 * @param pageId Id of a page to save. If omitted, active page is saved.
 */
export declare const savePageHandler: (identity: OpenFin.Identity, pageId?: string) => Promise<void>;
/**
 * @param identity Identity of browser window to execute save on.
 * @param pageId Id of a page to save. If omitted, active page is saved.
 */
export declare const savePageAsHandler: (identity: OpenFin.Identity, pageId?: string) => Promise<void>;
export declare const switchWorkspaceHandler: (winIdentity: OpenFin.Identity, workspaceItemData: WorkspaceContextMenuItemData) => Promise<void>;
export declare const deleteWorkspaceHandlerWithPayload: ({ workspaceItemData, winIdentity, positioning }: {
    workspaceItemData: WorkspaceContextMenuItemData;
    winIdentity?: OpenFin.Identity;
    positioning?: PositioningType;
}) => Promise<void>;
export declare const deleteWorkspaceHandler: (winIdentity: OpenFin.Identity, workspaceItemData: WorkspaceContextMenuItemData) => Promise<void>;
export declare const downloadsHandler: (identity: OpenFin.Identity) => Promise<void>;
/**
 * Reload activ view
 * Enterprise Browser
 * @param identity
 * @param pageId
 */
export declare const reloadPageHandler: (identity: OpenFin.Identity, pageId?: string) => Promise<void>;
/**
 * Close page, without Save Modal
 * Enterprise Browser
 * @param identity
 * @param pageId
 */
export declare const closePageHandler: (identity: OpenFin.Identity, pageId?: string) => Promise<void>;
/**
 * Close other pages
 * Enterprise Browser
 * @param identity
 * @param pageId
 */
export declare const closeOtherPagesHandler: (identity: OpenFin.Identity, pageId?: string) => Promise<void>;
/**
 * @param viewIdentities Array of views to execute print on.
 */
export declare const printSelectedViews: (viewIdentities: OpenFin.Identity[]) => Promise<void>;
export declare const deletePageHandler: (identity: OpenFin.Identity, pageId?: string) => Promise<void>;
