export declare const listenForStoreClose: () => void;
