# Workspace Platform API

The Workspace Platform Client APIs allow integrators to create their own Workspace platforms.

## Installation

Run `npm i -E @openfin/workspace-platform`.

## Workspace Platform API documentation

-   [Overview](https://developers.openfin.co/of-docs/docs/workspace-sdk)
-   [API Reference](https://workspace.openfin.co/workspace/docs/platform/latest/index.html)
-   [Example projects using Workspace Platform](https://github.com/built-on-openfin/workspace-starter)

## Code examples

### Initialize a Workspace Platform

```typescript
import * as WorkspacePlatform from '@openfin/workspace-platform';

const customThemes: WorkspacePlatform.CustomThemes = [
    {
        label: "OpenFin's Custom Theme",
        palette: {
            brandPrimary: '#F51F63', // required
            brandSecondary: '#1FF58A', // required
            backgroundPrimary: '#F8E71C', // required - hex, rgb/rgba, hsl/hsla only - no string colors: ‘red’
            background2: '#7D808A' // any of the optional colors
        }
    }
];

const overrideCallback: WorkspacePlatform.WorkspacePlatformOverrideCallback = async (WorkspacePlatformProvider) => {
    class Override extends WorkspacePlatformProvider {
        async quit(payload, callerIdentity) {
            return super.quit(payload, callerIdentity);
        }
    }
    return new Override();
};

await WorkspacePlatform.init({
    browser: {
        title: 'My Browser'
    },
    overrideCallback,
    theme: customThemes
});
```
