import type OpenFin from '@openfin/core';
interface LandingPageUrls {
    newPageUrl: string | false;
    newTabUrl: string | false;
}
export declare const getLandingPageUrls: (winIdentity?: OpenFin.Identity) => Promise<LandingPageUrls>;
export declare const checkHasNewTabUrl: () => Promise<boolean>;
export declare const getNewLandingTabViewOptions: (target: OpenFin.Identity) => Promise<OpenFin.PlatformViewCreationOptions>;
/**
 * Makes a new landing page.
 *
 * If winIdentity is specified, it uses the newPageUrl defined by the browser window options.
 * Otherwise, if the platform is Enterprise, it will use the landing page URL.
 */
export declare const makeNewLandingPage: (winIdentity?: OpenFin.Identity) => Promise<import("@client-platform/shapes").PageWithUpdatableRuntimeAttribs>;
export {};
