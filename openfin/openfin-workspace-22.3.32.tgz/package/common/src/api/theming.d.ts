import type { DefaultTheme } from 'styled-components';
import type OpenFin from '@openfin/core';
import { type ColorSchemeType, type ThemeSet } from '@openfin/ui-library';
import { Palette } from '@openfin/ui-library/dist/theme';
import { ColorSchemeOptionType } from '../../../client-api-platform/src/shapes';
export type WorkspaceComponentSetSelectedSchemePayload = {
    newScheme: ColorSchemeOptionType;
    identity: OpenFin.Identity;
};
export type ComputedThemes = ComputedTheme[];
export interface ComputedTheme {
    label: string;
    logoUrl?: string;
    theme: WorkspaceThemeSet;
    defaultScheme?: ColorSchemeOptionType;
}
export interface WorkspaceThemeSet extends ThemeSet {
    light: ThemeExtension;
    dark: ThemeExtension;
}
interface EnterpriseBrandIcons {
    /**
     * @internal
     * Internal brand options for Enterprise Browser
     */
    symbol: string;
}
export interface ThemeExtension extends DefaultTheme {
    notificationIndicatorColors?: Record<string, Omit<NotificationIndicatorColorsSet, 'foreground'> & {
        foreground: string;
    }>;
    /**
     * @internal
     * Internal brand options for Enterprise Browser
     */
    brand: {
        icons: EnterpriseBrandIcons;
    };
}
export interface NotificationIndicatorColorsSet {
    background: string;
    foreground?: string;
}
export interface NotificationIndicatorColorsSetDarkScheme {
    dark: NotificationIndicatorColorsSet;
    light?: NotificationIndicatorColorsSet;
}
export interface NotificationIndicatorColorsSetLightScheme {
    dark?: NotificationIndicatorColorsSet;
    light: NotificationIndicatorColorsSet;
}
export type NotificationIndicatorColorsWithScheme = Record<string, NotificationIndicatorColorsSetDarkScheme | NotificationIndicatorColorsSetLightScheme>;
export interface BaseThemeOptions {
    label: string;
    logoUrl?: string;
    /**
     * @internal
     * Internal brand options for Enterprise Browser
     */
    brand?: {
        icons?: {
            dark?: EnterpriseBrandIcons;
            light?: EnterpriseBrandIcons;
        };
    };
}
export type CustomThemeOptions = BaseThemeOptions & {
    palette: CustomPaletteSet;
    /**
     * NOTE: Only used in Notifications
     *
     * Used for providing color overrides of notification indicators or defining custom colors that clients could target.
     *
     * @example
     * ```ts
     * const themeOptions = {
     *   default: 'light',
     *   palettes: {...}
     *   notificationIndicatorColors: {
     *     red: {
     *       background: '#FF0000',
     *       foreground: '#FFFFDD'
     *     },
     *     customred: {
     *       // If `foreground` is not defined it will default to `#FFFFFF`
     *       background: '#FF0011'
     *     }
     *   }
     * };
     * ```
     */
    notificationIndicatorColors?: Record<string, NotificationIndicatorColorsSet>;
};
export type CustomThemeOptionsWithScheme = BaseThemeOptions & {
    /**
     * The default color scheme for this theme.
     *
     * This will be used as a fallback if the user has not yet selected a color scheme, or there was an error fetching the user's color scheme.
     *
     * @default 'dark'
     */
    default?: `${Exclude<ColorSchemeOptionType, 'system'>}`;
    /**
     * The palette for this theme.
     *
     * When a user selects a color scheme, the palette will be updated to match the selected scheme.
     *
     * If `system` is selected, the palette will be updated to match the user's system color scheme.
     */
    palettes: {
        light: CustomPaletteSet;
        dark: CustomPaletteSet;
    };
    /**
     * NOTE: Only used in Notifications
     *
     * Used for providing color overrides of notification indicators or defining custom colors that clients could target.
     *
     * @example
     * ```ts
     * const themeOptions = {
     *   default: 'light',
     *   palettes: {...}
     *   notificationIndicatorColors: {
     *     red: {
     *       dark: {
     *         background: '#FF0000',
     *         foreground: '#FFFFDD'
     *       },
     *       light: {
     *         // If `foreground` is not defined it will default to `#FFFFFF`
     *         background: '#FF1100',
     *       }
     *     },
     *     customred: {
     *       // If one of the schemes is not defined (in this case `light`) the values from the defined one will be copied to the other
     *       dark: {
     *         background: '#FF0011',
     *         foreground: '#FFDDDD'
     *       }
     *     }
     *   }
     * };
     * ```
     */
    notificationIndicatorColors?: NotificationIndicatorColorsWithScheme;
};
export type CustomThemes = (CustomThemeOptions | CustomThemeOptionsWithScheme)[];
export interface PreloadedThemeData {
    themes: CustomThemes;
    selectedScheme: ColorSchemeOptionType;
}
export interface DefaultPaletteSet {
    brandPrimary: string;
    brandSecondary: string;
    backgroundPrimary: string;
}
export interface BackgroundLayers {
    background1: string;
    background2: string;
    background3: string;
    background4: string;
    background5: string;
    background6: string;
}
export interface PaletteLayersBackgrounds {
    light: Partial<BackgroundLayers>;
    dark: Partial<BackgroundLayers>;
}
export interface CustomPaletteSet extends DefaultPaletteSet {
    brandPrimaryActive?: string;
    brandPrimaryHover?: string;
    brandPrimaryFocused?: string;
    brandPrimaryText?: string;
    brandSecondaryActive?: string;
    brandSecondaryHover?: string;
    brandSecondaryFocused?: string;
    brandSecondaryText?: string;
    functional1?: string;
    functional2?: string;
    functional3?: string;
    functional4?: string;
    functional5?: string;
    functional6?: string;
    functional7?: string;
    functional8?: string;
    functional9?: string;
    functional10?: string;
    statusSuccess?: string;
    statusWarning?: string;
    statusCritical?: string;
    statusActive?: string;
    inputBackground?: string;
    inputColor?: string;
    inputPlaceholder?: string;
    inputDisabled?: string;
    inputFocused?: string;
    inputBorder?: string;
    textDefault?: string;
    textHelp?: string;
    textInactive?: string;
    background1?: string;
    background2?: string;
    background3?: string;
    background4?: string;
    background5?: string;
    background6?: string;
    contentBackground1?: string;
    contentBackground2?: string;
    contentBackground3?: string;
    contentBackground4?: string;
    contentBackground5?: string;
    linkDefault?: string;
    linkHover?: string;
    borderNeutral?: string;
}
export declare const OpenFinLightTheme: {
    background1: "#FFFFFF";
    background2: "#FAFBFE";
    background3: "#F3F5F8";
    background4: "#ECEEF1";
    background5: "#DDDFE4";
    background6: "#C9CBD2";
    brandSecondary: "#DDDFE4";
    brandSecondaryActive: "#D7DADF";
    brandSecondaryHover: "#EBECEF";
    brandSecondaryFocused: "#1E1F23";
    brandSecondaryText: "#1E1F23";
    inputBackground: "#ECEEF1";
    inputColor: "#1E1F23";
    inputPlaceholder: "#383A40";
    inputDisabled: "#7D808A";
    inputFocused: "#C9CBD2";
    inputBorder: "#7D808A";
    textDefault: "#1E1F23";
    textHelp: "#2F3136";
    textInactive: "#7D808A";
    brandPrimary: string;
    brandPrimaryActive: string;
    brandPrimaryHover: string;
    brandPrimaryFocused: "#FFFFFF";
    brandPrimaryText: "#FFFFFF";
    statusSuccess: "#207735";
    statusWarning: "#F48F00";
    statusCritical: "#F31818";
    statusActive: "#0A76D3";
    contentBackground1: string;
    contentBackground2: string;
    contentBackground3: string;
    contentBackground4: string;
    contentBackground5: string;
    borderNeutral: "#C0C1C2";
};
export declare const OpenFinDarkTheme: {
    background1: "#111214";
    background2: "#1E1F23";
    background3: "#24262B";
    background4: "#2F3136";
    background5: "#383A40";
    background6: "#53565F";
    brandSecondary: "#383A40";
    brandSecondaryActive: "#33353B";
    brandSecondaryHover: "#44464E";
    brandSecondaryFocused: "#FFFFFF";
    brandSecondaryText: "#FFFFFF";
    inputBackground: "#53565F";
    inputColor: "#FFFFFF";
    inputPlaceholder: "#C9CBD2";
    inputDisabled: "#7D808A";
    inputFocused: "#C9CBD2";
    inputBorder: "#7D808A";
    textDefault: "#FFFFFF";
    textHelp: "#C9CBD2";
    textInactive: "#7D808A";
    brandPrimary: string;
    brandPrimaryActive: string;
    brandPrimaryHover: string;
    brandPrimaryFocused: "#FFFFFF";
    brandPrimaryText: "#FFFFFF";
    statusSuccess: "#207735";
    statusWarning: "#F48F00";
    statusCritical: "#F31818";
    statusActive: "#0A76D3";
    contentBackground1: string;
    contentBackground2: string;
    contentBackground3: string;
    contentBackground4: string;
    contentBackground5: string;
    borderNeutral: "#C0C1C2";
};
export declare const DefaultOpenFinTheme: CustomThemes;
export declare const getComputedPaletteSets: (customTheme: CustomThemeOptions | CustomThemeOptionsWithScheme) => WorkspaceThemeSet;
/**
 * Transforms input {@link CustomThemes} to {@link ComputedThemes} used by Workspace Platform / Notifications Platform.
 *
 * @param customThemes array of themes to transform
 * @param storedScheme sets the default scheme if provided
 * @returns array of {@link ComputedThemes | computed themes}
 */
export declare const computeThemes: (customThemes: CustomThemes, storedScheme?: ColorSchemeOptionType) => ComputedThemes;
export declare const getComputedPlatformTheme: (platformIdentity: OpenFin.Identity) => Promise<ComputedTheme>;
export declare const setSelectedScheme: (ctx: ColorSchemeOptionType) => Promise<void>;
export declare const getComputedScheme: (identity?: OpenFin.Identity) => Promise<Exclude<ColorSchemeType, "system">>;
export declare const getComputedBackgroundColor: (paletteKey: keyof typeof Palette, defaultColor?: string) => Promise<string>;
export {};
