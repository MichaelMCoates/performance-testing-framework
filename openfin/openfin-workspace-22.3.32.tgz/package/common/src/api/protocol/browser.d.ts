import type OpenFin from '@openfin/core';
export declare const getWindowChannelId: (identity: OpenFin.Identity, prefix?: string) => string;
export interface ChannelClient extends OpenFin.ChannelClient {
    dispatch: (action: (typeof BrowserChannelAction)[keyof BrowserChannelAction], payload?: any) => Promise<any>;
}
export declare const getNamedChannelClient: (channelName: string) => Promise<ChannelClient>;
export declare const getChannelClient: (identity: OpenFin.Identity, prefix?: string) => Promise<ChannelClient>;
/**
 * If the browser window is reloaded too quickly, runtime will
 * respond that the channel provider has already been created.
 * Hence, we retry a couple of times to make sure this does not occur.
 * (Should only happen in local development)
 */
export declare const createChannel: (identity?: OpenFin.Identity, prefix?: string) => Promise<OpenFin.ChannelProvider>;
export declare const getBrowserChannelClient: () => Promise<OpenFin.ChannelProvider>;
export declare const getViewThemeChannelClient: () => Promise<OpenFin.ChannelProvider>;
export interface AddToChannelRequest {
    newChannelId: string;
    selectedViews: OpenFin.Identity[];
}
/**
 * These actions are used to handle functionality activated by user in the UI (e.g. context menu)
 * and hence show dialogs, indicators etc.
 * Not to be confused with attached pages actions, which are for API use.
 */
declare enum GeneralBrowserChannelActions {
    CloseBrowserWindow = "close-browser-window",
    QuitPlatform = "quit-platform",
    ClosePage = "close-page",
    AddToChannel = "add-to-channel",
    RemoveFromChannel = "remove-from-channel",
    OpenSaveModalInternal = "open-save-modal-internal",
    DuplicatePage = "duplicate-page",
    SetSelectedScheme = "set-selected-scheme",
    ShowBrowserIndicator = "show-browser-indicator",
    SetSelectedLanguage = "set-selected-language",
    RefreshBookmarksInternal = "refresh-bookmarks",// Enterprise
    GetLayoutsWithSelectedViewsInternal = "get-layouts-with-selected-views",// Enterprise
    FocusAndExpandSearchInternal = "focus-and-expand-search"
}
/**
 * All of the remote procedures that can be called in the
 * platform window's address space regarding attached pages.
 */
export declare enum PageChannelAction {
    GetPages = "get-pages",
    GetActivePageForWindow = "get-active-page-for-window",
    AttachPagesToWindow = "attach-pages-to-window",
    DetachPagesFromWindow = "detach-pages-from-window",
    SetActivePageForWindow = "set-active-page-for-window",
    RenamePage = "rename-page",
    ReorderPagesForWindow = "reorder-pages-for-window",
    UpdatePageForWindow = "update-page-for-window",
    UpdatePagesWindowOptions = "update-pages-window-options",
    IsDetachingPages = "is-detaching-pages",
    IsActivePageChanging = "is-active-page-changing"
}
/**
 * @internal
 */
export declare enum EnterpriseAppDirectoryChannelAction {
    GetApps = "get-apps",
    GetCuratedContent = "get-curated-content",
    GetRecentlyVisited = "get-recently-visited",
    GetSearchProviders = "get-search-providers"
}
/**
 * @internal
 */
export declare enum EnterpriseBookmarkChannelAction {
    CreateBookmarkNode = "create-bookmark-node",// Enterprise
    GetBookmarkNode = "get-bookmark-node",// Enterprise
    SearchBookmarkNodes = "search-bookmark-nodes",// Enterprise
    UpdateBookmarkNode = "update-bookmark-node",// Enterprise
    DeleteBookmarkNode = "delete-bookmark-node"
}
export declare enum CompanionDockChannelAction {
    UpdateFavoriteEntries = "update-favorite-entries",// Enterprise
    UpdateContentMenu = "update-content-menu",// Enterprise
    NavigateContentMenu = "navigate-content-menu"
}
/**
 * @internal
 */
export declare enum EnterpriseRequestModalChannelAction {
    SendUpdateVersionModalResponse = "send-update-version-modal-response"
}
export declare const BrowserChannelAction: {
    UpdateFavoriteEntries: CompanionDockChannelAction.UpdateFavoriteEntries;
    UpdateContentMenu: CompanionDockChannelAction.UpdateContentMenu;
    NavigateContentMenu: CompanionDockChannelAction.NavigateContentMenu;
    GetPages: PageChannelAction.GetPages;
    GetActivePageForWindow: PageChannelAction.GetActivePageForWindow;
    AttachPagesToWindow: PageChannelAction.AttachPagesToWindow;
    DetachPagesFromWindow: PageChannelAction.DetachPagesFromWindow;
    SetActivePageForWindow: PageChannelAction.SetActivePageForWindow;
    RenamePage: PageChannelAction.RenamePage;
    ReorderPagesForWindow: PageChannelAction.ReorderPagesForWindow;
    UpdatePageForWindow: PageChannelAction.UpdatePageForWindow;
    UpdatePagesWindowOptions: PageChannelAction.UpdatePagesWindowOptions;
    IsDetachingPages: PageChannelAction.IsDetachingPages;
    IsActivePageChanging: PageChannelAction.IsActivePageChanging;
    CloseBrowserWindow: GeneralBrowserChannelActions.CloseBrowserWindow;
    QuitPlatform: GeneralBrowserChannelActions.QuitPlatform;
    ClosePage: GeneralBrowserChannelActions.ClosePage;
    AddToChannel: GeneralBrowserChannelActions.AddToChannel;
    RemoveFromChannel: GeneralBrowserChannelActions.RemoveFromChannel;
    OpenSaveModalInternal: GeneralBrowserChannelActions.OpenSaveModalInternal;
    DuplicatePage: GeneralBrowserChannelActions.DuplicatePage;
    SetSelectedScheme: GeneralBrowserChannelActions.SetSelectedScheme;
    ShowBrowserIndicator: GeneralBrowserChannelActions.ShowBrowserIndicator;
    SetSelectedLanguage: GeneralBrowserChannelActions.SetSelectedLanguage;
    RefreshBookmarksInternal: GeneralBrowserChannelActions.RefreshBookmarksInternal;
    GetLayoutsWithSelectedViewsInternal: GeneralBrowserChannelActions.GetLayoutsWithSelectedViewsInternal;
    FocusAndExpandSearchInternal: GeneralBrowserChannelActions.FocusAndExpandSearchInternal;
};
export type BrowserChannelAction = typeof BrowserChannelAction;
export {};
