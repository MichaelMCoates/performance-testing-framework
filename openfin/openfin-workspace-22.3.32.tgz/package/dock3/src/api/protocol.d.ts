import type { OpenFin } from '@openfin/core';
import { BaseCustomDropdownItem } from '../../../client-api/src/shapes';
import { BookmarkDockEntryPayload, DockEntry, LaunchDockEntryPayload } from '../../../client-api-platform/src/shapes';
import { Dock3Config, DockCompanionButton } from '../../../dock3/src/shapes';
type ChannelActionMap = {
    [action: string]: (...args: any[]) => any;
};
type TypedChannelClient<ProviderActions extends ChannelActionMap, ClientActions extends ChannelActionMap> = Omit<OpenFin.ChannelClient, 'dispatch' | 'register'> & {
    dispatch: <T extends keyof ProviderActions>(action: T, payload: Parameters<ProviderActions[T]>[0]) => Promise<Awaited<ReturnType<ProviderActions[T]>>>;
    register: <T extends keyof ClientActions>(action: T, handler: (payload: Parameters<ClientActions[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Promise<Awaited<ReturnType<ClientActions[T]>>>) => boolean;
};
type TypedChannelProvider<ProviderActions extends ChannelActionMap, ClientActions extends ChannelActionMap> = Omit<OpenFin.ChannelProvider, 'dispatch' | 'register'> & {
    dispatch: <T extends keyof ClientActions>(to: OpenFin.ClientIdentity, action: T, payload: Parameters<ClientActions[T]>[0]) => Promise<Awaited<ReturnType<ClientActions[T]>>>;
    register: <T extends keyof ProviderActions>(action: T, handler: (payload: Parameters<ProviderActions[T]>[0], id: OpenFin.ProviderIdentity | OpenFin.ClientIdentity) => Promise<Awaited<ReturnType<ProviderActions[T]>>>) => boolean;
};
/**
 * @internal
 */
export type Dock3ChannelProviderChannelActions = {
    'launch-entry': (payload: LaunchDockEntryPayload) => void;
    'ready': () => void;
    'save-config': (payload: {
        config: Dock3Config;
    }) => Promise<void>;
    'bookmark-content-menu-entry': (payload: BookmarkDockEntryPayload) => Promise<void>;
};
/**
 * @internal
 */
export type Dock3ChannelClientChannelActions = {
    'handle-dock-config-updated': (payload: Dock3Config) => void;
};
/**
 * @internal
 */
export type Dock3ChannelProvider = TypedChannelProvider<Dock3ChannelProviderChannelActions, Dock3ChannelClientChannelActions>;
/**
 * @internal
 */
export type Dock3ChannelClient = TypedChannelClient<Dock3ChannelProviderChannelActions, Dock3ChannelClientChannelActions>;
/**
 * These are channel actions registered by the platform.
 *
 * @internal
 */
export type EnterpriseDockChannelProviderChannelActions = Dock3ChannelProviderChannelActions & {
    'set-dock-favorites-order': (newFavorites: DockEntry[]) => void;
    'set-default-dock-buttons-order': (newFavorites: DockCompanionButton[]) => void;
    'get-dock-workspaces-context-menu': () => BaseCustomDropdownItem[];
    'handle-dock-workspaces-menu-response': (payload: any) => void;
    'remove-favorite-entry': (entry: DockEntry) => void;
    'add-favorite-entry': (entry: DockEntry) => void;
};
/**
 * These are channel actions registered by the client (enterprise dock)
 * @internal
 */
export type EnterpriseDockChannelClientChannelActions = Dock3ChannelClientChannelActions & {
    'update-favorite-entries': () => void;
    'update-content-menu': () => void;
    'navigate-content-menu': () => void;
};
/**
 * Used by Enterprise Dock for communication with the platform.
 * @internal
 */
export type EnterpriseDockChannelClient = TypedChannelClient<EnterpriseDockChannelProviderChannelActions, EnterpriseDockChannelClientChannelActions>;
/**
 * Used by the platform for communication with Enterprise Dock.
 * @internal
 */
export type EnterpriseDockChannelProvider = TypedChannelProvider<EnterpriseDockChannelProviderChannelActions, EnterpriseDockChannelClientChannelActions>;
export {};
