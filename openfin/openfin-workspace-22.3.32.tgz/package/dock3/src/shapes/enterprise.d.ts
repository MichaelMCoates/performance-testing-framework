import { Point } from '../../../common/src/utils/window';
import { Dock3Button, Dock3Config } from './shapes';
export type { EnterpriseDockChannelClient, EnterpriseDockChannelProvider } from '../api/protocol';
/**
 * @internal
 */
export type DockCompanionButton = Exclude<Dock3Button, 'store'> | 'bookmarks' | 'searchShortcut';
/**
 * @internal
 */
export type CompanionDockConfig = Omit<Dock3Config, 'defaultDockButtons'> & {
    /**
     * Companion dock window position
     */
    dockPosition?: Point;
    /**
     * Base URL for the companion dock
     */
    baseUrl?: string;
    defaultDockButtons?: DockCompanionButton[];
    windowType?: 'enterprise';
};
