import type OpenFin from '@openfin/core';
import type { AttachedPage, CopyPagePayload, DetachPagesFromWindowPayload, ExtendedAttachPagesToWindowPayload, HandlePagesAndWindowClosePayload, HandlePagesAndWindowCloseResult, HandleSaveModalOnPageClosePayload, ReorderPagesForWindowPayload, SaveModalOnPageCloseResult, SetActivePageForWindowPayload, ShouldPageClosePayload, ShouldPageCloseResult, UpdatePageForWindowPayload } from '../../../../common/src/api/pages/shapes';
import type { CreateSavedPageRequest, HandlePageChangesPayload, ModifiedPageState, Page, UpdateSavedPageRequest, WorkspacePlatformProvider } from '../../../../client-api-platform/src/shapes';
/**
 * Get all open pages in which are attached to a window.
 * @returns the list of attached pages.
 */
export declare const getAllAttachedPages: () => Promise<AttachedPage[]>;
export declare const createSavedPageInternal: ({ page }: CreateSavedPageRequest) => Promise<void>;
export declare const deleteSavedPageInternal: (id: string) => Promise<void>;
export declare const updateSavedPageInternal: ({ pageId, page }: UpdateSavedPageRequest) => Promise<any>;
export declare const savePage: (page: Page) => Promise<any>;
export declare const attachPagesToWindow: (payload: ExtendedAttachPagesToWindowPayload) => Promise<void>;
export declare const updatePageForWindow: (payload: UpdatePageForWindowPayload) => Promise<void>;
export declare const detachPagesFromWindow: (payload: DetachPagesFromWindowPayload) => Promise<void>;
export declare const setActivePage: (payload: SetActivePageForWindowPayload) => Promise<void>;
export declare const getPagesForWindow: (identity: OpenFin.Identity) => Promise<AttachedPage[]>;
export declare const getPageForWindow: ({ identity, pageId }: {
    identity: OpenFin.Identity;
    pageId: string;
}) => Promise<AttachedPage>;
export declare const reorderPagesForWindow: (payload: ReorderPagesForWindowPayload) => Promise<void>;
export declare const getActivePageIdForWindow: (identity: OpenFin.Identity) => Promise<string>;
/**
 * Checks if a given page name is unique.
 *
 * If the name is not unique, it will append a number to the end of the name.
 *
 * @param initialName The initial name to test
 * @returns string: a unique page name
 */
export declare function getUniquePageTitle(initialName?: string): Promise<string>;
export declare function handleSaveModalOnPageClose({ page }: HandleSaveModalOnPageClosePayload): Promise<SaveModalOnPageCloseResult>;
/**
 * Default implementation of shouldPageClose. If enableBeforeUnload isn't set to true, always returns True (proceed with close).
 * If beforeunload handling is enabled, will return False if any views in the page are determined not to close.
 */
export declare function shouldPageClose(this: WorkspacePlatformProvider, { page, identity }: ShouldPageClosePayload): Promise<ShouldPageCloseResult>;
/**
 * Internal function to broker closing of the window. It needs to live here to call multiple overrides directly instead of via channels.
 * @param payload Accepts pages and window identity
 * @returns a flag indicating whether to continue closing the window
 * @internal
 */
export declare function shouldWindowClose(this: WorkspacePlatformProvider, { pages, identity }: {
    pages: AttachedPage[];
    identity: OpenFin.Identity;
}): Promise<{
    shouldWindowClose: boolean;
}>;
/**
 * Default implementation of handlePagesAndWindowClose. Will abort closing of the window if any of the pages within it are prevented from closing.
 * @param payload Contains pages that were prevented from closing, pages that weren't, and identity of the window
 * @returns {shouldWindowClose: boolean} which determines whether closing of the window will proceed
 */
export declare function handlePagesAndWindowClose(this: WorkspacePlatformProvider, { pagesPreventingClose, pagesNotPreventingClose, identity }: HandlePagesAndWindowClosePayload): Promise<HandlePagesAndWindowCloseResult>;
export declare function copyPageOverride({ page }: CopyPagePayload): Promise<Page>;
export declare function handlePageChanges(payload: HandlePageChangesPayload): Promise<ModifiedPageState>;
/**
 * Mark all unsaved pages as saved.
 */
export declare const markUnsavedPagesAsSavedInternal: () => Promise<void>;
