import type OpenFin from '@openfin/core';
import { App } from '../../../client-api/src/shapes';
import { SearchProvider } from '../../../client-api-platform/src/shapes';
import type { LaunchAppRequest, SearchSitesRequest, SearchSitesResponse, Site } from '../shapes';
/**
 * Launch the app described by an App Directory entry.
 * @param app the app directory entry.
 * @param opts launch options.
 */
export declare function launchApp({ app, target }: LaunchAppRequest): Promise<void | OpenFin.View | OpenFin.Identity | OpenFin.Platform | OpenFin.Application>;
export declare const enterpriseAppDirectoryChannelClient: () => Promise<OpenFin.ChannelClient>;
export declare function getResults(payload: {
    req: SearchSitesRequest;
} & {
    identity: OpenFin.Identity;
}): Promise<SearchSitesResponse>;
export declare function getSearchProviders(payload: {
    identity: OpenFin.Identity;
}): Promise<SearchProvider[]>;
export declare function getCuratedContent(payload: {
    identity: OpenFin.Identity;
}): Promise<Site[]>;
export declare function getRecentlyVisited(payload: {
    identity: OpenFin.Identity;
}): Promise<App[]>;
