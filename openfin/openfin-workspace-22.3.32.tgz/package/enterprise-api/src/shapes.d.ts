import type { OpenFin } from '@openfin/core';
/**
 * Base options for page operations (used by _addPages)
 * @internal
 */
export interface BasePageOpts {
    multiInstanceViewBehavior?: OpenFin.MultiInstanceViewBehavior;
}
/**
 * Extended options for single page operations (used by _addPage)
 * @internal
 */
export interface PageOpts extends BasePageOpts {
    index?: number;
}
/**
 * Options for adding pages, either by index or by replacing the active page.
 *
 * - If `insertionIndex` is set, the new pages will be inserted at the specified index.
 * - If `replaceActivePage` is set to `true`, the active page will be replaced with the new pages.
 * - Only one of `insertionIndex` or `replaceActivePage` should be set at a time.
 *
 * @example
 * // Insert at index 2
 * const opts: AddPagesOptions = { insertionIndex: 2 };
 *
 * // Replace the active page
 * const opts: AddPagesOptions = { replaceActivePage: true };
 *
 * @internal
 */
export type AddPagesOptions = {
    insertionIndex: number;
    replaceActivePage?: never;
} | {
    replaceActivePage: true;
    insertionIndex?: never;
};
