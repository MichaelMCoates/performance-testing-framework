import { ProvidersMap } from '../../../../client-api/src/internal/providers';
import { CLIProvider, HomeProvider, RegisterMetaInfoInternal } from '../..';
export declare const HomeProviders: ProvidersMap<HomeProvider | CLIProvider>;
export declare const registerHomeProviderInternal: (provider: HomeProvider | CLIProvider) => Promise<RegisterMetaInfoInternal>;
