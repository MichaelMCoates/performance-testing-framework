import * as Notifications from 'openfin-notifications/dist/client/without-auto-launch';
import type { NotificationsPlatform, NotificationsRegisterOptions } from './shapes/notifications';
export * from 'openfin-notifications/dist/client/without-auto-launch';
export * from './shapes/notifications';
/**
 * @deprecated Use `register` with {@link NotificationsRegisterOptions | options?: NotificationsRegisterOptions} argument instead.
 */
export declare function register(platform: NotificationsPlatform): Promise<Notifications.NotificationsRegistration>;
/**
 * Launches Notifications service and registers a notifications platform. Throws if workspace platform is not initialized or if you run version of notifications-service which doesn't support platforms.
 *
 * @param options {@link NotificationsPlatform} object
 */
export declare function register(options?: NotificationsRegisterOptions): Promise<Notifications.NotificationsRegistration>;
/**
 * Deregisters notifications platform. Throws if you run version of notifications-service which doesn't support platforms.
 * @param platformId id of the platform to deregister
 */
export declare const deregister: (platformId: string) => Promise<void>;
