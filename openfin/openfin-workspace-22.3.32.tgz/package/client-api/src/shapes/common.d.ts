export type { Action, DispatchedAction, DispatchedSearchResult, SearchListenerRequest, SearchListenerResponse, SearchProviderInfo, SearchResult, ScoreOrder, SearchTag, SearchProvider, UserInputListener, ResultDispatchListener, SearchResponse } from '../../../search-api/src/index';
export type { Workspace } from '../../../common/src/api/workspaces';
export { SearchTagBackground, ActionTrigger } from '../../../search-api/src/shapes';
export type { ProviderInfo } from './provider';
export type { BaseCustomButtonConfig, BaseCustomDropdownConfig, BaseCustomDropdownItem, BaseCustomDropdownItems, CustomActionSpecifier, CustomButtonConfig, CustomDropdownConfig } from '../../../common/src/api/action';
/**
 * Registration meta info
 *
 * Returned when a Workspace component is registered.
 */
export interface RegistrationMetaInfo {
    /**
     * Client API version
     *
     * This is the version of the Workspace client API that is being used to register the component.
     */
    clientAPIVersion: string;
    /**
     * Workspace version
     *
     * This is the version of Workspace that the Workspace component is running on.
     * This could be used to determine if the component is running on a version of Workspace that supports a particular feature.
     */
    workspaceVersion: string;
}
/**
 * Response from the Workspace Provider when a component is registered.
 *
 * @internal
 */
export type RegisterMetaInfoInternal = Pick<RegistrationMetaInfo, 'workspaceVersion'>;
