/**
 * This module exports only notifications types that are not defined in 'openfin-notifications' npm package
 */
import { NotificationsCustomManifestOptions } from '../../../common/src/api/shapes/notifications';
/**
 * Platform object to pass to `register` function.
 *
 * ```ts
 * import { register, NotificationsPlatform } from '@openfin/workspace/notifications';
 *
 * const platform: NotificationsPlatform = {
 *    id: 'my-notifications-platform',
 *    title: 'My Notifications Platform',
 *    icon: 'https://link.to/my-notifications-platform.ico'
 * }
 *
 * await register(platform);
 * ```
 */
export interface NotificationsPlatform {
    /**
     * Unique identifier of the platform.
     */
    id: string;
    /**
     * Stream title.
     *
     * Providing a different displayName for an existing stream id will update the
     * displayName of the stream stored in Notification Center.
     *
     */
    title: string;
    /**
     * URL of the icon to be displayed for this platform.
     */
    icon: string;
}
export interface NotificationsRegisterOptions {
    notificationsPlatformOptions?: NotificationsPlatform;
    notificationsCustomManifest?: NotificationsCustomManifestOptions;
}
